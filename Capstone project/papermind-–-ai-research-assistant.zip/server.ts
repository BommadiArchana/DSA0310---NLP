import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import apiRouter from './server/routes/api.ts';
import {
  originProtectionMiddleware,
  sessionMiddleware,
} from './server/utils/security.ts';

const PORT = Number(process.env.PORT || 3000);
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

async function startServer(): Promise<void> {
  const app = express();
  app.set('trust proxy', 1);

  app.use(express.json({ limit: '2mb' }));
  app.use(sessionMiddleware);
  app.use('/api', originProtectionMiddleware, apiRouter);

  if (!IS_PRODUCTION) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(
      `PaperMind server running on http://0.0.0.0:${PORT} (${IS_PRODUCTION ? 'production' : 'development'})`,
    );
  });
}

startServer().catch((err) => {
  console.error('Failed to start PaperMind server:', err);
  process.exit(1);
});
