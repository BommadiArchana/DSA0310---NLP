import type { PaperComparisonResult, StoredDocument } from '../types.ts';
import {
  Type,
  callWithRetry,
  getGeminiClient,
  parseStructuredJson,
} from './geminiService.ts';

const COMPARISON_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    paperATitle: { type: Type.STRING },
    paperBTitle: { type: Type.STRING },
    comparisonTable: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          dimension: { type: Type.STRING },
          paperA: { type: Type.STRING },
          paperB: { type: Type.STRING },
          notes: { type: Type.STRING },
        },
        required: ['dimension', 'paperA', 'paperB', 'notes'],
      },
    },
    metricComparabilityWarning: { type: Type.STRING },
    similarities: { type: Type.ARRAY, items: { type: Type.STRING } },
    differences: { type: Type.ARRAY, items: { type: Type.STRING } },
    overallSummary: { type: Type.STRING },
  },
  required: [
    'paperATitle',
    'paperBTitle',
    'comparisonTable',
    'metricComparabilityWarning',
    'similarities',
    'differences',
    'overallSummary',
  ],
};

function summarizePaperForComparison(doc: StoredDocument) {
  return {
    filename: doc.originalFilename,
    pageCount: doc.pageCount,
    extraction: doc.extraction,
    analysisSummary: doc.analysis?.summary,
    methodologyAnalysis: doc.analysis?.methodologyAnalysis,
    datasetAnalysis: doc.analysis?.datasetAnalysis,
    resultsAnalysis: doc.analysis?.resultsAnalysis,
    strengthsAndWeaknesses: doc.analysis?.strengthsAndWeaknesses,
    researchGaps: doc.analysis?.researchGaps,
    futureScope: doc.analysis?.futureScope,
    textExcerpt: doc.fullText.slice(0, 24000),
  };
}

export async function compareResearchPapers(
  docA: StoredDocument,
  docB: StoredDocument,
): Promise<PaperComparisonResult> {
  const ai = getGeminiClient();

  const prompt = `Compare these two research papers rigorously across all 12 required academic dimensions:
1. Research Objectives
2. Research Problems
3. Methodologies
4. Algorithms
5. Datasets
6. Tools & Technologies
7. Performance Metrics (definitions & units)
8. Experimental Results
9. Strengths
10. Limitations
11. Research Contributions
12. Future Scope

CRITICAL COMPARABILITY RULES:
- Ground every cell strictly in the respective paper's actual extracted content.
- If a paper does not report a value or detail, explicitly state "Not specified in Paper A/B".
- NEVER compare performance metrics that use different definitions, datasets, tasks, or scales (e.g., MAE vs Accuracy, or accuracy on different datasets) as if they were directly equivalent. Explicitly note metric comparability caveats in both the Performance Metrics/Experimental Results rows and in "metricComparabilityWarning".

PAPER A:
${JSON.stringify(summarizePaperForComparison(docA))}

PAPER B:
${JSON.stringify(summarizePaperForComparison(docB))}`;

  const response = await callWithRetry(
    (attemptModel, attemptThinking) =>
      ai.models.generateContent({
        model: attemptModel,
        contents: prompt,
        config: {
          systemInstruction:
            'You are an academic peer reviewer conducting a rigorous side-by-side comparison of two research papers without fabricating data or conflating incompatible metrics.',
          responseMimeType: 'application/json',
          responseSchema: COMPARISON_RESPONSE_SCHEMA,
          thinkingConfig: { thinkingLevel: attemptThinking },
        },
      }),
    { retries: 1, timeoutMs: 55000 },
  );

  const parsed = parseStructuredJson<PaperComparisonResult>(response.text);
  docA.lastComparison = parsed;
  return parsed;
}
