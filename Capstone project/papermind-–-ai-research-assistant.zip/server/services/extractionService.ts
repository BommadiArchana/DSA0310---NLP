import type {
  ExtractedPage,
  ExtractedReference,
  SmartExtractionData,
  StoredDocument,
} from '../types.ts';
import {
  ThinkingLevel,
  parseStructuredJson,
  splitDocumentTextForLargePapers,
  streamGenerateContentText,
} from './geminiService.ts';

export const NOT_SPECIFIED = 'Not specified in the document';

export function extractReferencesFromPages(
  pages: ExtractedPage[],
): ExtractedReference[] {
  const fullLines: string[] = [];
  let inRefsSection = false;

  for (const page of pages) {
    const lines = page.text.split('\n');
    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line) continue;

      if (
        /^(?:\d+\.?\s+)?(?:references|bibliography|works cited)$/i.test(line)
      ) {
        inRefsSection = true;
        continue;
      }
      if (
        inRefsSection &&
        /^(?:appendix|acknowledg(?:e)?ments?|author biographies)$/i.test(line)
      ) {
        inRefsSection = false;
        continue;
      }
      if (inRefsSection) {
        fullLines.push(line);
      }
    }
  }

  if (fullLines.length === 0) return [];

  // Reassemble multi-line references starting with [1], [2] or 1., 2.
  const entries: string[] = [];
  let current = '';
  for (const line of fullLines) {
    if (/^(?:\[\d+\]|\d{1,3}\.)\s+/.test(line)) {
      if (current.trim()) entries.push(current.trim());
      current = line.replace(/^(?:\[\d+\]|\d{1,3}\.)\s+/, '');
    } else if (current) {
      current += ' ' + line;
    } else {
      current = line;
    }
  }
  if (current.trim()) entries.push(current.trim());

  const refs: ExtractedReference[] = [];
  for (const entry of entries.slice(0, 60)) {
    const yearMatch = entry.match(/\b(19\d{2}|20\d{2})\b/);
    const year = yearMatch ? yearMatch[1] : NOT_SPECIFIED;

    const doiMatch = entry.match(
      /(https?:\/\/\S+|10\.\d{4,9}\/[-._;()/:A-Za-z0-9]+)/i,
    );
    const doiOrUrl = doiMatch ? doiMatch[1].replace(/[.,;)]+$/, '') : NOT_SPECIFIED;

    // Extract title & authors heuristically from comma/period splits without fabricating
    const quotedMatch = entry.match(/["“]([^"”]{6,200})["”]/);
    let title = quotedMatch ? quotedMatch[1].trim() : '';
    let authors = NOT_SPECIFIED;

    if (quotedMatch && quotedMatch.index !== undefined) {
      const beforeQuote = entry.slice(0, quotedMatch.index).replace(/[,.\s]+$/, '').trim();
      if (beforeQuote.length >= 2) authors = beforeQuote;
    } else {
      const parts = entry.split(/\.\s+/);
      if (parts.length >= 2) {
        authors = parts[0].trim() || NOT_SPECIFIED;
        title = parts[1].trim();
      } else {
        title = entry.slice(0, 180).trim();
      }
    }

    if (title.length >= 4) {
      refs.push({
        title,
        authors: authors || NOT_SPECIFIED,
        year,
        doiOrUrl,
      });
    }
  }

  return refs;
}

function strOrDefault(v: unknown): string {
  if (typeof v !== 'string') return NOT_SPECIFIED;
  const trimmed = v.trim();
  return trimmed.length > 0 ? trimmed : NOT_SPECIFIED;
}

function arrOrEmpty(v: unknown): string[] {
  if (!Array.isArray(v)) return [];
  return v
    .filter((item): item is string => typeof item === 'string')
    .map((s) => s.trim())
    .filter((s) => s.length > 0 && s !== NOT_SPECIFIED);
}

export function normalizeExtraction(
  raw: Partial<SmartExtractionData>,
  fallbackRefs: ExtractedReference[] = [],
): SmartExtractionData {
  const g = raw.generalInfo ?? ({} as SmartExtractionData['generalInfo']);
  const r = raw.researchInfo ?? ({} as SmartExtractionData['researchInfo']);
  const t = raw.technicalInfo ?? ({} as SmartExtractionData['technicalInfo']);
  const e = raw.experimentalInfo ?? ({} as SmartExtractionData['experimentalInfo']);
  const c = raw.conclusions ?? ({} as SmartExtractionData['conclusions']);

  const aiRefs: ExtractedReference[] = Array.isArray(raw.references)
    ? raw.references
        .filter((ref) => ref && typeof ref === 'object')
        .map((ref) => ({
          title: strOrDefault(ref.title),
          authors: strOrDefault(ref.authors),
          year: strOrDefault(ref.year),
          doiOrUrl: strOrDefault(ref.doiOrUrl),
        }))
        .filter(
          (ref) => ref.title !== NOT_SPECIFIED || ref.authors !== NOT_SPECIFIED,
        )
    : [];

  const refs = fallbackRefs.length > 0 ? fallbackRefs : aiRefs;

  return {
    generalInfo: {
      title: strOrDefault(g.title),
      authors: arrOrEmpty(g.authors),
      publicationYear: strOrDefault(g.publicationYear),
      journalOrConference: strOrDefault(g.journalOrConference),
      doi: strOrDefault(g.doi),
      abstract: strOrDefault(g.abstract),
      keywords: arrOrEmpty(g.keywords),
    },
    researchInfo: {
      researchProblem: strOrDefault(r.researchProblem),
      researchObjectives: arrOrEmpty(r.researchObjectives),
      researchQuestions: arrOrEmpty(r.researchQuestions),
      researchMotivation: strOrDefault(r.researchMotivation),
      existingSystem: strOrDefault(r.existingSystem),
      proposedSystem: strOrDefault(r.proposedSystem),
      researchContributions: arrOrEmpty(r.researchContributions),
    },
    technicalInfo: {
      researchMethodology: strOrDefault(t.researchMethodology),
      algorithmsUsed: arrOrEmpty(t.algorithmsUsed),
      mlModels: arrOrEmpty(t.mlModels),
      dlModels: arrOrEmpty(t.dlModels),
      nlpTechniques: arrOrEmpty(t.nlpTechniques),
      datasetNames: arrOrEmpty(t.datasetNames),
      datasetDescriptions: arrOrEmpty(t.datasetDescriptions),
      toolsAndTechnologies: arrOrEmpty(t.toolsAndTechnologies),
      softwareAndLibraries: arrOrEmpty(t.softwareAndLibraries),
    },
    experimentalInfo: {
      experimentalSetup: strOrDefault(e.experimentalSetup),
      evaluationMethods: arrOrEmpty(e.evaluationMethods),
      performanceMetricsSummary: strOrDefault(e.performanceMetricsSummary),
      accuracy: strOrDefault(e.accuracy),
      precision: strOrDefault(e.precision),
      recall: strOrDefault(e.recall),
      f1Score: strOrDefault(e.f1Score),
      mae: strOrDefault(e.mae),
      rmse: strOrDefault(e.rmse),
      otherMeasurements: arrOrEmpty(e.otherMeasurements),
      experimentalFindings: arrOrEmpty(e.experimentalFindings),
    },
    conclusions: {
      keyFindings: arrOrEmpty(c.keyFindings),
      strengths: arrOrEmpty(c.strengths),
      limitations: arrOrEmpty(c.limitations),
      challenges: arrOrEmpty(c.challenges),
      futureScope: arrOrEmpty(c.futureScope),
      conclusion: strOrDefault(c.conclusion),
    },
    references: refs,
  };
}

export function mergeExtractions(
  items: SmartExtractionData[],
): SmartExtractionData {
  if (items.length === 1) return items[0];

  const pickFirstStr = (vals: string[]) =>
    vals.find((v) => v && v !== NOT_SPECIFIED) ?? NOT_SPECIFIED;

  const mergeArrays = (lists: string[][]) => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const list of lists) {
      for (const item of list) {
        const key = item.toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          out.push(item);
        }
      }
    }
    return out;
  };

  const joinLongStr = (vals: string[]) => {
    const valid = vals.filter((v) => v && v !== NOT_SPECIFIED);
    if (valid.length === 0) return NOT_SPECIFIED;
    return Array.from(new Set(valid)).join(' ');
  };

  const mergedRefs: ExtractedReference[] = [];
  const refSeen = new Set<string>();
  for (const item of items) {
    for (const ref of item.references) {
      const k = `${ref.title.toLowerCase()}|${ref.year}`;
      if (!refSeen.has(k)) {
        refSeen.add(k);
        mergedRefs.push(ref);
      }
    }
  }

  return {
    generalInfo: {
      title: pickFirstStr(items.map((i) => i.generalInfo.title)),
      authors: mergeArrays(items.map((i) => i.generalInfo.authors)),
      publicationYear: pickFirstStr(
        items.map((i) => i.generalInfo.publicationYear),
      ),
      journalOrConference: pickFirstStr(
        items.map((i) => i.generalInfo.journalOrConference),
      ),
      doi: pickFirstStr(items.map((i) => i.generalInfo.doi)),
      abstract: pickFirstStr(items.map((i) => i.generalInfo.abstract)),
      keywords: mergeArrays(items.map((i) => i.generalInfo.keywords)),
    },
    researchInfo: {
      researchProblem: joinLongStr(
        items.map((i) => i.researchInfo.researchProblem),
      ),
      researchObjectives: mergeArrays(
        items.map((i) => i.researchInfo.researchObjectives),
      ),
      researchQuestions: mergeArrays(
        items.map((i) => i.researchInfo.researchQuestions),
      ),
      researchMotivation: joinLongStr(
        items.map((i) => i.researchInfo.researchMotivation),
      ),
      existingSystem: joinLongStr(
        items.map((i) => i.researchInfo.existingSystem),
      ),
      proposedSystem: joinLongStr(
        items.map((i) => i.researchInfo.proposedSystem),
      ),
      researchContributions: mergeArrays(
        items.map((i) => i.researchInfo.researchContributions),
      ),
    },
    technicalInfo: {
      researchMethodology: joinLongStr(
        items.map((i) => i.technicalInfo.researchMethodology),
      ),
      algorithmsUsed: mergeArrays(
        items.map((i) => i.technicalInfo.algorithmsUsed),
      ),
      mlModels: mergeArrays(items.map((i) => i.technicalInfo.mlModels)),
      dlModels: mergeArrays(items.map((i) => i.technicalInfo.dlModels)),
      nlpTechniques: mergeArrays(
        items.map((i) => i.technicalInfo.nlpTechniques),
      ),
      datasetNames: mergeArrays(items.map((i) => i.technicalInfo.datasetNames)),
      datasetDescriptions: mergeArrays(
        items.map((i) => i.technicalInfo.datasetDescriptions),
      ),
      toolsAndTechnologies: mergeArrays(
        items.map((i) => i.technicalInfo.toolsAndTechnologies),
      ),
      softwareAndLibraries: mergeArrays(
        items.map((i) => i.technicalInfo.softwareAndLibraries),
      ),
    },
    experimentalInfo: {
      experimentalSetup: joinLongStr(
        items.map((i) => i.experimentalInfo.experimentalSetup),
      ),
      evaluationMethods: mergeArrays(
        items.map((i) => i.experimentalInfo.evaluationMethods),
      ),
      performanceMetricsSummary: joinLongStr(
        items.map((i) => i.experimentalInfo.performanceMetricsSummary),
      ),
      accuracy: pickFirstStr(items.map((i) => i.experimentalInfo.accuracy)),
      precision: pickFirstStr(items.map((i) => i.experimentalInfo.precision)),
      recall: pickFirstStr(items.map((i) => i.experimentalInfo.recall)),
      f1Score: pickFirstStr(items.map((i) => i.experimentalInfo.f1Score)),
      mae: pickFirstStr(items.map((i) => i.experimentalInfo.mae)),
      rmse: pickFirstStr(items.map((i) => i.experimentalInfo.rmse)),
      otherMeasurements: mergeArrays(
        items.map((i) => i.experimentalInfo.otherMeasurements),
      ),
      experimentalFindings: mergeArrays(
        items.map((i) => i.experimentalInfo.experimentalFindings),
      ),
    },
    conclusions: {
      keyFindings: mergeArrays(items.map((i) => i.conclusions.keyFindings)),
      strengths: mergeArrays(items.map((i) => i.conclusions.strengths)),
      limitations: mergeArrays(items.map((i) => i.conclusions.limitations)),
      challenges: mergeArrays(items.map((i) => i.conclusions.challenges)),
      futureScope: mergeArrays(items.map((i) => i.conclusions.futureScope)),
      conclusion: joinLongStr(items.map((i) => i.conclusions.conclusion)),
    },
    references: mergedRefs,
  };
}

export async function runSmartExtraction(
  doc: StoredDocument,
  onBatchProgress?: (msg: string) => void,
  signal?: AbortSignal,
): Promise<SmartExtractionData> {
  const parsedRefs = extractReferencesFromPages(doc.pages);
  const batches = splitDocumentTextForLargePapers(doc.pages, 140000);
  const partialResults: SmartExtractionData[] = [];

  for (const batch of batches) {
    if (batches.length > 1) {
      onBatchProgress?.(
        `Large document (${doc.pageCount} pages): extracting section batch ${batch.batchIndex} of ${batches.length} (pages ${batch.pageRange})...`,
      );
    }

    const refInstruction =
      parsedRefs.length > 0
        ? 'Leave "references" as an empty array [] (references are already parsed separately).'
        : 'Extract up to 12 key cited references found in this text into "references".';

    const prompt = `Extract structured factual information strictly from this research paper text (pages ${batch.pageRange} of ${doc.pageCount}, file: "${doc.originalFilename}").

CRITICAL RULES:
- Never invent or guess authors, years, DOIs, datasets, sample counts, or metrics.
- Set any unstated string field strictly to "${NOT_SPECIFIED}". Set any unstated array to [].
- Keep scalar descriptions concise (1-2 sentences) and arrays concise (3-6 key items).
- ${refInstruction}

Return valid JSON matching this exact structure:
{
  "generalInfo": { "title": "", "authors": [], "publicationYear": "", "journalOrConference": "", "doi": "", "abstract": "", "keywords": [] },
  "researchInfo": { "researchProblem": "", "researchObjectives": [], "researchQuestions": [], "researchMotivation": "", "existingSystem": "", "proposedSystem": "", "researchContributions": [] },
  "technicalInfo": { "researchMethodology": "", "algorithmsUsed": [], "mlModels": [], "dlModels": [], "nlpTechniques": [], "datasetNames": [], "datasetDescriptions": [], "toolsAndTechnologies": [], "softwareAndLibraries": [] },
  "experimentalInfo": { "experimentalSetup": "", "evaluationMethods": [], "performanceMetricsSummary": "", "accuracy": "", "precision": "", "recall": "", "f1Score": "", "mae": "", "rmse": "", "otherMeasurements": [], "experimentalFindings": [] },
  "conclusions": { "keyFindings": [], "strengths": [], "limitations": [], "challenges": [], "futureScope": [], "conclusion": "" },
  "references": [{ "title": "", "authors": "", "year": "", "doiOrUrl": "" }]
}

RESEARCH PAPER TEXT:
${batch.text}`;

    const rawText = await streamGenerateContentText({
      contents: prompt,
      systemInstruction:
        'You extract concise, accurate structured JSON metadata and facts from academic research papers without fabricating any missing facts.',
      responseMimeType: 'application/json',
      thinkingLevel: ThinkingLevel.LOW,
      totalTimeoutMs: 55000,
      retries: 1,
      signal,
    });

    const parsed = parseStructuredJson<Partial<SmartExtractionData>>(rawText);
    partialResults.push(normalizeExtraction(parsed, parsedRefs));
  }

  return mergeExtractions(partialResults);
}
