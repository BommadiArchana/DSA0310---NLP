import { pathToFileURL } from 'node:url';
import path from 'node:path';
import type {
  DocumentChunk,
  DocumentSection,
  ExtractedPage,
} from '../types.ts';
import {
  extractPageImagesForOcr,
  runOcrOnImageBuffers,
  type OcrPageTask,
} from './ocrService.ts';

interface TextItemLike {
  str?: string;
  hasEOL?: boolean;
  transform?: number[];
}

const KNOWN_SECTION_PATTERNS = [
  /^(abstract|summary)$/i,
  /^(keywords|index terms)$/i,
  /^(?:\d+(?:\.\d+)*\.?|[IVX]+\.?)\s+[A-Z][A-Za-z0-9\s,&:-]{2,70}$/,
  /^(introduction|background|related work|literature review|methodology|methods|proposed system|proposed approach|system architecture|experimental setup|experiments|dataset|datasets|results|results and discussion|evaluation|performance evaluation|discussion|limitations|future work|future scope|conclusion|conclusions|references|bibliography|acknowledgements|acknowledgments)$/i,
];

function isLikelyHeading(line: string): boolean {
  const trimmed = line.trim();
  if (trimmed.length < 3 || trimmed.length > 85) return false;
  if (trimmed.endsWith('.') && !/^\d+\./.test(trimmed)) return false;
  return KNOWN_SECTION_PATTERNS.some((re) => re.test(trimmed));
}

function reconstructPageText(items: TextItemLike[]): string {
  const lines: string[] = [];
  let currentLine = '';
  let lastY: number | null = null;

  for (const item of items) {
    const str = item.str ?? '';
    const y = Array.isArray(item.transform) ? item.transform[5] : null;

    if (lastY !== null && y !== null && Math.abs(y - lastY) > 4) {
      if (currentLine.trim()) {
        lines.push(currentLine.trim());
      }
      currentLine = str;
    } else {
      if (
        currentLine &&
        str &&
        !currentLine.endsWith(' ') &&
        !str.startsWith(' ') &&
        !currentLine.endsWith('-')
      ) {
        currentLine += ' ';
      }
      if (currentLine.endsWith('-') && str && /^[a-z]/.test(str)) {
        currentLine = currentLine.slice(0, -1) + str;
      } else {
        currentLine += str;
      }
    }

    if (item.hasEOL) {
      if (currentLine.trim()) {
        lines.push(currentLine.trim());
      }
      currentLine = '';
      lastY = null;
    } else if (y !== null) {
      lastY = y;
    }
  }

  if (currentLine.trim()) {
    lines.push(currentLine.trim());
  }

  return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

function identifySectionsFromPages(pages: ExtractedPage[]): DocumentSection[] {
  const sections: DocumentSection[] = [];

  for (const page of pages) {
    const lines = page.text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (isLikelyHeading(line)) {
        if (sections.length > 0) {
          sections[sections.length - 1].pageEnd = page.pageNumber;
        }
        const preview = lines
          .slice(i + 1, i + 4)
          .join(' ')
          .trim()
          .slice(0, 180);
        sections.push({
          title: line,
          pageStart: page.pageNumber,
          pageEnd: page.pageNumber,
          preview,
        });
      }
    }
  }

  if (sections.length === 0 && pages.length > 0) {
    sections.push({
      title: 'Full Document Content',
      pageStart: 1,
      pageEnd: pages[pages.length - 1].pageNumber,
      preview: pages[0].text.slice(0, 180),
    });
  } else if (sections.length > 0 && pages.length > 0) {
    sections[sections.length - 1].pageEnd = pages[pages.length - 1].pageNumber;
  }

  return sections;
}

function buildDocumentChunks(
  pages: ExtractedPage[],
  targetChunkSize = 2800,
  overlapSize = 300,
): DocumentChunk[] {
  const chunks: DocumentChunk[] = [];
  let currentSection = 'Document Opening';
  let buffer = '';
  let chunkPageStart = 1;
  let chunkPageEnd = 1;
  let chunkIndex = 1;

  const flushBuffer = (nextStartPage: number) => {
    const trimmed = buffer.trim();
    if (!trimmed) return;
    chunks.push({
      id: `chunk_${chunkIndex++}`,
      pageStart: chunkPageStart,
      pageEnd: chunkPageEnd,
      section: currentSection,
      text: trimmed,
    });
    const tail = trimmed.slice(Math.max(0, trimmed.length - overlapSize));
    buffer = tail ? `${tail}\n` : '';
    chunkPageStart = nextStartPage;
  };

  for (const page of pages) {
    if (!page.text.trim()) continue;
    const pageHeader = `[Page ${page.pageNumber}]\n`;
    const lines = page.text.split('\n');

    if (!buffer.trim()) {
      chunkPageStart = page.pageNumber;
    }
    chunkPageEnd = page.pageNumber;
    buffer += pageHeader;

    for (const line of lines) {
      if (isLikelyHeading(line)) {
        if (buffer.length > targetChunkSize * 0.5) {
          flushBuffer(page.pageNumber);
          buffer += `[Page ${page.pageNumber}]\n`;
        }
        currentSection = line.trim();
      }
      buffer += `${line}\n`;
      if (buffer.length >= targetChunkSize) {
        flushBuffer(page.pageNumber);
        buffer += `[Page ${page.pageNumber}]\n`;
      }
    }
    buffer += '\n';
  }

  if (buffer.trim()) {
    chunks.push({
      id: `chunk_${chunkIndex++}`,
      pageStart: chunkPageStart,
      pageEnd: chunkPageEnd,
      section: currentSection,
      text: buffer.trim(),
    });
  }

  return chunks;
}

export interface PdfExtractionOutput {
  pageCount: number;
  pages: ExtractedPage[];
  fullText: string;
  sections: DocumentSection[];
  chunks: DocumentChunk[];
  ocrPagesCount: number;
  ocrWarnings: string[];
  extractionStatus: 'extracted' | 'partial_ocr' | 'failed';
}

export async function extractPdfContent(
  pdfBuffer: Buffer,
): Promise<PdfExtractionOutput> {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const workerPath = path.resolve(
    process.cwd(),
    'node_modules/pdfjs-dist/legacy/build/pdf.worker.mjs',
  );
  if (pdfjs.GlobalWorkerOptions) {
    pdfjs.GlobalWorkerOptions.workerSrc = pathToFileURL(workerPath).href;
  }

  const standardFontDataUrl =
    pathToFileURL(
      path.resolve(process.cwd(), 'node_modules/pdfjs-dist/standard_fonts'),
    ).href + '/';
  const cMapUrl =
    pathToFileURL(
      path.resolve(process.cwd(), 'node_modules/pdfjs-dist/cmaps'),
    ).href + '/';
  const iccUrl =
    pathToFileURL(
      path.resolve(process.cwd(), 'node_modules/pdfjs-dist/iccs'),
    ).href + '/';
  const wasmUrl =
    pathToFileURL(
      path.resolve(process.cwd(), 'node_modules/pdfjs-dist/wasm'),
    ).href + '/';

  let pdfDoc;
  try {
    const loadingTask = pdfjs.getDocument({
      data: new Uint8Array(pdfBuffer),
      verbosity: 0,
      useSystemFonts: true,
      disableFontFace: true,
      standardFontDataUrl,
      cMapUrl,
      cMapPacked: true,
      iccUrl,
      wasmUrl,
    });
    pdfDoc = await loadingTask.promise;
  } catch (err: unknown) {
    const name =
      err && typeof err === 'object' && 'name' in err
        ? String((err as { name: string }).name)
        : '';
    const message = err instanceof Error ? err.message : String(err);

    if (
      name === 'PasswordException' ||
      /password/i.test(message)
    ) {
      throw new PdfProcessingError(
        'This PDF is password-protected. Please remove the password and upload an unlocked PDF.',
        'PASSWORD_PROTECTED',
      );
    }
    if (
      name === 'InvalidPDFException' ||
      /invalid pdf|corrupt|stream must have data/i.test(message)
    ) {
      throw new PdfProcessingError(
        'The uploaded file is corrupted or not a valid PDF structure.',
        'CORRUPTED_PDF',
      );
    }
    throw new PdfProcessingError(
      `Failed to read PDF document: ${message}`,
      'EXTRACTION_FAILED',
    );
  }

  const pageCount = pdfDoc.numPages;
  if (!pageCount || pageCount <= 0) {
    throw new PdfProcessingError(
      'The uploaded PDF contains 0 pages.',
      'EMPTY_PDF',
    );
  }

  const pages: ExtractedPage[] = [];
  const ocrTasks: OcrPageTask[] = [];
  const ocrWarnings: string[] = [];

  for (let p = 1; p <= pageCount; p++) {
    const page = await pdfDoc.getPage(p);
    const textContent = await page.getTextContent();
    const extracted = reconstructPageText(textContent.items as TextItemLike[]);
    const nonWsCount = extracted.replace(/\s+/g, '').length;

    if (nonWsCount < 40) {
      // Likely a scanned page or diagram-heavy page; queue for OCR
      const imageBuffers =
        p <= 25 // Cap heavy OCR per upload to 25 scanned pages for responsiveness
          ? await extractPageImagesForOcr(page, pdfjs.OPS)
          : [];
      if (p > 25) {
        ocrWarnings.push(
          `Page ${p}: skipped OCR beyond 25 scanned pages limit.`,
        );
      } else {
        ocrTasks.push({ pageNumber: p, imageBuffers });
      }
    }

    pages.push({
      pageNumber: p,
      text: extracted,
      charCount: nonWsCount,
      ocrUsed: false,
    });
  }

  let ocrPagesCount = 0;
  if (ocrTasks.length > 0) {
    const ocrResults = await runOcrOnImageBuffers(ocrTasks);
    for (const [pageNumber, res] of ocrResults.entries()) {
      const target = pages.find((pg) => pg.pageNumber === pageNumber);
      if (!target) continue;
      if (res.text && res.text.replace(/\s+/g, '').length > target.charCount) {
        target.text = res.text;
        target.charCount = res.text.replace(/\s+/g, '').length;
        target.ocrUsed = true;
        ocrPagesCount++;
      } else if (res.error) {
        target.ocrError = res.error;
        ocrWarnings.push(`Page ${pageNumber}: ${res.error}`);
      }
    }
  }

  const totalNonWs = pages.reduce((acc, pg) => acc + pg.charCount, 0);
  if (totalNonWs < 25) {
    throw new PdfProcessingError(
      'No readable text could be extracted from this PDF (it may be an empty PDF or an unreadable scan without extractable text).',
      ocrTasks.length > 0 ? 'UNREADABLE_SCANNED_PDF' : 'EMPTY_PDF',
    );
  }

  const fullText = pages
    .map((pg) => `--- [Page ${pg.pageNumber}] ---\n${pg.text}`)
    .join('\n\n');

  const sections = identifySectionsFromPages(pages);
  const chunks = buildDocumentChunks(pages);

  return {
    pageCount,
    pages,
    fullText,
    sections,
    chunks,
    ocrPagesCount,
    ocrWarnings,
    extractionStatus: ocrPagesCount > 0 ? 'partial_ocr' : 'extracted',
  };
}

export class PdfProcessingError extends Error {
  code:
    | 'PASSWORD_PROTECTED'
    | 'CORRUPTED_PDF'
    | 'EMPTY_PDF'
    | 'UNREADABLE_SCANNED_PDF'
    | 'EXTRACTION_FAILED';

  constructor(
    message: string,
    code:
      | 'PASSWORD_PROTECTED'
      | 'CORRUPTED_PDF'
      | 'EMPTY_PDF'
      | 'UNREADABLE_SCANNED_PDF'
      | 'EXTRACTION_FAILED',
  ) {
    super(message);
    this.name = 'PdfProcessingError';
    this.code = code;
  }
}
