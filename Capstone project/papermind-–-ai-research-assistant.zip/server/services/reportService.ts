import crypto from 'node:crypto';
import fs from 'node:fs';
import PDFDocument from 'pdfkit';
import type { StoredDocument, StoredReport } from '../types.ts';
import { resolveInsideDir } from '../utils/security.ts';
import {
  DOCUMENT_TTL_MS,
  REPORTS_DIR,
  setReport,
} from './storageService.ts';

export interface StructuredReportPayload {
  generatedAt: string;
  documentId: string;
  sourceFilename: string;
  pageCount: number;
  sections: {
    researchPaperInformation: {
      title: string;
      authors: string[];
      publicationYear: string;
      journalOrConference: string;
      doi: string;
      keywords: string[];
    };
    abstractSummary: {
      originalAbstract: string;
      shortSummary: string;
      detailedSummary: string;
    };
    introduction: {
      mainPurpose: string;
      researchMotivation: string;
      importantContributions: string[];
    };
    researchProblem: {
      mainProblem: string;
      whyProblemExists: string;
      existingChallenges: string[];
      whyResearchNecessary: string;
    };
    researchObjectives: Array<{
      objective: string;
      simpleExplanation: string;
    }>;
    methodology: {
      researchApproach: string;
      proposedMethodology: string;
      workflowSteps: Array<{
        stepNumber: number;
        title: string;
        description: string;
      }>;
      implementationDetails: string;
    };
    algorithmsAndModels: {
      algorithmsUsed: string[];
      mlModels: string[];
      dlModels: string[];
      nlpTechniques: string[];
    };
    datasetInformation: Array<{
      datasetName: string;
      datasetSource: string;
      numberOfRecords: string;
      characteristics: string;
      preprocessingMethods: string[];
      trainTestSplitDetails: string;
    }>;
    toolsAndTechnologies: {
      toolsAndTechnologies: string[];
      softwareAndLibraries: string[];
    };
    experimentalResults: {
      experimentalSetup: string;
      evaluationMethods: string[];
      experimentalFindings: string[];
      metricsTable: Array<{
        modelOrAlgorithm: string;
        dataset: string;
        accuracy: number | null;
        precision: number | null;
        recall: number | null;
        f1Score: number | null;
        mae: number | null;
        rmse: number | null;
        otherMetrics: string;
        rawReportedValues: string;
      }>;
    };
    performanceAnalysis: {
      explanation: string;
      performanceMetricsSummary: string;
    };
    strengthsAndLimitations: {
      majorStrengths: string[];
      technicalAdvantages: string[];
      methodologicalLimitations: string[];
      performanceLimitations: string[];
      practicalChallenges: string[];
    };
    researchGap: {
      authorIdentifiedGaps: string[];
      aiSuggestedOpportunities: string[];
    };
    futureScope: {
      aiGeneratedDisclaimer: string;
      possibleImprovements: string[];
      alternativeApproaches: string[];
      newAlgorithmsToInvestigate: string[];
      possibleApplications: string[];
      futureResearchDirections: string[];
    };
    conclusion: {
      finalConclusion: string;
      paperConclusion: string;
    };
    references: Array<{
      title: string;
      authors: string;
      year: string;
      doiOrUrl: string;
    }>;
  };
}

export function buildStructuredReportPayload(
  doc: StoredDocument,
): StructuredReportPayload {
  const ext = doc.extraction;
  const ana = doc.analysis;
  const NS = 'Not specified in the document';

  return {
    generatedAt: new Date().toISOString(),
    documentId: doc.documentId,
    sourceFilename: doc.originalFilename,
    pageCount: doc.pageCount,
    sections: {
      researchPaperInformation: {
        title: ext?.generalInfo.title || doc.originalFilename,
        authors: ext?.generalInfo.authors || [],
        publicationYear: ext?.generalInfo.publicationYear || NS,
        journalOrConference: ext?.generalInfo.journalOrConference || NS,
        doi: ext?.generalInfo.doi || NS,
        keywords: ext?.generalInfo.keywords || [],
      },
      abstractSummary: {
        originalAbstract: ext?.generalInfo.abstract || NS,
        shortSummary: ana?.summary.shortSummary || NS,
        detailedSummary: ana?.summary.detailedSummary || NS,
      },
      introduction: {
        mainPurpose: ana?.summary.mainPurpose || NS,
        researchMotivation: ext?.researchInfo.researchMotivation || NS,
        importantContributions:
          ana?.summary.importantContributions ||
          ext?.researchInfo.researchContributions ||
          [],
      },
      researchProblem: {
        mainProblem:
          ana?.problemAnalysis.mainProblem ||
          ext?.researchInfo.researchProblem ||
          NS,
        whyProblemExists: ana?.problemAnalysis.whyProblemExists || NS,
        existingChallenges: ana?.problemAnalysis.existingChallenges || [],
        whyResearchNecessary: ana?.problemAnalysis.whyResearchNecessary || NS,
      },
      researchObjectives:
        ana?.objectivesExplained && ana.objectivesExplained.length > 0
          ? ana.objectivesExplained
          : (ext?.researchInfo.researchObjectives || []).map((o) => ({
              objective: o,
              simpleExplanation: o,
            })),
      methodology: {
        researchApproach: ana?.methodologyAnalysis.researchApproach || NS,
        proposedMethodology:
          ana?.methodologyAnalysis.proposedMethodology ||
          ext?.technicalInfo.researchMethodology ||
          NS,
        workflowSteps: ana?.methodologyAnalysis.workflowSteps || [],
        implementationDetails:
          ana?.methodologyAnalysis.implementationDetails || NS,
      },
      algorithmsAndModels: {
        algorithmsUsed:
          ext?.technicalInfo.algorithmsUsed ||
          ana?.methodologyAnalysis.algorithmsUsed ||
          [],
        mlModels: ext?.technicalInfo.mlModels || [],
        dlModels: ext?.technicalInfo.dlModels || [],
        nlpTechniques: ext?.technicalInfo.nlpTechniques || [],
      },
      datasetInformation: ana?.datasetAnalysis || [],
      toolsAndTechnologies: {
        toolsAndTechnologies: ext?.technicalInfo.toolsAndTechnologies || [],
        softwareAndLibraries: ext?.technicalInfo.softwareAndLibraries || [],
      },
      experimentalResults: {
        experimentalSetup: ext?.experimentalInfo.experimentalSetup || NS,
        evaluationMethods: ext?.experimentalInfo.evaluationMethods || [],
        experimentalFindings: ext?.experimentalInfo.experimentalFindings || [],
        metricsTable: ana?.resultsAnalysis.metricsTable || [],
      },
      performanceAnalysis: {
        explanation: ana?.resultsAnalysis.explanation || NS,
        performanceMetricsSummary:
          ext?.experimentalInfo.performanceMetricsSummary || NS,
      },
      strengthsAndLimitations: {
        majorStrengths:
          ana?.strengthsAndWeaknesses.majorStrengths ||
          ext?.conclusions.strengths ||
          [],
        technicalAdvantages:
          ana?.strengthsAndWeaknesses.technicalAdvantages || [],
        methodologicalLimitations:
          ana?.strengthsAndWeaknesses.methodologicalLimitations ||
          ext?.conclusions.limitations ||
          [],
        performanceLimitations:
          ana?.strengthsAndWeaknesses.performanceLimitations || [],
        practicalChallenges:
          ana?.strengthsAndWeaknesses.practicalChallenges ||
          ext?.conclusions.challenges ||
          [],
      },
      researchGap: {
        authorIdentifiedGaps: ana?.researchGaps.authorIdentifiedGaps || [],
        aiSuggestedOpportunities:
          ana?.researchGaps.aiSuggestedOpportunities || [],
      },
      futureScope: {
        aiGeneratedDisclaimer:
          ana?.futureScope.aiGeneratedDisclaimer ||
          'AI-Generated Suggestions (Gemini)',
        possibleImprovements: ana?.futureScope.possibleImprovements || [],
        alternativeApproaches: ana?.futureScope.alternativeApproaches || [],
        newAlgorithmsToInvestigate:
          ana?.futureScope.newAlgorithmsToInvestigate || [],
        possibleApplications: ana?.futureScope.possibleApplications || [],
        futureResearchDirections:
          ana?.futureScope.futureResearchDirections ||
          ext?.conclusions.futureScope ||
          [],
      },
      conclusion: {
        finalConclusion: ana?.finalConclusion || NS,
        paperConclusion: ext?.conclusions.conclusion || NS,
      },
      references: ext?.references || [],
    },
  };
}

export function formatReportAsTxt(payload: StructuredReportPayload): string {
  const s = payload.sections;
  const lines: string[] = [];
  const hr = '='.repeat(76);
  const sub = '-'.repeat(60);

  const pushBullets = (label: string, items: string[]) => {
    lines.push(`${label}:`);
    if (!items || items.length === 0) {
      lines.push('  - Not specified in the document');
    } else {
      for (const item of items) {
        lines.push(`  - ${item}`);
      }
    }
  };

  lines.push(hr);
  lines.push('PAPERMIND – RESEARCH PAPER ANALYSIS REPORT');
  lines.push(`Generated: ${new Date(payload.generatedAt).toUTCString()}`);
  lines.push(`Source File: ${payload.sourceFilename} (${payload.pageCount} pages)`);
  lines.push(hr);
  lines.push('');

  lines.push('1. RESEARCH PAPER INFORMATION');
  lines.push(sub);
  lines.push(`Title: ${s.researchPaperInformation.title}`);
  lines.push(
    `Authors: ${s.researchPaperInformation.authors.join(', ') || 'Not specified in the document'}`,
  );
  lines.push(`Publication Year: ${s.researchPaperInformation.publicationYear}`);
  lines.push(
    `Journal/Conference: ${s.researchPaperInformation.journalOrConference}`,
  );
  lines.push(`DOI: ${s.researchPaperInformation.doi}`);
  lines.push(
    `Keywords: ${s.researchPaperInformation.keywords.join(', ') || 'Not specified in the document'}`,
  );
  lines.push('');

  lines.push('2. ABSTRACT SUMMARY');
  lines.push(sub);
  lines.push(`Original Abstract:\n${s.abstractSummary.originalAbstract}\n`);
  lines.push(`Short Summary:\n${s.abstractSummary.shortSummary}\n`);
  lines.push(`Detailed Summary:\n${s.abstractSummary.detailedSummary}\n`);

  lines.push('3. INTRODUCTION');
  lines.push(sub);
  lines.push(`Main Purpose: ${s.introduction.mainPurpose}`);
  lines.push(`Research Motivation: ${s.introduction.researchMotivation}`);
  pushBullets('Important Contributions', s.introduction.importantContributions);
  lines.push('');

  lines.push('4. RESEARCH PROBLEM');
  lines.push(sub);
  lines.push(`Main Problem: ${s.researchProblem.mainProblem}`);
  lines.push(`Why Problem Exists: ${s.researchProblem.whyProblemExists}`);
  pushBullets('Existing Challenges', s.researchProblem.existingChallenges);
  lines.push(
    `Why Research Is Necessary: ${s.researchProblem.whyResearchNecessary}`,
  );
  lines.push('');

  lines.push('5. RESEARCH OBJECTIVES');
  lines.push(sub);
  if (s.researchObjectives.length === 0) {
    lines.push('  - Not specified in the document');
  } else {
    s.researchObjectives.forEach((o, i) => {
      lines.push(`  ${i + 1}. ${o.objective}`);
      lines.push(`     Explanation: ${o.simpleExplanation}`);
    });
  }
  lines.push('');

  lines.push('6. METHODOLOGY');
  lines.push(sub);
  lines.push(`Research Approach: ${s.methodology.researchApproach}`);
  lines.push(`Proposed Methodology: ${s.methodology.proposedMethodology}`);
  if (s.methodology.workflowSteps.length > 0) {
    lines.push('Workflow Steps:');
    for (const step of s.methodology.workflowSteps) {
      lines.push(`  Step ${step.stepNumber}: ${step.title} — ${step.description}`);
    }
  }
  lines.push(`Implementation Details: ${s.methodology.implementationDetails}`);
  lines.push('');

  lines.push('7. ALGORITHMS AND MODELS');
  lines.push(sub);
  pushBullets('Algorithms Used', s.algorithmsAndModels.algorithmsUsed);
  pushBullets('Machine Learning Models', s.algorithmsAndModels.mlModels);
  pushBullets('Deep Learning Models', s.algorithmsAndModels.dlModels);
  pushBullets('NLP Techniques', s.algorithmsAndModels.nlpTechniques);
  lines.push('');

  lines.push('8. DATASET INFORMATION');
  lines.push(sub);
  if (s.datasetInformation.length === 0) {
    lines.push('Not specified in the document');
  } else {
    for (const ds of s.datasetInformation) {
      lines.push(`Dataset: ${ds.datasetName}`);
      lines.push(`  Source: ${ds.datasetSource}`);
      lines.push(`  Records: ${ds.numberOfRecords}`);
      lines.push(`  Characteristics: ${ds.characteristics}`);
      lines.push(
        `  Preprocessing: ${ds.preprocessingMethods.join(', ') || 'Not specified'}`,
      );
      lines.push(`  Train/Test Details: ${ds.trainTestSplitDetails}`);
    }
  }
  lines.push('');

  lines.push('9. TOOLS AND TECHNOLOGIES');
  lines.push(sub);
  pushBullets(
    'Tools & Technologies',
    s.toolsAndTechnologies.toolsAndTechnologies,
  );
  pushBullets(
    'Software & Libraries',
    s.toolsAndTechnologies.softwareAndLibraries,
  );
  lines.push('');

  lines.push('10. EXPERIMENTAL RESULTS');
  lines.push(sub);
  lines.push(`Experimental Setup: ${s.experimentalResults.experimentalSetup}`);
  pushBullets('Evaluation Methods', s.experimentalResults.evaluationMethods);
  pushBullets(
    'Experimental Findings',
    s.experimentalResults.experimentalFindings,
  );
  if (s.experimentalResults.metricsTable.length > 0) {
    lines.push('Metrics Table:');
    for (const m of s.experimentalResults.metricsTable) {
      lines.push(
        `  * ${m.modelOrAlgorithm} [${m.dataset}] -> Acc: ${m.accuracy ?? '-'}, Prec: ${m.precision ?? '-'}, Rec: ${m.recall ?? '-'}, F1: ${m.f1Score ?? '-'}, MAE: ${m.mae ?? '-'}, RMSE: ${m.rmse ?? '-'} (${m.rawReportedValues})`,
      );
    }
  }
  lines.push('');

  lines.push('11. PERFORMANCE ANALYSIS');
  lines.push(sub);
  lines.push(s.performanceAnalysis.explanation);
  lines.push(`Summary: ${s.performanceAnalysis.performanceMetricsSummary}`);
  lines.push('');

  lines.push('12. STRENGTHS AND LIMITATIONS');
  lines.push(sub);
  pushBullets('Major Strengths', s.strengthsAndLimitations.majorStrengths);
  pushBullets(
    'Technical Advantages',
    s.strengthsAndLimitations.technicalAdvantages,
  );
  pushBullets(
    'Methodological Limitations',
    s.strengthsAndLimitations.methodologicalLimitations,
  );
  pushBullets(
    'Performance Limitations',
    s.strengthsAndLimitations.performanceLimitations,
  );
  pushBullets(
    'Practical Challenges',
    s.strengthsAndLimitations.practicalChallenges,
  );
  lines.push('');

  lines.push('13. RESEARCH GAP');
  lines.push(sub);
  pushBullets(
    'Explicitly Discussed by Authors',
    s.researchGap.authorIdentifiedGaps,
  );
  pushBullets(
    'AI-Generated Research Opportunities (Gemini)',
    s.researchGap.aiSuggestedOpportunities,
  );
  lines.push('');

  lines.push('14. FUTURE SCOPE (AI-GENERATED SUGGESTIONS)');
  lines.push(sub);
  lines.push(`Note: ${s.futureScope.aiGeneratedDisclaimer}`);
  pushBullets('Possible Improvements', s.futureScope.possibleImprovements);
  pushBullets('Alternative Approaches', s.futureScope.alternativeApproaches);
  pushBullets(
    'New Algorithms to Investigate',
    s.futureScope.newAlgorithmsToInvestigate,
  );
  pushBullets('Possible Applications', s.futureScope.possibleApplications);
  pushBullets(
    'Future Research Directions',
    s.futureScope.futureResearchDirections,
  );
  lines.push('');

  lines.push('15. CONCLUSION');
  lines.push(sub);
  lines.push(`AI Final Conclusion:\n${s.conclusion.finalConclusion}\n`);
  lines.push(`Paper Conclusion:\n${s.conclusion.paperConclusion}\n`);

  lines.push('16. REFERENCES');
  lines.push(sub);
  if (s.references.length === 0) {
    lines.push('No bibliographic references extracted.');
  } else {
    s.references.forEach((ref, i) => {
      lines.push(
        `  [${i + 1}] ${ref.authors} (${ref.year}). ${ref.title}. ${ref.doiOrUrl !== 'Not specified in the document' ? ref.doiOrUrl : ''}`,
      );
    });
  }

  return lines.join('\n');
}

async function renderReportPdfFile(
  payload: StructuredReportPayload,
  outPath: string,
): Promise<void> {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: 'A4',
      margin: 50,
      bufferPages: true,
      info: {
        Title: `PaperMind Report - ${payload.sections.researchPaperInformation.title}`,
        Author: 'PaperMind – AI Research Assistant',
      },
    });

    const stream = fs.createWriteStream(outPath);
    doc.pipe(stream);

    const s = payload.sections;
    const navy = '#1E1B4B';
    const purple = '#6D28D9';
    const slate = '#334155';
    const muted = '#64748B';
    const border = '#DDD6FE';

    const ensureSpace = (needed = 80) => {
      if (doc.y + needed > doc.page.height - 65) {
        doc.addPage();
      }
    };

    const sectionHeading = (num: number, title: string) => {
      ensureSpace(65);
      doc.moveDown(0.7);
      doc
        .font('Helvetica-Bold')
        .fontSize(13)
        .fillColor(purple)
        .text(`${num}. ${title}`);
      doc
        .moveTo(50, doc.y + 3)
        .lineTo(doc.page.width - 50, doc.y + 3)
        .lineWidth(0.8)
        .strokeColor(border)
        .stroke();
      doc.moveDown(0.5);
    };

    const bodyParagraph = (label: string | null, text: string) => {
      ensureSpace(40);
      if (label) {
        doc
          .font('Helvetica-Bold')
          .fontSize(10)
          .fillColor(navy)
          .text(`${label}:`, { continued: false });
      }
      doc
        .font('Helvetica')
        .fontSize(10)
        .fillColor(slate)
        .text(text || 'Not specified in the document', {
          align: 'left',
          lineGap: 2,
        });
      doc.moveDown(0.4);
    };

    const bulletList = (label: string, items: string[]) => {
      ensureSpace(45);
      doc.font('Helvetica-Bold').fontSize(10).fillColor(navy).text(`${label}:`);
      if (!items || items.length === 0) {
        doc
          .font('Helvetica')
          .fontSize(10)
          .fillColor(muted)
          .text('• Not specified in the document', { indent: 12 });
      } else {
        for (const item of items) {
          ensureSpace(26);
          doc
            .font('Helvetica')
            .fontSize(10)
            .fillColor(slate)
            .text(`• ${item}`, { indent: 12, lineGap: 1.5 });
        }
      }
      doc.moveDown(0.35);
    };

    // Cover / Title Banner
    doc
      .rect(50, 45, doc.page.width - 100, 82)
      .fillAndStroke('#F5F3FF', '#C4B5FD');
    doc
      .font('Helvetica-Bold')
      .fontSize(10)
      .fillColor(purple)
      .text('PAPERMIND – AI RESEARCH ANALYSIS REPORT', 66, 58);
    doc
      .font('Helvetica-Bold')
      .fontSize(15)
      .fillColor(navy)
      .text(s.researchPaperInformation.title, 66, 76, {
        width: doc.page.width - 132,
        ellipsis: true,
      });
    doc
      .font('Helvetica')
      .fontSize(9)
      .fillColor(muted)
      .text(
        `Source: ${payload.sourceFilename} · ${payload.pageCount} pages · Generated ${new Date(payload.generatedAt).toUTCString()}`,
        66,
        108,
      );

    doc.y = 142;

    sectionHeading(1, 'Research Paper Information');
    bodyParagraph(
      'Authors',
      s.researchPaperInformation.authors.join(', ') ||
        'Not specified in the document',
    );
    bodyParagraph(
      'Publication Year',
      s.researchPaperInformation.publicationYear,
    );
    bodyParagraph(
      'Journal / Conference',
      s.researchPaperInformation.journalOrConference,
    );
    bodyParagraph('DOI', s.researchPaperInformation.doi);
    bodyParagraph(
      'Keywords',
      s.researchPaperInformation.keywords.join(', ') ||
        'Not specified in the document',
    );

    sectionHeading(2, 'Abstract Summary');
    bodyParagraph('Original Abstract', s.abstractSummary.originalAbstract);
    bodyParagraph('Short Summary', s.abstractSummary.shortSummary);
    bodyParagraph('Detailed Summary', s.abstractSummary.detailedSummary);

    sectionHeading(3, 'Introduction');
    bodyParagraph('Main Purpose', s.introduction.mainPurpose);
    bodyParagraph('Research Motivation', s.introduction.researchMotivation);
    bulletList(
      'Important Contributions',
      s.introduction.importantContributions,
    );

    sectionHeading(4, 'Research Problem');
    bodyParagraph('Main Problem', s.researchProblem.mainProblem);
    bodyParagraph('Why the Problem Exists', s.researchProblem.whyProblemExists);
    bulletList('Existing Challenges', s.researchProblem.existingChallenges);
    bodyParagraph(
      'Why Research Is Necessary',
      s.researchProblem.whyResearchNecessary,
    );

    sectionHeading(5, 'Research Objectives');
    if (s.researchObjectives.length === 0) {
      bodyParagraph(null, 'Not specified in the document');
    } else {
      s.researchObjectives.forEach((o, i) => {
        bodyParagraph(`${i + 1}. ${o.objective}`, o.simpleExplanation);
      });
    }

    sectionHeading(6, 'Methodology');
    bodyParagraph('Research Approach', s.methodology.researchApproach);
    bodyParagraph('Proposed Methodology', s.methodology.proposedMethodology);
    if (s.methodology.workflowSteps.length > 0) {
      bulletList(
        'Workflow Steps',
        s.methodology.workflowSteps.map(
          (st) => `Step ${st.stepNumber} (${st.title}): ${st.description}`,
        ),
      );
    }
    bodyParagraph('Implementation Details', s.methodology.implementationDetails);

    sectionHeading(7, 'Algorithms and Models');
    bulletList('Algorithms Used', s.algorithmsAndModels.algorithmsUsed);
    bulletList('Machine Learning Models', s.algorithmsAndModels.mlModels);
    bulletList('Deep Learning Models', s.algorithmsAndModels.dlModels);
    bulletList('NLP Techniques', s.algorithmsAndModels.nlpTechniques);

    sectionHeading(8, 'Dataset Information');
    if (s.datasetInformation.length === 0) {
      bodyParagraph(null, 'Not specified in the document');
    } else {
      for (const ds of s.datasetInformation) {
        bodyParagraph(
          ds.datasetName,
          `Source: ${ds.datasetSource} | Records: ${ds.numberOfRecords} | Characteristics: ${ds.characteristics} | Preprocessing: ${ds.preprocessingMethods.join(', ') || 'None'} | Split: ${ds.trainTestSplitDetails}`,
        );
      }
    }

    sectionHeading(9, 'Tools and Technologies');
    bulletList(
      'Tools & Technologies',
      s.toolsAndTechnologies.toolsAndTechnologies,
    );
    bulletList(
      'Software & Libraries',
      s.toolsAndTechnologies.softwareAndLibraries,
    );

    sectionHeading(10, 'Experimental Results');
    bodyParagraph('Experimental Setup', s.experimentalResults.experimentalSetup);
    bulletList('Evaluation Methods', s.experimentalResults.evaluationMethods);
    bulletList(
      'Experimental Findings',
      s.experimentalResults.experimentalFindings,
    );

    // Formatted Results Table if rows exist
    if (s.experimentalResults.metricsTable.length > 0) {
      ensureSpace(90);
      doc
        .font('Helvetica-Bold')
        .fontSize(10)
        .fillColor(navy)
        .text('Reported Performance Metrics Table:');
      doc.moveDown(0.3);

      const startX = 50;
      const colWidths = [135, 95, 50, 50, 50, 50, 65];
      const headers = ['Model', 'Dataset', 'Acc', 'Prec', 'Rec', 'F1', 'Other'];
      let y = doc.y;

      doc
        .rect(startX, y, doc.page.width - 100, 20)
        .fill('#EDE9FE');
      let x = startX + 4;
      doc.font('Helvetica-Bold').fontSize(8.5).fillColor(navy);
      headers.forEach((h, idx) => {
        doc.text(h, x, y + 6, { width: colWidths[idx] - 6, ellipsis: true });
        x += colWidths[idx];
      });
      y += 22;

      for (const row of s.experimentalResults.metricsTable) {
        if (y > doc.page.height - 75) {
          doc.addPage();
          y = 55;
        }
        doc
          .moveTo(startX, y + 18)
          .lineTo(doc.page.width - 50, y + 18)
          .lineWidth(0.4)
          .strokeColor('#E2E8F0')
          .stroke();

        const vals = [
          row.modelOrAlgorithm,
          row.dataset,
          row.accuracy !== null ? String(row.accuracy) : '-',
          row.precision !== null ? String(row.precision) : '-',
          row.recall !== null ? String(row.recall) : '-',
          row.f1Score !== null ? String(row.f1Score) : '-',
          row.mae !== null || row.rmse !== null
            ? `MAE:${row.mae ?? '-'} RMSE:${row.rmse ?? '-'}`
            : row.otherMetrics,
        ];
        let cx = startX + 4;
        doc.font('Helvetica').fontSize(8).fillColor(slate);
        vals.forEach((val, idx) => {
          doc.text(val, cx, y + 4, {
            width: colWidths[idx] - 6,
            height: 13,
            ellipsis: true,
          });
          cx += colWidths[idx];
        });
        y += 20;
      }
      doc.y = y + 8;
    }

    sectionHeading(11, 'Performance Analysis');
    bodyParagraph('Results Explanation', s.performanceAnalysis.explanation);
    bodyParagraph(
      'Metrics Summary',
      s.performanceAnalysis.performanceMetricsSummary,
    );

    sectionHeading(12, 'Strengths and Limitations');
    bulletList('Major Strengths', s.strengthsAndLimitations.majorStrengths);
    bulletList(
      'Technical Advantages',
      s.strengthsAndLimitations.technicalAdvantages,
    );
    bulletList(
      'Methodological Limitations',
      s.strengthsAndLimitations.methodologicalLimitations,
    );
    bulletList(
      'Performance Limitations',
      s.strengthsAndLimitations.performanceLimitations,
    );
    bulletList(
      'Practical Challenges',
      s.strengthsAndLimitations.practicalChallenges,
    );

    sectionHeading(13, 'Research Gap');
    bulletList(
      'Explicitly Discussed by Authors',
      s.researchGap.authorIdentifiedGaps,
    );
    bulletList(
      'AI-Generated Research Opportunities (Gemini)',
      s.researchGap.aiSuggestedOpportunities,
    );

    sectionHeading(14, 'Future Scope (AI-Generated Suggestions)');
    bodyParagraph('AI Disclosure', s.futureScope.aiGeneratedDisclaimer);
    bulletList('Possible Improvements', s.futureScope.possibleImprovements);
    bulletList('Alternative Approaches', s.futureScope.alternativeApproaches);
    bulletList(
      'New Algorithms to Investigate',
      s.futureScope.newAlgorithmsToInvestigate,
    );
    bulletList('Possible Applications', s.futureScope.possibleApplications);
    bulletList(
      'Future Research Directions',
      s.futureScope.futureResearchDirections,
    );

    sectionHeading(15, 'Conclusion');
    bodyParagraph('Synthesized Conclusion', s.conclusion.finalConclusion);
    bodyParagraph('Original Paper Conclusion', s.conclusion.paperConclusion);

    sectionHeading(16, 'References');
    if (s.references.length === 0) {
      bodyParagraph(null, 'No bibliographic references extracted.');
    } else {
      s.references.forEach((ref, i) => {
        ensureSpace(28);
        doc
          .font('Helvetica')
          .fontSize(9)
          .fillColor(slate)
          .text(
            `[${i + 1}] ${ref.authors} (${ref.year}). ${ref.title}. ${ref.doiOrUrl !== 'Not specified in the document' ? ref.doiOrUrl : ''}`,
            { lineGap: 1.5 },
          );
      });
    }

    // Add page numbers to every page
    const range = doc.bufferedPageRange();
    for (let i = range.start; i < range.start + range.count; i++) {
      doc.switchToPage(i);
      doc
        .font('Helvetica')
        .fontSize(8.5)
        .fillColor(muted)
        .text(
          `PaperMind AI Research Report · Page ${i + 1} of ${range.count}`,
          50,
          doc.page.height - 35,
          { align: 'center', width: doc.page.width - 100 },
        );
    }

    doc.end();
    stream.on('finish', resolve);
    stream.on('error', reject);
  });
}

export async function generateReportFile(
  doc: StoredDocument,
  sessionId: string,
  format: 'pdf' | 'txt' | 'json',
): Promise<{ report: StoredReport; payload: StructuredReportPayload }> {
  const payload = buildStructuredReportPayload(doc);
  const reportId = `rep_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
  const baseSlug = doc.sanitizedFilename.replace(/\.pdf$/i, '');
  const filename = `${baseSlug}_PaperMind_Report.${format}`;
  const outPath = resolveInsideDir(REPORTS_DIR, `${reportId}.${format}`);

  let mimeType = 'application/octet-stream';
  if (format === 'json') {
    mimeType = 'application/json; charset=utf-8';
    fs.writeFileSync(outPath, JSON.stringify(payload, null, 2), 'utf8');
  } else if (format === 'txt') {
    mimeType = 'text/plain; charset=utf-8';
    fs.writeFileSync(outPath, formatReportAsTxt(payload), 'utf8');
  } else {
    mimeType = 'application/pdf';
    await renderReportPdfFile(payload, outPath);
  }

  const now = Date.now();
  const report: StoredReport = {
    reportId,
    documentId: doc.documentId,
    sessionId,
    format,
    filename,
    filePath: outPath,
    mimeType,
    createdAt: now,
    expiresAt: now + DOCUMENT_TTL_MS,
  };
  setReport(report);

  return { report, payload };
}
