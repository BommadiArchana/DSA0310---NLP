import { GoogleGenAI, Type, ThinkingLevel } from '@google/genai';

export { Type, ThinkingLevel };

export const GEMINI_MODEL = 'gemini-4-hydrogen';
export const GEMINI_FAST_MODEL = 'gemini-3.1-flash-lite';

let cachedClient: GoogleGenAI | null = null;

export function isGeminiConfigured(): boolean {
  const key = process.env.GEMINI_API_KEY;
  return Boolean(key && key.trim() && key !== 'MY_GEMINI_API_KEY');
}

export function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || !apiKey.trim() || apiKey === 'MY_GEMINI_API_KEY') {
    throw new GeminiServiceError(
      'GEMINI_API_KEY is not configured on the server. Please configure your Gemini API key in Settings > Secrets.',
      'API_KEY_MISSING',
      503,
    );
  }
  if (!cachedClient) {
    cachedClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return cachedClient;
}

export class GeminiServiceError extends Error {
  code:
    | 'API_KEY_MISSING'
    | 'API_KEY_INVALID'
    | 'RATE_LIMIT'
    | 'TIMEOUT'
    | 'NETWORK_ERROR'
    | 'INVALID_JSON'
    | 'API_FAILURE';
  statusCode: number;

  constructor(
    message: string,
    code: GeminiServiceError['code'],
    statusCode = 502,
  ) {
    super(message);
    this.name = 'GeminiServiceError';
    this.code = code;
    this.statusCode = statusCode;
  }
}

export function classifyGeminiError(err: unknown): GeminiServiceError {
  if (err instanceof GeminiServiceError) return err;

  const rawMsg = err instanceof Error ? err.message : String(err);
  const safeMsg = rawMsg.replace(/AIza[0-9A-Za-z_-]{20,}/g, '[REDACTED_KEY]');

  if (/API_KEY_INVALID|API key not valid|PERMISSION_DENIED|403|401/i.test(safeMsg)) {
    return new GeminiServiceError(
      'Gemini API authentication failed. Please verify GEMINI_API_KEY in Settings > Secrets.',
      'API_KEY_INVALID',
      401,
    );
  }
  if (/RESOURCE_EXHAUSTED|429|rate limit|quota/i.test(safeMsg)) {
    return new GeminiServiceError(
      'Gemini API rate limit or quota exceeded. Please wait a few seconds and retry.',
      'RATE_LIMIT',
      429,
    );
  }
  if (/timed out|timeout|ETIMEDOUT|ABORT_ERR/i.test(safeMsg)) {
    return new GeminiServiceError(
      'The AI analysis request timed out. Please retry.',
      'TIMEOUT',
      504,
    );
  }
  if (/503|UNAVAILABLE|high demand|overloaded/i.test(safeMsg)) {
    return new GeminiServiceError(
      'The Gemini AI model is temporarily experiencing high demand. Please wait a few seconds and click Retry.',
      'API_FAILURE',
      503,
    );
  }
  if (/ECONNREFUSED|ENOTFOUND|ECONNRESET|fetch failed|network/i.test(safeMsg)) {
    return new GeminiServiceError(
      'Network connection failure while contacting Gemini API. Please retry.',
      'NETWORK_ERROR',
      503,
    );
  }

  return new GeminiServiceError(
    `Gemini API processing failed: ${safeMsg.slice(0, 220)}`,
    'API_FAILURE',
    502,
  );
}

export async function callWithRetry<T>(
  fn: (attemptModel: string, attemptThinking: ThinkingLevel) => Promise<T>,
  options: {
    retries?: number;
    timeoutMs?: number;
    signal?: AbortSignal;
    primaryModel?: string;
    fallbackModel?: string;
    onRetry?: (attempt: number, error: GeminiServiceError, nextModel: string) => void;
  } = {},
): Promise<T> {
  const retries = options.retries ?? 1;
  const timeoutMs = options.timeoutMs ?? 45000;
  const primaryModel = options.primaryModel || GEMINI_MODEL;
  const fallbackModel = options.fallbackModel || GEMINI_FAST_MODEL;
  let lastError: unknown;

  for (let attempt = 0; attempt <= retries; attempt++) {
    if (options.signal?.aborted) {
      throw new GeminiServiceError('Analysis was cancelled.', 'API_FAILURE', 499);
    }

    const useFallback = attempt > 0 && Boolean(fallbackModel);
    const attemptModel = useFallback ? fallbackModel : primaryModel;
    const attemptThinking =
      attemptModel === GEMINI_FAST_MODEL
        ? ThinkingLevel.MINIMAL
        : ThinkingLevel.LOW;

    let timeoutId: ReturnType<typeof setTimeout> | undefined;
    try {
      const timeoutPromise = new Promise<never>((_, reject) => {
        timeoutId = setTimeout(
          () => reject(new Error('Request timed out')),
          timeoutMs,
        );
        options.signal?.addEventListener(
          'abort',
          () => {
            if (timeoutId) clearTimeout(timeoutId);
            reject(new Error('Analysis was cancelled.'));
          },
          { once: true },
        );
      });

      const result = await Promise.race([
        fn(attemptModel, attemptThinking),
        timeoutPromise,
      ]);
      if (timeoutId) clearTimeout(timeoutId);
      return result;
    } catch (err) {
      if (timeoutId) clearTimeout(timeoutId);
      lastError = err;
      const classified = classifyGeminiError(err);
      if (
        classified.code === 'API_KEY_MISSING' ||
        classified.code === 'API_KEY_INVALID' ||
        options.signal?.aborted
      ) {
        throw classified;
      }

      if (attempt < retries) {
        const nextModel = fallbackModel || primaryModel;
        options.onRetry?.(attempt + 1, classified, nextModel);
        // Switch immediately if falling back to another model; otherwise brief backoff
        const delayMs = nextModel !== attemptModel ? 300 : 1500;
        await new Promise((r) => setTimeout(r, delayMs));
      }
    }
  }

  throw classifyGeminiError(lastError);
}

export async function streamGenerateContentText(options: {
  model?: string;
  fallbackModel?: string;
  contents: string;
  systemInstruction: string;
  responseMimeType?: string;
  thinkingLevel?: ThinkingLevel;
  firstChunkTimeoutMs?: number;
  totalTimeoutMs?: number;
  retries?: number;
  signal?: AbortSignal;
  onChunk?: (accumulatedText: string) => void;
  onRetry?: (attempt: number, error: GeminiServiceError, nextModel: string) => void;
}): Promise<string> {
  const ai = getGeminiClient();
  const primaryModel = options.model || GEMINI_MODEL;
  const fallbackModel = options.fallbackModel || GEMINI_FAST_MODEL;
  const retries = options.retries ?? 1;
  const firstChunkTimeoutMs = options.firstChunkTimeoutMs ?? 15000;
  const totalTimeoutMs = options.totalTimeoutMs ?? 55000;

  let lastError: unknown;

  for (let attempt = 0; attempt <= retries; attempt++) {
    if (options.signal?.aborted) {
      throw new GeminiServiceError('Analysis was cancelled.', 'API_FAILURE', 499);
    }

    const attemptModel = attempt > 0 ? fallbackModel : primaryModel;
    const attemptThinking =
      attemptModel === GEMINI_FAST_MODEL
        ? ThinkingLevel.MINIMAL
        : (options.thinkingLevel ?? ThinkingLevel.LOW);

    const attemptController = new AbortController();
    const onExternalAbort = () => attemptController.abort();
    options.signal?.addEventListener('abort', onExternalAbort, { once: true });

    let gotAnyChunk = false;
    const firstChunkTimer = setTimeout(() => {
      if (!gotAnyChunk) {
        attemptController.abort(new Error('Request timed out waiting for Gemini'));
      }
    }, firstChunkTimeoutMs);
    const totalTimer = setTimeout(() => {
      attemptController.abort(new Error('Request timed out'));
    }, totalTimeoutMs);

    try {
      const streamPromise = ai.models.generateContentStream({
        model: attemptModel,
        contents: options.contents,
        config: {
          abortSignal: attemptController.signal,
          systemInstruction: options.systemInstruction,
          ...(options.responseMimeType
            ? { responseMimeType: options.responseMimeType }
            : {}),
          thinkingConfig: {
            thinkingLevel: attemptThinking,
          },
        },
      });

      const abortPromise = new Promise<never>((_, reject) => {
        if (attemptController.signal.aborted) {
          reject(
            attemptController.signal.reason || new Error('Request timed out'),
          );
          return;
        }
        attemptController.signal.addEventListener(
          'abort',
          () => {
            reject(
              attemptController.signal.reason || new Error('Request timed out'),
            );
          },
          { once: true },
        );
      });

      const stream = await Promise.race([streamPromise, abortPromise]);

      let fullText = '';
      const iterator = stream[Symbol.asyncIterator]();

      while (true) {
        const nextResult = await Promise.race([iterator.next(), abortPromise]);
        if (nextResult.done) break;
        const piece = nextResult.value?.text ?? '';
        if (piece) {
          if (!gotAnyChunk) {
            gotAnyChunk = true;
            clearTimeout(firstChunkTimer);
          }
          fullText += piece;
          options.onChunk?.(fullText);
        }
      }

      clearTimeout(firstChunkTimer);
      clearTimeout(totalTimer);
      options.signal?.removeEventListener('abort', onExternalAbort);
      return fullText;
    } catch (err) {
      clearTimeout(firstChunkTimer);
      clearTimeout(totalTimer);
      options.signal?.removeEventListener('abort', onExternalAbort);

      lastError = err;
      const classified = classifyGeminiError(err);
      if (
        classified.code === 'API_KEY_MISSING' ||
        classified.code === 'API_KEY_INVALID' ||
        options.signal?.aborted
      ) {
        throw classified;
      }

      if (attempt < retries) {
        options.onRetry?.(attempt + 1, classified, fallbackModel);
        await new Promise((r) => setTimeout(r, 300));
      }
    }
  }

  throw classifyGeminiError(lastError);
}

export function parseStructuredJson<T>(rawText: string | undefined): T {
  if (!rawText || !rawText.trim()) {
    throw new GeminiServiceError(
      'Gemini returned an empty response instead of structured JSON.',
      'INVALID_JSON',
      502,
    );
  }

  let cleaned = rawText.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
  }

  try {
    return JSON.parse(cleaned) as T;
  } catch {
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace > firstBrace) {
      try {
        return JSON.parse(cleaned.slice(firstBrace, lastBrace + 1)) as T;
      } catch {
        // Fall through
      }
    }
    throw new GeminiServiceError(
      'Gemini returned malformed JSON that could not be parsed.',
      'INVALID_JSON',
      502,
    );
  }
}

export function splitDocumentTextForLargePapers(
  pages: Array<{ pageNumber: number; text: string }>,
  maxCharsPerBatch = 140000,
): Array<{ batchIndex: number; pageRange: string; text: string }> {
  const batches: Array<{ batchIndex: number; pageRange: string; text: string }> =
    [];
  let currentText = '';
  let startPage = pages[0]?.pageNumber ?? 1;
  let endPage = startPage;
  let idx = 1;

  for (const page of pages) {
    const pageBlock = `--- [Page ${page.pageNumber}] ---\n${page.text}\n\n`;
    if (
      currentText.length > 0 &&
      currentText.length + pageBlock.length > maxCharsPerBatch
    ) {
      batches.push({
        batchIndex: idx++,
        pageRange: `${startPage}-${endPage}`,
        text: currentText.trim(),
      });
      currentText = pageBlock;
      startPage = page.pageNumber;
      endPage = page.pageNumber;
    } else {
      if (currentText.length === 0) startPage = page.pageNumber;
      currentText += pageBlock;
      endPage = page.pageNumber;
    }
  }

  if (currentText.trim()) {
    batches.push({
      batchIndex: idx,
      pageRange: `${startPage}-${endPage}`,
      text: currentText.trim(),
    });
  }

  return batches;
}
