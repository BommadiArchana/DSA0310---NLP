import type { DocumentChunk, StoredDocument } from '../types.ts';

const STOP_WORDS = new Set([
  'the',
  'is',
  'at',
  'which',
  'on',
  'a',
  'an',
  'and',
  'or',
  'of',
  'to',
  'in',
  'for',
  'with',
  'this',
  'that',
  'what',
  'are',
  'how',
  'why',
  'did',
  'does',
  'do',
  'from',
  'by',
  'be',
  'as',
  'it',
  'its',
  'can',
  'about',
  'paper',
  'research',
  'authors',
  'explain',
  'tell',
  'me',
]);

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 1 && !STOP_WORDS.has(w));
}

export function retrieveRelevantChunks(
  doc: StoredDocument,
  query: string,
  topK = 5,
): DocumentChunk[] {
  const chunks = doc.chunks;
  if (chunks.length <= topK) {
    return chunks;
  }

  const queryTerms = tokenize(query);
  if (queryTerms.length === 0) {
    return chunks.slice(0, topK);
  }

  // Compute document frequency across chunks for IDF weighting
  const df = new Map<string, number>();
  const chunkTokens = chunks.map((chunk) => {
    const tokens = tokenize(`${chunk.section} ${chunk.text}`);
    const unique = new Set(tokens);
    for (const t of unique) {
      df.set(t, (df.get(t) ?? 0) + 1);
    }
    return tokens;
  });

  const N = chunks.length;
  const scored = chunks.map((chunk, idx) => {
    const tokens = chunkTokens[idx];
    const tf = new Map<string, number>();
    for (const t of tokens) {
      tf.set(t, (tf.get(t) ?? 0) + 1);
    }

    let score = 0;
    const sectionLower = chunk.section.toLowerCase();

    for (const qt of queryTerms) {
      const termFreq = tf.get(qt) ?? 0;
      if (termFreq > 0) {
        const docFreq = df.get(qt) ?? 1;
        const idf = Math.log(1 + (N - docFreq + 0.5) / (docFreq + 0.5));
        score += idf * (1 + Math.log(termFreq));
      }
      if (sectionLower.includes(qt)) {
        score += 2.5;
      }
    }

    // Boost abstract / opening chunk lightly for general overview questions
    if (
      /abstract|overview|objective|purpose|beginner|simple|contribution/i.test(
        query,
      ) &&
      chunk.pageStart <= 2
    ) {
      score += 1.5;
    }
    // Boost limitation / future / conclusion queries toward later sections
    if (
      /limit|gap|future|conclu|finding/i.test(query) &&
      /limit|future|conclu|discuss/i.test(chunk.section)
    ) {
      score += 2.5;
    }
    // Boost metrics / dataset / algorithm queries toward matching sections
    if (
      /metric|accuracy|f1|precision|recall|rmse|mae|result|performance/i.test(
        query,
      ) &&
      /result|evaluat|experiment|perform/i.test(chunk.section)
    ) {
      score += 2.5;
    }

    return { chunk, score };
  });

  scored.sort((a, b) => b.score - a.score);
  const selected = scored.slice(0, topK).map((s) => s.chunk);

  // Always preserve chronological page order in returned context
  return selected.sort((a, b) => a.pageStart - b.pageStart);
}
