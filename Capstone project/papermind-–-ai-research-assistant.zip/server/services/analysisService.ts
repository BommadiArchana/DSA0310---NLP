import type {
  AIAnalysisData,
  PerformanceMetricRow,
  SmartExtractionData,
  StoredDocument,
} from '../types.ts';
import {
  ThinkingLevel,
  parseStructuredJson,
  splitDocumentTextForLargePapers,
  streamGenerateContentText,
} from './geminiService.ts';
import { NOT_SPECIFIED } from './extractionService.ts';

function cleanStr(v: unknown, fallback = NOT_SPECIFIED): string {
  if (typeof v !== 'string') return fallback;
  const s = v.trim();
  return s.length > 0 ? s : fallback;
}

function cleanArr(v: unknown): string[] {
  if (!Array.isArray(v)) return [];
  return v
    .filter((i): i is string => typeof i === 'string')
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
}

function cleanNum(v: unknown): number | null {
  if (typeof v === 'number' && Number.isFinite(v)) return v;
  if (typeof v === 'string') {
    const parsed = Number(v.replace(/%$/, '').trim());
    if (v.trim() && Number.isFinite(parsed)) return parsed;
  }
  return null;
}

export function normalizeAnalysis(raw: Partial<AIAnalysisData>): AIAnalysisData {
  const metricsTable: PerformanceMetricRow[] = Array.isArray(
    raw.resultsAnalysis?.metricsTable,
  )
    ? raw.resultsAnalysis.metricsTable
        .filter((row) => row && typeof row === 'object')
        .map((row) => ({
          modelOrAlgorithm: cleanStr(row.modelOrAlgorithm),
          dataset: cleanStr(row.dataset),
          accuracy: cleanNum(row.accuracy),
          precision: cleanNum(row.precision),
          recall: cleanNum(row.recall),
          f1Score: cleanNum(row.f1Score),
          mae: cleanNum(row.mae),
          rmse: cleanNum(row.rmse),
          otherMetrics: cleanStr(row.otherMetrics, 'None reported'),
          rawReportedValues: cleanStr(row.rawReportedValues),
        }))
    : [];

  const numericChartableCount = metricsTable.filter(
    (m) =>
      m.accuracy !== null ||
      m.precision !== null ||
      m.recall !== null ||
      m.f1Score !== null ||
      m.mae !== null ||
      m.rmse !== null,
  ).length;

  return {
    summary: {
      shortSummary: cleanStr(raw.summary?.shortSummary),
      detailedSummary: cleanStr(raw.summary?.detailedSummary),
      mainPurpose: cleanStr(raw.summary?.mainPurpose),
      importantContributions: cleanArr(raw.summary?.importantContributions),
    },
    problemAnalysis: {
      mainProblem: cleanStr(raw.problemAnalysis?.mainProblem),
      whyProblemExists: cleanStr(raw.problemAnalysis?.whyProblemExists),
      existingChallenges: cleanArr(raw.problemAnalysis?.existingChallenges),
      whyResearchNecessary: cleanStr(raw.problemAnalysis?.whyResearchNecessary),
    },
    objectivesExplained: Array.isArray(raw.objectivesExplained)
      ? raw.objectivesExplained
          .filter((o) => o && typeof o === 'object')
          .map((o) => ({
            objective: cleanStr(o.objective),
            simpleExplanation: cleanStr(o.simpleExplanation),
          }))
      : [],
    methodologyAnalysis: {
      researchApproach: cleanStr(raw.methodologyAnalysis?.researchApproach),
      proposedMethodology: cleanStr(
        raw.methodologyAnalysis?.proposedMethodology,
      ),
      algorithmsUsed: cleanArr(raw.methodologyAnalysis?.algorithmsUsed),
      modelsUsed: cleanArr(raw.methodologyAnalysis?.modelsUsed),
      workflowSteps: Array.isArray(raw.methodologyAnalysis?.workflowSteps)
        ? raw.methodologyAnalysis.workflowSteps
            .filter((s) => s && typeof s === 'object')
            .map((s, idx) => ({
              stepNumber:
                typeof s.stepNumber === 'number' ? s.stepNumber : idx + 1,
              title: cleanStr(s.title, `Step ${idx + 1}`),
              description: cleanStr(s.description),
            }))
        : [],
      implementationDetails: cleanStr(
        raw.methodologyAnalysis?.implementationDetails,
      ),
    },
    datasetAnalysis: Array.isArray(raw.datasetAnalysis)
      ? raw.datasetAnalysis
          .filter((d) => d && typeof d === 'object')
          .map((d) => ({
            datasetName: cleanStr(d.datasetName),
            datasetSource: cleanStr(d.datasetSource),
            numberOfRecords: cleanStr(d.numberOfRecords),
            characteristics: cleanStr(d.characteristics),
            preprocessingMethods: cleanArr(d.preprocessingMethods),
            trainTestSplitDetails: cleanStr(d.trainTestSplitDetails),
          }))
      : [],
    resultsAnalysis: {
      metricsTable,
      hasSufficientNumericalDataForChart:
        Boolean(raw.resultsAnalysis?.hasSufficientNumericalDataForChart) &&
        numericChartableCount >= 1,
      chartMetricUnit: cleanStr(
        raw.resultsAnalysis?.chartMetricUnit,
        'Reported units',
      ),
      explanation: cleanStr(raw.resultsAnalysis?.explanation),
    },
    strengthsAndWeaknesses: {
      majorStrengths: cleanArr(raw.strengthsAndWeaknesses?.majorStrengths),
      technicalAdvantages: cleanArr(
        raw.strengthsAndWeaknesses?.technicalAdvantages,
      ),
      methodologicalLimitations: cleanArr(
        raw.strengthsAndWeaknesses?.methodologicalLimitations,
      ),
      performanceLimitations: cleanArr(
        raw.strengthsAndWeaknesses?.performanceLimitations,
      ),
      practicalChallenges: cleanArr(
        raw.strengthsAndWeaknesses?.practicalChallenges,
      ),
    },
    researchGaps: {
      authorIdentifiedGaps: cleanArr(raw.researchGaps?.authorIdentifiedGaps),
      aiSuggestedOpportunities: cleanArr(
        raw.researchGaps?.aiSuggestedOpportunities,
      ),
    },
    futureScope: {
      aiGeneratedDisclaimer: cleanStr(
        raw.futureScope?.aiGeneratedDisclaimer,
        'AI-Generated Research Suggestions (Gemini): These recommendations extend beyond explicit author statements and should be evaluated by domain researchers.',
      ),
      possibleImprovements: cleanArr(raw.futureScope?.possibleImprovements),
      alternativeApproaches: cleanArr(raw.futureScope?.alternativeApproaches),
      newAlgorithmsToInvestigate: cleanArr(
        raw.futureScope?.newAlgorithmsToInvestigate,
      ),
      possibleApplications: cleanArr(raw.futureScope?.possibleApplications),
      futureResearchDirections: cleanArr(
        raw.futureScope?.futureResearchDirections,
      ),
    },
    finalConclusion: cleanStr(raw.finalConclusion),
  };
}

export async function runDeepAnalysis(
  doc: StoredDocument,
  extraction: SmartExtractionData,
  onStatusUpdate?: (msg: string) => void,
  signal?: AbortSignal,
): Promise<AIAnalysisData> {
  const batches = splitDocumentTextForLargePapers(doc.pages, 160000);

  let paperContextText = '';
  if (batches.length === 1) {
    paperContextText = batches[0].text;
  } else {
    onStatusUpdate?.(
      `Synthesizing ${batches.length} large document sections in parallel...`,
    );
    const digests = await Promise.all(
      batches.map(async (batch) => {
        const text = await streamGenerateContentText({
          contents: `Summarize all key academic details, methodology steps, datasets, exact numerical metrics, limitations, and gaps from pages ${batch.pageRange} while preserving exact numbers and page references:\n\n${batch.text}`,
          systemInstruction:
            'Summarize academic paper sections concisely while preserving exact numbers and metrics.',
          thinkingLevel: ThinkingLevel.LOW,
          totalTimeoutMs: 55000,
          retries: 1,
          signal,
        });
        return `=== SECTION DIGEST (Pages ${batch.pageRange}) ===\n${text}`;
      }),
    );
    paperContextText = digests.join('\n\n');
  }

  onStatusUpdate?.(
    'Generating structured research analysis, metrics evaluation, and research gap insights...',
  );

  const prompt = `Analyze this research paper in clear, concise academic English strictly grounded in the paper content and verified extraction facts below.

STRICT RULES:
1. Base every claim, dataset detail, and metric strictly on the paper. Use "${NOT_SPECIFIED}" for unstated string fields and null for missing numeric metrics.
2. Keep prose crisp and direct (1-3 sentences per string field, 3-5 concise items per array) for fast readability.
3. For Research Gaps: separate "authorIdentifiedGaps" (explicitly stated by authors) from "aiSuggestedOpportunities" (Gemini-suggested opportunities).
4. Set hasSufficientNumericalDataForChart = true ONLY when metricsTable contains numeric values reported in the paper.

Return valid JSON matching this schema:
{
  "summary": { "shortSummary": "", "detailedSummary": "", "mainPurpose": "", "importantContributions": [] },
  "problemAnalysis": { "mainProblem": "", "whyProblemExists": "", "existingChallenges": [], "whyResearchNecessary": "" },
  "objectivesExplained": [{ "objective": "", "simpleExplanation": "" }],
  "methodologyAnalysis": { "researchApproach": "", "proposedMethodology": "", "algorithmsUsed": [], "modelsUsed": [], "workflowSteps": [{ "stepNumber": 1, "title": "", "description": "" }], "implementationDetails": "" },
  "datasetAnalysis": [{ "datasetName": "", "datasetSource": "", "numberOfRecords": "", "characteristics": "", "preprocessingMethods": [], "trainTestSplitDetails": "" }],
  "resultsAnalysis": { "metricsTable": [{ "modelOrAlgorithm": "", "dataset": "", "accuracy": null, "precision": null, "recall": null, "f1Score": null, "mae": null, "rmse": null, "otherMetrics": "", "rawReportedValues": "" }], "hasSufficientNumericalDataForChart": false, "chartMetricUnit": "", "explanation": "" },
  "strengthsAndWeaknesses": { "majorStrengths": [], "technicalAdvantages": [], "methodologicalLimitations": [], "performanceLimitations": [], "practicalChallenges": [] },
  "researchGaps": { "authorIdentifiedGaps": [], "aiSuggestedOpportunities": [] },
  "futureScope": { "aiGeneratedDisclaimer": "AI-Generated Research Suggestions (Gemini): These recommendations extend beyond explicit author statements and should be evaluated by domain researchers.", "possibleImprovements": [], "alternativeApproaches": [], "newAlgorithmsToInvestigate": [], "possibleApplications": [], "futureResearchDirections": [] },
  "finalConclusion": ""
}

VERIFIED EXTRACTION SUMMARY:
${JSON.stringify({
  title: extraction.generalInfo.title,
  authors: extraction.generalInfo.authors,
  year: extraction.generalInfo.publicationYear,
  datasets: extraction.technicalInfo.datasetNames,
  algorithms: extraction.technicalInfo.algorithmsUsed,
  experimentalInfo: extraction.experimentalInfo,
})}

FULL PAPER CONTENT (${doc.pageCount} pages):
${paperContextText}`;

  const rawText = await streamGenerateContentText({
    contents: prompt,
    systemInstruction:
      'You are PaperMind, an expert academic research analyst. Write clear, concise structured JSON analysis grounded strictly in the uploaded paper.',
    responseMimeType: 'application/json',
    thinkingLevel: ThinkingLevel.LOW,
    totalTimeoutMs: 60000,
    retries: 1,
    signal,
  });

  const parsed = parseStructuredJson<Partial<AIAnalysisData>>(rawText);
  return normalizeAnalysis(parsed);
}
