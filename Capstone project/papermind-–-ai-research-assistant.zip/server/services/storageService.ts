import fs from 'node:fs';
import path from 'node:path';
import type { AnalysisJob, StoredDocument, StoredReport } from '../types.ts';
import { resolveInsideDir } from '../utils/security.ts';

const WORKSPACE_ROOT = process.cwd();
export const UPLOADS_DIR = path.resolve(WORKSPACE_ROOT, 'uploads');
export const REPORTS_DIR = path.resolve(WORKSPACE_ROOT, 'reports');
export const DOCUMENT_TTL_MS = 3 * 60 * 60 * 1000; // 3 hours
export const MAX_UPLOAD_BYTES =
  Number(process.env.MAX_UPLOAD_MB || 25) * 1024 * 1024;

function ensureDirs(): void {
  if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  }
  if (!fs.existsSync(REPORTS_DIR)) {
    fs.mkdirSync(REPORTS_DIR, { recursive: true });
  }
}

ensureDirs();

const documents = new Map<string, StoredDocument>();
const jobs = new Map<string, AnalysisJob>();
const reports = new Map<string, StoredReport>();

export function saveUploadedPdfBuffer(
  documentId: string,
  buffer: Buffer,
): string {
  ensureDirs();
  const safeFile = `${documentId}.pdf`;
  const targetPath = resolveInsideDir(UPLOADS_DIR, safeFile);
  fs.writeFileSync(targetPath, buffer);
  return targetPath;
}

export function setDocument(doc: StoredDocument): void {
  documents.set(doc.documentId, doc);
}

export function getDocumentForSession(
  documentId: string,
  sessionId: string,
): { doc?: StoredDocument; reason?: 'not_found' | 'expired' | 'forbidden' } {
  const doc = documents.get(documentId);
  if (!doc) {
    return { reason: 'not_found' };
  }
  if (Date.now() > doc.expiresAt) {
    removeFileQuietly(doc.filePath);
    documents.delete(documentId);
    return { reason: 'expired' };
  }
  if (doc.sessionId !== sessionId) {
    return { reason: 'forbidden' };
  }
  return { doc };
}

export function listDocumentsForSession(sessionId: string): StoredDocument[] {
  const now = Date.now();
  const list: StoredDocument[] = [];
  for (const [id, doc] of documents.entries()) {
    if (now > doc.expiresAt) {
      removeFileQuietly(doc.filePath);
      documents.delete(id);
      continue;
    }
    if (doc.sessionId === sessionId) {
      list.push(doc);
    }
  }
  return list.sort((a, b) => b.createdAt - a.createdAt);
}

export function deleteDocumentForSession(
  documentId: string,
  sessionId: string,
): { deleted: boolean; fileDeleted: boolean; reason?: 'not_found' | 'forbidden' } {
  const doc = documents.get(documentId);
  if (!doc) {
    return { deleted: false, fileDeleted: false, reason: 'not_found' };
  }
  if (doc.sessionId !== sessionId) {
    return { deleted: false, fileDeleted: false, reason: 'forbidden' };
  }

  let fileDeleted = false;
  if (doc.filePath) {
    fileDeleted = removeFileVerified(doc.filePath);
  }

  // Also clean up any jobs and reports linked to this document
  for (const [jobId, job] of jobs.entries()) {
    if (job.documentId === documentId) {
      job.cancelled = true;
      jobs.delete(jobId);
    }
  }
  for (const [repId, rep] of reports.entries()) {
    if (rep.documentId === documentId) {
      removeFileQuietly(rep.filePath);
      reports.delete(repId);
    }
  }

  documents.delete(documentId);
  return { deleted: true, fileDeleted };
}

export function setJob(job: AnalysisJob): void {
  jobs.set(job.jobId, job);
}

export function getJobForSession(
  jobId: string,
  sessionId: string,
): AnalysisJob | null {
  const job = jobs.get(jobId);
  if (!job || job.sessionId !== sessionId) return null;
  return job;
}

export function findActiveJobForDocument(
  documentId: string,
  sessionId: string,
): AnalysisJob | null {
  for (const job of jobs.values()) {
    if (
      job.documentId === documentId &&
      job.sessionId === sessionId &&
      (job.status === 'queued' || job.status === 'running')
    ) {
      return job;
    }
  }
  return null;
}

export function setReport(report: StoredReport): void {
  reports.set(report.reportId, report);
}

export function getReportForSession(
  reportId: string,
  sessionId: string,
): { report?: StoredReport; reason?: 'not_found' | 'expired' | 'forbidden' } {
  const report = reports.get(reportId);
  if (!report) {
    return { reason: 'not_found' };
  }
  if (Date.now() > report.expiresAt) {
    removeFileQuietly(report.filePath);
    reports.delete(reportId);
    return { reason: 'expired' };
  }
  if (report.sessionId !== sessionId) {
    return { reason: 'forbidden' };
  }
  return { report };
}

function removeFileVerified(filePath: string): boolean {
  try {
    if (!fs.existsSync(filePath)) {
      return true;
    }
    fs.unlinkSync(filePath);
    return !fs.existsSync(filePath);
  } catch {
    return false;
  }
}

function removeFileQuietly(filePath: string): void {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch {
    // Ignore cleanup errors during background sweep
  }
}

export function cleanupExpiredAssets(): void {
  const now = Date.now();
  for (const [id, doc] of documents.entries()) {
    if (now > doc.expiresAt) {
      removeFileQuietly(doc.filePath);
      documents.delete(id);
    }
  }
  for (const [id, rep] of reports.entries()) {
    if (now > rep.expiresAt) {
      removeFileQuietly(rep.filePath);
      reports.delete(id);
    }
  }
  for (const [id, job] of jobs.entries()) {
    if (now - job.updatedAt > DOCUMENT_TTL_MS) {
      jobs.delete(id);
    }
  }
}

// Run cleanup sweep every 15 minutes
const sweepTimer = setInterval(cleanupExpiredAssets, 15 * 60 * 1000);
if (typeof sweepTimer.unref === 'function') {
  sweepTimer.unref();
}
