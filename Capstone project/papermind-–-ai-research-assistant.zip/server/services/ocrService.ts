import { PNG } from 'pngjs';
import { createWorker } from 'tesseract.js';

interface PdfImageObject {
  width?: number;
  height?: number;
  kind?: number; // 1 = GRAYSCALE_1BPP, 2 = RGB_24BPP, 3 = RGBA_32BPP
  data?: Uint8Array | Uint8ClampedArray;
}

function encodePdfImageToPngBuffer(img: PdfImageObject): Buffer | null {
  if (!img || !img.width || !img.height || !img.data) return null;
  const { width, height, data } = img;
  if (width < 32 || height < 32) return null; // Skip tiny decorative icons

  const png = new PNG({ width, height });
  const totalPixels = width * height;

  if (data.length === totalPixels * 4) {
    // RGBA_32BPP
    for (let i = 0; i < totalPixels * 4; i++) {
      png.data[i] = data[i];
    }
  } else if (data.length === totalPixels * 3) {
    // RGB_24BPP
    for (let p = 0; p < totalPixels; p++) {
      const srcIdx = p * 3;
      const dstIdx = p * 4;
      png.data[dstIdx] = data[srcIdx];
      png.data[dstIdx + 1] = data[srcIdx + 1];
      png.data[dstIdx + 2] = data[srcIdx + 2];
      png.data[dstIdx + 3] = 255;
    }
  } else if (data.length === totalPixels) {
    // 8-bit grayscale
    for (let p = 0; p < totalPixels; p++) {
      const dstIdx = p * 4;
      const g = data[p];
      png.data[dstIdx] = g;
      png.data[dstIdx + 1] = g;
      png.data[dstIdx + 2] = g;
      png.data[dstIdx + 3] = 255;
    }
  } else if (data.length === Math.ceil(width / 8) * height) {
    // 1bpp monochrome scanned image
    const rowBytes = Math.ceil(width / 8);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const byteVal = data[y * rowBytes + (x >> 3)];
        const bit = (byteVal >> (7 - (x & 7))) & 1;
        const val = bit ? 255 : 0;
        const dstIdx = (y * width + x) * 4;
        png.data[dstIdx] = val;
        png.data[dstIdx + 1] = val;
        png.data[dstIdx + 2] = val;
        png.data[dstIdx + 3] = 255;
      }
    }
  } else {
    return null;
  }

  return PNG.sync.write(png);
}

export interface OcrPageTask {
  pageNumber: number;
  imageBuffers: Buffer[];
}

export async function extractPageImagesForOcr(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  page: any,
  OPS: Record<string, number>,
): Promise<Buffer[]> {
  const buffers: Buffer[] = [];
  try {
    const opList = await page.getOperatorList();
    const seenNames = new Set<string>();

    for (let i = 0; i < opList.fnArray.length; i++) {
      const fn = opList.fnArray[i];
      if (
        fn === OPS.paintImageXObject ||
        fn === OPS.paintImageXObjectRepeat ||
        fn === OPS.paintJpegXObject
      ) {
        const args = opList.argsArray[i];
        const imgName = typeof args?.[0] === 'string' ? args[0] : null;
        if (!imgName || seenNames.has(imgName)) continue;
        seenNames.add(imgName);

        try {
          const imgObj = await new Promise<PdfImageObject | null>((resolve) => {
            const timeout = setTimeout(() => resolve(null), 1500);
            try {
              page.objs.get(imgName, (obj: PdfImageObject) => {
                clearTimeout(timeout);
                resolve(obj || null);
              });
            } catch {
              clearTimeout(timeout);
              resolve(null);
            }
          });
          if (imgObj) {
            const pngBuf = encodePdfImageToPngBuffer(imgObj);
            if (pngBuf) {
              buffers.push(pngBuf);
            }
          }
        } catch {
          // Skip unreadable image object
        }
      }
    }
  } catch {
    // Ignore operator list inspection failures
  }
  return buffers;
}

export async function runOcrOnImageBuffers(
  tasks: OcrPageTask[],
): Promise<Map<number, { text: string; error?: string }>> {
  const results = new Map<number, { text: string; error?: string }>();
  if (tasks.length === 0) return results;

  let worker: Awaited<ReturnType<typeof createWorker>> | null = null;
  try {
    worker = await createWorker('eng');
    for (const task of tasks) {
      if (task.imageBuffers.length === 0) {
        results.set(task.pageNumber, {
          text: '',
          error:
            'No raster image layer was extractable for OCR on this page.',
        });
        continue;
      }

      const pageTexts: string[] = [];
      for (const imgBuf of task.imageBuffers.slice(0, 4)) {
        try {
          const ocrPromise = worker.recognize(imgBuf);
          const timeoutPromise = new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('OCR timeout on page')), 25000),
          );
          const {
            data: { text },
          } = await Promise.race([ocrPromise, timeoutPromise]);
          if (text && text.trim()) {
            pageTexts.push(text.trim());
          }
        } catch (err) {
          const msg =
            err instanceof Error ? err.message : 'OCR recognition failed';
          results.set(task.pageNumber, { text: '', error: msg });
        }
      }

      const combined = pageTexts.join('\n').trim();
      if (combined) {
        results.set(task.pageNumber, { text: combined });
      } else if (!results.has(task.pageNumber)) {
        results.set(task.pageNumber, {
          text: '',
          error: 'OCR produced no readable text on this page.',
        });
      }
    }
  } catch (err) {
    const msg =
      err instanceof Error
        ? err.message
        : 'OCR engine could not be initialized.';
    for (const task of tasks) {
      if (!results.has(task.pageNumber)) {
        results.set(task.pageNumber, { text: '', error: msg });
      }
    }
  } finally {
    if (worker) {
      try {
        await worker.terminate();
      } catch {
        // Ignore termination errors
      }
    }
  }

  return results;
}
