import crypto from 'node:crypto';
import type { ChatMessage, StoredDocument } from '../types.ts';
import {
  GEMINI_FAST_MODEL,
  GEMINI_MODEL,
  ThinkingLevel,
  classifyGeminiError,
  getGeminiClient,
} from './geminiService.ts';
import { retrieveRelevantChunks } from './retrievalService.ts';

export const INSUFFICIENT_INFO_MSG =
  'The uploaded research paper does not provide sufficient information to answer this question.';

function buildChatSystemInstruction(doc: StoredDocument): string {
  const title =
    doc.extraction?.generalInfo.title || doc.originalFilename;
  const authors =
    doc.extraction?.generalInfo.authors?.join(', ') || 'Not specified';
  const year = doc.extraction?.generalInfo.publicationYear || 'Not specified';

  return `You are PaperMind, an academic AI research assistant answering questions strictly about the uploaded research paper:
Title: ${title}
Authors: ${authors}
Publication Year: ${year}
Total Pages: ${doc.pageCount}

STRICT GROUNDING RULES:
1. Answer ONLY using the provided retrieved paper passages and structured paper summary below.
2. When citing facts, results, or quotes, reference the source page numbers in parentheses like (Page 3) or (Pages 4-5).
3. If the answer cannot be found or reasonably inferred from the uploaded research paper passages, respond with this exact sentence:
"${INSUFFICIENT_INFO_MSG}"
4. Never invent metrics, authors, datasets, citations, or claims not present in the paper.
5. Support follow-up questions naturally using the conversation history while staying strictly anchored to this paper.`;
}

function buildUserContextPrompt(
  doc: StoredDocument,
  question: string,
): { prompt: string; sourcePages: number[] } {
  const chunks = retrieveRelevantChunks(doc, question, 6);
  const pageSet = new Set<number>();
  for (const ch of chunks) {
    for (let p = ch.pageStart; p <= ch.pageEnd; p++) {
      pageSet.add(p);
    }
  }
  const sourcePages = Array.from(pageSet).sort((a, b) => a - b);

  const structuredDigest = doc.extraction
    ? `PAPER SUMMARY METADATA:
- Title: ${doc.extraction.generalInfo.title}
- Abstract: ${doc.extraction.generalInfo.abstract}
- Research Problem: ${doc.extraction.researchInfo.researchProblem}
- Objectives: ${doc.extraction.researchInfo.researchObjectives.join('; ')}
- Algorithms/Models: ${[...doc.extraction.technicalInfo.algorithmsUsed, ...doc.extraction.technicalInfo.mlModels, ...doc.extraction.technicalInfo.dlModels].join(', ') || 'None listed'}
- Datasets: ${doc.extraction.technicalInfo.datasetNames.join(', ') || 'None listed'}
- Key Findings: ${doc.extraction.conclusions.keyFindings.join('; ') || 'None listed'}
- Limitations: ${doc.extraction.conclusions.limitations.join('; ') || 'None listed'}`
    : '';

  const passagesText = chunks
    .map(
      (c) =>
        `[Section: ${c.section} | Pages ${c.pageStart}${c.pageEnd !== c.pageStart ? `-${c.pageEnd}` : ''}]\n${c.text}`,
    )
    .join('\n\n---\n\n');

  const prompt = `${structuredDigest}

RETRIEVED PAPER PASSAGES:
${passagesText}

USER QUESTION:
${question}`;

  return { prompt, sourcePages };
}

export async function* streamChatResponse(
  doc: StoredDocument,
  question: string,
): AsyncGenerator<
  | { type: 'meta'; sourcePages: number[] }
  | { type: 'chunk'; text: string }
  | { type: 'done'; message: ChatMessage },
  void,
  unknown
> {
  const ai = getGeminiClient();
  const { prompt, sourcePages } = buildUserContextPrompt(doc, question);

  const userMsg: ChatMessage = {
    id: crypto.randomUUID(),
    role: 'user',
    content: question,
    timestamp: new Date().toISOString(),
  };
  doc.chatHistory.push(userMsg);

  // Preserve recent conversation turns (excluding the latest just-pushed user message)
  const priorHistory = doc.chatHistory.slice(-11, -1).map((m) => ({
    role: m.role === 'user' ? ('user' as const) : ('model' as const),
    parts: [{ text: m.content }],
  }));

  yield { type: 'meta', sourcePages };

  try {
    let fullReply = '';

    const tryYieldStream = async function* (
      modelName: string,
      thinkingLevel: ThinkingLevel,
    ) {
      const controller = new AbortController();
      let gotFirst = false;
      const firstTimer = setTimeout(() => {
        if (!gotFirst) controller.abort(new Error('Request timed out'));
      }, 12000);

      try {
        const stream = await ai.models.generateContentStream({
          model: modelName,
          contents: [
            ...priorHistory,
            { role: 'user', parts: [{ text: prompt }] },
          ],
          config: {
            abortSignal: controller.signal,
            systemInstruction: buildChatSystemInstruction(doc),
            thinkingConfig: { thinkingLevel },
          },
        });

        for await (const chunk of stream) {
          const piece = chunk.text ?? '';
          if (piece) {
            if (!gotFirst) {
              gotFirst = true;
              clearTimeout(firstTimer);
            }
            fullReply += piece;
            yield piece;
          }
        }
      } finally {
        clearTimeout(firstTimer);
      }
    };

    try {
      for await (const piece of tryYieldStream(GEMINI_MODEL, ThinkingLevel.LOW)) {
        yield { type: 'chunk', text: piece };
      }
    } catch (primaryErr) {
      const classified = classifyGeminiError(primaryErr);
      if (
        fullReply.length > 0 ||
        classified.code === 'API_KEY_MISSING' ||
        classified.code === 'API_KEY_INVALID'
      ) {
        throw primaryErr;
      }
      for await (const piece of tryYieldStream(
        GEMINI_FAST_MODEL,
        ThinkingLevel.MINIMAL,
      )) {
        yield { type: 'chunk', text: piece };
      }
    }

    const finalContent = fullReply.trim() || INSUFFICIENT_INFO_MSG;
    // Extract explicitly mentioned page numbers if present, else fallback to retrieved pages
    const mentionedPages = new Set<number>();
    const pageMatches = finalContent.matchAll(/Page(?:s)?\s+(\d+)(?:\s*-\s*(\d+))?/gi);
    for (const match of pageMatches) {
      const start = Number(match[1]);
      const end = match[2] ? Number(match[2]) : start;
      if (Number.isFinite(start) && start >= 1 && start <= doc.pageCount) {
        for (let p = start; p <= Math.min(end, doc.pageCount); p++) {
          mentionedPages.add(p);
        }
      }
    }

    const citedPages =
      finalContent === INSUFFICIENT_INFO_MSG
        ? []
        : mentionedPages.size > 0
          ? Array.from(mentionedPages).sort((a, b) => a - b)
          : sourcePages.slice(0, 4);

    const assistantMsg: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'assistant',
      content: finalContent,
      sourcePages: citedPages,
      timestamp: new Date().toISOString(),
    };
    doc.chatHistory.push(assistantMsg);

    yield { type: 'done', message: assistantMsg };
  } catch (err) {
    // Roll back the dangling user message if generation failed so user can retry cleanly
    if (
      doc.chatHistory.length > 0 &&
      doc.chatHistory[doc.chatHistory.length - 1].id === userMsg.id
    ) {
      doc.chatHistory.pop();
    }
    throw classifyGeminiError(err);
  }
}
