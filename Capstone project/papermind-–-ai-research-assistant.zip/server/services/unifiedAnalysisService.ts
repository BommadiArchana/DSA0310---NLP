import type {
  AIAnalysisData,
  SmartExtractionData,
  StoredDocument,
} from '../types.ts';
import {
  ThinkingLevel,
  parseStructuredJson,
  splitDocumentTextForLargePapers,
  streamGenerateContentText,
} from './geminiService.ts';
import {
  NOT_SPECIFIED,
  extractReferencesFromPages,
  normalizeExtraction,
} from './extractionService.ts';
import { normalizeAnalysis } from './analysisService.ts';

export interface UnifiedAnalysisProgress {
  phase: 'extracting' | 'analyzing';
  progress: number;
  message: string;
}

export async function runUnifiedPaperAnalysis(
  doc: StoredDocument,
  onProgress?: (update: UnifiedAnalysisProgress) => void,
  signal?: AbortSignal,
): Promise<{ extraction: SmartExtractionData; analysis: AIAnalysisData }> {
  const tStart = Date.now();
  const parsedRefs = extractReferencesFromPages(doc.pages);
  const batches = splitDocumentTextForLargePapers(doc.pages, 150000);

  let paperContextText = '';
  if (batches.length === 1) {
    paperContextText = batches[0].text;
  } else {
    onProgress?.({
      phase: 'extracting',
      progress: 38,
      message: `Synthesizing ${batches.length} sections of this ${doc.pageCount}-page document in parallel...`,
    });

    const digests = await Promise.all(
      batches.map(async (batch) => {
        const text = await streamGenerateContentText({
          contents: `Extract and summarize all metadata, research objectives, methodology steps, algorithms, datasets, exact numerical metrics, author-stated limitations, and key conclusions from pages ${batch.pageRange} while preserving exact numbers and page numbers:\n\n${batch.text}`,
          systemInstruction:
            'Summarize academic paper sections concisely while preserving exact entities, datasets, and numerical metrics.',
          thinkingLevel: ThinkingLevel.LOW,
          totalTimeoutMs: 55000,
          retries: 1,
          signal,
        });
        return `=== PAGES ${batch.pageRange} DIGEST ===\n${text}`;
      }),
    );

    const openingPages = doc.pages
      .slice(0, 2)
      .map((p) => `--- [Page ${p.pageNumber}] ---\n${p.text}`)
      .join('\n\n');
    paperContextText = `${openingPages}\n\n${digests.join('\n\n')}`;
  }

  const refInstruction =
    parsedRefs.length > 0
      ? 'Set "extraction.references" to [] (references have already been extracted deterministically).'
      : 'Populate "extraction.references" with up to 12 key cited references explicitly found in this paper (or [] if none are listed).';

  const prompt = `Analyze the uploaded research paper (${doc.pageCount} pages, file: "${doc.originalFilename}") and return BOTH structured extraction ("extraction") and deep academic analysis ("analysis") in a single valid JSON object.

STRICT GROUNDING & CONCISENESS RULES:
1. Never invent or extrapolate authors, years, DOIs, datasets, sample counts, or performance metrics.
2. For any unstated string field in "extraction" or "analysis", set it strictly to "${NOT_SPECIFIED}". For unstated arrays, use []. For missing numerical metrics in "metricsTable", use null.
3. Keep all narrative strings crisp and concise (1-2 clear sentences per field) and arrays concise (3-5 bullet items) while preserving exact reported metrics and units.
4. Separate "researchGaps.authorIdentifiedGaps" (stated explicitly by the authors) from "researchGaps.aiSuggestedOpportunities" (suggested by Gemini based on methodology).
5. Set "resultsAnalysis.hasSufficientNumericalDataForChart" to true ONLY if "metricsTable" contains explicit numeric values reported in the paper.
6. ${refInstruction}

Return valid JSON matching this exact top-level structure:
{
  "extraction": {
    "generalInfo": { "title": "", "authors": [], "publicationYear": "", "journalOrConference": "", "doi": "", "abstract": "", "keywords": [] },
    "researchInfo": { "researchProblem": "", "researchObjectives": [], "researchQuestions": [], "researchMotivation": "", "existingSystem": "", "proposedSystem": "", "researchContributions": [] },
    "technicalInfo": { "researchMethodology": "", "algorithmsUsed": [], "mlModels": [], "dlModels": [], "nlpTechniques": [], "datasetNames": [], "datasetDescriptions": [], "toolsAndTechnologies": [], "softwareAndLibraries": [] },
    "experimentalInfo": { "experimentalSetup": "", "evaluationMethods": [], "performanceMetricsSummary": "", "accuracy": "", "precision": "", "recall": "", "f1Score": "", "mae": "", "rmse": "", "otherMeasurements": [], "experimentalFindings": [] },
    "conclusions": { "keyFindings": [], "strengths": [], "limitations": [], "challenges": [], "futureScope": [], "conclusion": "" },
    "references": [{ "title": "", "authors": "", "year": "", "doiOrUrl": "" }]
  },
  "analysis": {
    "summary": { "shortSummary": "", "detailedSummary": "", "mainPurpose": "", "importantContributions": [] },
    "problemAnalysis": { "mainProblem": "", "whyProblemExists": "", "existingChallenges": [], "whyResearchNecessary": "" },
    "objectivesExplained": [{ "objective": "", "simpleExplanation": "" }],
    "methodologyAnalysis": { "researchApproach": "", "proposedMethodology": "", "algorithmsUsed": [], "modelsUsed": [], "workflowSteps": [{ "stepNumber": 1, "title": "", "description": "" }], "implementationDetails": "" },
    "datasetAnalysis": [{ "datasetName": "", "datasetSource": "", "numberOfRecords": "", "characteristics": "", "preprocessingMethods": [], "trainTestSplitDetails": "" }],
    "resultsAnalysis": { "metricsTable": [{ "modelOrAlgorithm": "", "dataset": "", "accuracy": null, "precision": null, "recall": null, "f1Score": null, "mae": null, "rmse": null, "otherMetrics": "", "rawReportedValues": "" }], "hasSufficientNumericalDataForChart": false, "chartMetricUnit": "", "explanation": "" },
    "strengthsAndWeaknesses": { "majorStrengths": [], "technicalAdvantages": [], "methodologicalLimitations": [], "performanceLimitations": [], "practicalChallenges": [] },
    "researchGaps": { "authorIdentifiedGaps": [], "aiSuggestedOpportunities": [] },
    "futureScope": { "aiGeneratedDisclaimer": "AI-Generated Research Suggestions (Gemini): These recommendations extend beyond explicit author statements and should be evaluated by domain researchers.", "possibleImprovements": [], "alternativeApproaches": [], "newAlgorithmsToInvestigate": [], "possibleApplications": [], "futureResearchDirections": [] },
    "finalConclusion": ""
  }
}

RESEARCH PAPER CONTENT:
${paperContextText}`;

  let switchedToAnalysis = false;
  let lastProgressAt = 0;

  onProgress?.({
    phase: 'extracting',
    progress: 34,
    message: 'Extracting metadata, objectives, methodology & datasets...',
  });

  const rawText = await streamGenerateContentText({
    contents: prompt,
    systemInstruction:
      'You are PaperMind, an expert academic research assistant. Output compact, accurate JSON grounded strictly in the paper text. Be concise and direct so responses complete quickly without omitting any key facts or metrics.',
    responseMimeType: 'application/json',
    thinkingLevel: ThinkingLevel.LOW,
    firstChunkTimeoutMs: 15000,
    totalTimeoutMs: 55000,
    retries: 1,
    signal,
    onRetry: () => {
      onProgress?.({
        phase: 'extracting',
        progress: 36,
        message: 'Primary model busy — switching to fast Gemini Flash Lite model...',
      });
    },
    onChunk: (accumulated) => {
      const now = Date.now();
      if (now - lastProgressAt < 350) return;
      lastProgressAt = now;

      const len = accumulated.length;
      const hasAnalysisKey =
        accumulated.includes('"analysis"') || len > 3200;

      if (!hasAnalysisKey && !switchedToAnalysis) {
        const pct = Math.min(62, 36 + Math.round((len / 3200) * 26));
        const msg =
          len > 1500
            ? 'Extracting datasets, algorithms & experimental metrics...'
            : 'Extracting research metadata, objectives & methodology...';
        onProgress?.({
          phase: 'extracting',
          progress: pct,
          message: msg,
        });
      } else {
        switchedToAnalysis = true;
        const analysisLen = Math.max(0, len - 2800);
        const pct = Math.min(95, 68 + Math.round((analysisLen / 4500) * 27));
        const msg =
          pct >= 84
            ? 'Identifying research gaps, limitations & future scope...'
            : 'Generating deep AI analysis, metrics table & methodology review...';
        onProgress?.({
          phase: 'analyzing',
          progress: pct,
          message: msg,
        });
      }
    },
  });

  const parsed = parseStructuredJson<{
    extraction?: Partial<SmartExtractionData>;
    analysis?: Partial<AIAnalysisData>;
  }>(rawText);

  const extraction = normalizeExtraction(parsed.extraction ?? {}, parsedRefs);
  const analysis = normalizeAnalysis(parsed.analysis ?? {});

  console.log(
    `[PaperMind] Unified analysis completed for ${doc.documentId} (${doc.pageCount} pages, ${parsedRefs.length} deterministic refs) in ${Date.now() - tStart}ms`,
  );

  return { extraction, analysis };
}
