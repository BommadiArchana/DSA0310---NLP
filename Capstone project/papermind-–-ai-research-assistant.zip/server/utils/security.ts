import crypto from 'node:crypto';
import path from 'node:path';
import type { Request, Response, NextFunction } from 'express';

const SESSION_COOKIE_NAME = 'papermind_sid';
const EPHEMERAL_FALLBACK_SECRET = crypto.randomBytes(32).toString('hex');

function getSigningSecret(): string {
  return process.env.SESSION_SECRET || EPHEMERAL_FALLBACK_SECRET;
}

export function signSessionId(sessionId: string): string {
  const hmac = crypto
    .createHmac('sha256', getSigningSecret())
    .update(sessionId)
    .digest('hex');
  return `${sessionId}.${hmac}`;
}

export function verifySignedSessionId(token: string): string | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [sessionId, signature] = parts;
  if (!sessionId || !signature || !/^[a-f0-9-]{36}$/i.test(sessionId)) {
    return null;
  }
  const expected = crypto
    .createHmac('sha256', getSigningSecret())
    .update(sessionId)
    .digest('hex');
  const sigBuf = Buffer.from(signature, 'utf8');
  const expBuf = Buffer.from(expected, 'utf8');
  if (sigBuf.length !== expBuf.length) return null;
  if (!crypto.timingSafeEqual(sigBuf, expBuf)) return null;
  return sessionId;
}

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  const pairs = cookieHeader.split(';');
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx === -1) continue;
    const key = pair.slice(0, idx).trim();
    const val = decodeURIComponent(pair.slice(idx + 1).trim());
    if (key) result[key] = val;
  }
  return result;
}

function extractBearerToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || typeof authHeader !== 'string') return null;
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : null;
}

export interface SessionRequest extends Request {
  sessionId?: string;
  sessionToken?: string;
}

export function sessionMiddleware(
  req: SessionRequest,
  res: Response,
  next: NextFunction,
): void {
  const bearerToken = extractBearerToken(req);
  const cookies = parseCookies(req.headers.cookie);
  const rawCookie = cookies[SESSION_COOKIE_NAME];

  let sessionId =
    (bearerToken ? verifySignedSessionId(bearerToken) : null) ||
    (rawCookie ? verifySignedSessionId(rawCookie) : null);

  let signedToken: string;

  if (!sessionId) {
    sessionId = crypto.randomUUID();
    signedToken = signSessionId(sessionId);

    const originHeader =
      typeof req.headers.origin === 'string' ? req.headers.origin : '';
    const isHttps =
      req.secure ||
      req.headers['x-forwarded-proto'] === 'https' ||
      originHeader.startsWith('https://') ||
      Boolean(process.env.APP_URL?.startsWith('https://')) ||
      process.env.NODE_ENV === 'production';

    if (isHttps) {
      res.cookie(SESSION_COOKIE_NAME, signedToken, {
        httpOnly: true,
        secure: true,
        sameSite: 'none',
        partitioned: true,
        maxAge: 24 * 60 * 60 * 1000,
        path: '/',
      });
    } else {
      res.cookie(SESSION_COOKIE_NAME, signedToken, {
        httpOnly: true,
        sameSite: 'lax',
        maxAge: 24 * 60 * 60 * 1000,
        path: '/',
      });
    }
  } else {
    signedToken = signSessionId(sessionId);
  }

  req.sessionId = sessionId;
  req.sessionToken = signedToken;
  res.setHeader('X-Session-Token', signedToken);
  next();
}

export function originProtectionMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    next();
    return;
  }

  const origin = req.headers.origin;
  if (!origin) {
    next();
    return;
  }

  let originHost: string;
  try {
    originHost = new URL(origin).host;
  } catch {
    res.status(403).json({ error: 'Invalid request origin.' });
    return;
  }

  const candidateHosts = new Set<string>();
  const forwardedHost = req.headers['x-forwarded-host'];
  if (typeof forwardedHost === 'string') {
    for (const part of forwardedHost.split(',')) {
      const trimmed = part.trim();
      if (trimmed) candidateHosts.add(trimmed);
    }
  }
  if (typeof req.headers.host === 'string' && req.headers.host.trim()) {
    candidateHosts.add(req.headers.host.trim());
  }
  if (process.env.APP_URL) {
    try {
      candidateHosts.add(new URL(process.env.APP_URL).host);
    } catch {
      // Ignore invalid APP_URL placeholder
    }
  }
  if (typeof req.headers.referer === 'string') {
    try {
      candidateHosts.add(new URL(req.headers.referer).host);
    } catch {
      // Ignore malformed referer
    }
  }

  if (candidateHosts.has(originHost)) {
    next();
    return;
  }

  // Behind reverse proxies (e.g. nginx -> localhost:3000) Host is rewritten to localhost:3000.
  // Browsers enforce CORS preflight on custom headers like X-Requested-With, blocking cross-site requests.
  const hasCustomSpaHeader =
    req.headers['x-requested-with'] === 'PaperMind' ||
    Boolean(extractBearerToken(req));
  const hostHeader = req.headers.host || '';
  const isLocalProxyHost =
    hostHeader === 'localhost' ||
    hostHeader.startsWith('localhost:') ||
    hostHeader === '127.0.0.1' ||
    hostHeader.startsWith('127.0.0.1:');

  if (hasCustomSpaHeader && isLocalProxyHost) {
    next();
    return;
  }

  res.status(403).json({
    error: 'Cross-origin mutation request rejected.',
  });
}

export function sanitizeFilename(rawName: string): string {
  const base = path.basename(rawName || 'research-paper.pdf');
  const cleaned = base
    .replace(/[^a-zA-Z0-9._-]/g, '_')
    .replace(/_{2,}/g, '_')
    .slice(0, 120);
  if (!cleaned || cleaned === '.' || cleaned === '..') {
    return 'research-paper.pdf';
  }
  return cleaned.toLowerCase().endsWith('.pdf') ? cleaned : `${cleaned}.pdf`;
}

export function resolveInsideDir(baseDir: string, targetFilename: string): string {
  const normalizedBase = path.resolve(baseDir);
  const safeName = path.basename(targetFilename);
  const resolved = path.resolve(normalizedBase, safeName);
  if (!resolved.startsWith(normalizedBase + path.sep)) {
    throw new Error('Invalid file path outside storage boundary.');
  }
  return resolved;
}

export function hasPdfMagicSignature(buffer: Buffer): boolean {
  if (!buffer || buffer.length < 5) return false;
  const head = buffer.subarray(0, Math.min(1024, buffer.length)).toString('latin1');
  return head.includes('%PDF-');
}

export function isValidId(id: string | undefined): id is string {
  return Boolean(id && /^[a-zA-Z0-9_-]{8,64}$/.test(id));
}
