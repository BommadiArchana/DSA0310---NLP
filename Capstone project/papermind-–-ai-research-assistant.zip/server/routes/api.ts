import crypto from 'node:crypto';
import fs from 'node:fs';
import express from 'express';
import multer from 'multer';
import type { AnalysisJob, StoredDocument } from '../types.ts';
import {
  MAX_UPLOAD_BYTES,
  DOCUMENT_TTL_MS,
  deleteDocumentForSession,
  findActiveJobForDocument,
  getDocumentForSession,
  getJobForSession,
  getReportForSession,
  listDocumentsForSession,
  saveUploadedPdfBuffer,
  setDocument,
  setJob,
} from '../services/storageService.ts';
import {
  extractPdfContent,
  PdfProcessingError,
} from '../services/pdfService.ts';
import {
  classifyGeminiError,
  isGeminiConfigured,
} from '../services/geminiService.ts';
import { runSmartExtraction } from '../services/extractionService.ts';
import { runDeepAnalysis } from '../services/analysisService.ts';
import { runUnifiedPaperAnalysis } from '../services/unifiedAnalysisService.ts';
import { streamChatResponse } from '../services/chatService.ts';
import { compareResearchPapers } from '../services/comparisonService.ts';
import { generateLiteratureReview } from '../services/literatureService.ts';
import {
  buildStructuredReportPayload,
  generateReportFile,
} from '../services/reportService.ts';
import {
  hasPdfMagicSignature,
  isValidId,
  sanitizeFilename,
  type SessionRequest,
} from '../utils/security.ts';

const router = express.Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_UPLOAD_BYTES,
    files: 1,
  },
});

const activeAbortControllers = new Map<string, AbortController>();

function serializeDocumentResponse(doc: StoredDocument) {
  return {
    documentId: doc.documentId,
    originalFilename: doc.originalFilename,
    sanitizedFilename: doc.sanitizedFilename,
    fileSizeBytes: doc.fileSizeBytes,
    pageCount: doc.pageCount,
    sectionsCount: doc.sections.length,
    sections: doc.sections,
    ocrPagesCount: doc.ocrPagesCount,
    ocrWarnings: doc.ocrWarnings,
    extractionStatus: doc.extractionStatus,
    analysisStatus: doc.analysisStatus,
    extraction: doc.extraction ?? null,
    analysis: doc.analysis ?? null,
    chatHistory: doc.chatHistory,
    lastComparison: doc.lastComparison ?? null,
    lastLiteratureReview: doc.lastLiteratureReview ?? null,
    createdAt: doc.createdAt,
    expiresAt: doc.expiresAt,
  };
}

router.get('/health', (req: SessionRequest, res) => {
  res.json({
    status: 'ok',
    service: 'PaperMind Research Analysis API',
    geminiConfigured: isGeminiConfigured(),
    maxUploadBytes: MAX_UPLOAD_BYTES,
    maxUploadMb: Math.round(MAX_UPLOAD_BYTES / (1024 * 1024)),
    sessionToken: req.sessionToken,
    timestamp: new Date().toISOString(),
  });
});

router.get('/documents', (req: SessionRequest, res) => {
  const sessionId = req.sessionId!;
  const docs = listDocumentsForSession(sessionId).map((d) => ({
    documentId: d.documentId,
    originalFilename: d.originalFilename,
    title: d.extraction?.generalInfo.title || d.originalFilename,
    authors: d.extraction?.generalInfo.authors || [],
    publicationYear: d.extraction?.generalInfo.publicationYear || '',
    fileSizeBytes: d.fileSizeBytes,
    pageCount: d.pageCount,
    sectionsCount: d.sections.length,
    extractionStatus: d.extractionStatus,
    analysisStatus: d.analysisStatus,
    createdAt: d.createdAt,
    expiresAt: d.expiresAt,
  }));
  res.json({ documents: docs });
});

router.post('/documents/upload', (req: SessionRequest, res) => {
  upload.single('file')(req, res, async (multerErr) => {
    if (multerErr) {
      if (
        multerErr instanceof multer.MulterError &&
        multerErr.code === 'LIMIT_FILE_SIZE'
      ) {
        res.status(413).json({
          error: `PDF exceeds the maximum upload limit of ${Math.round(MAX_UPLOAD_BYTES / (1024 * 1024))} MB.`,
          code: 'FILE_TOO_LARGE',
        });
        return;
      }
      res.status(400).json({
        error: multerErr.message || 'File upload failed.',
        code: 'UPLOAD_ERROR',
      });
      return;
    }

    const sessionId = req.sessionId!;
    const file = req.file;
    if (!file) {
      res.status(400).json({
        error: 'No PDF file was selected. Please choose a PDF file to upload.',
        code: 'NO_FILE',
      });
      return;
    }

    const isPdfExt = file.originalname.toLowerCase().endsWith('.pdf');
    const isPdfMime = file.mimetype === 'application/pdf';
    if (!isPdfExt && !isPdfMime) {
      res.status(400).json({
        error: 'Invalid file format. Only PDF (.pdf) documents are supported.',
        code: 'INVALID_FORMAT',
      });
      return;
    }

    if (file.size === 0 || !file.buffer || file.buffer.length === 0) {
      res.status(400).json({
        error: 'The uploaded PDF file is empty (0 bytes).',
        code: 'EMPTY_PDF',
      });
      return;
    }

    if (!hasPdfMagicSignature(file.buffer)) {
      res.status(400).json({
        error:
          'Invalid PDF file signature. The uploaded file does not appear to be a valid PDF document.',
        code: 'INVALID_SIGNATURE',
      });
      return;
    }

    try {
      const extracted = await extractPdfContent(file.buffer);
      const documentId = `doc_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
      const sanitized = sanitizeFilename(file.originalname);
      const filePath = saveUploadedPdfBuffer(documentId, file.buffer);
      const now = Date.now();

      const stored: StoredDocument = {
        documentId,
        sessionId,
        originalFilename: file.originalname,
        sanitizedFilename: sanitized,
        filePath,
        fileSizeBytes: file.size,
        pageCount: extracted.pageCount,
        pages: extracted.pages,
        fullText: extracted.fullText,
        sections: extracted.sections,
        chunks: extracted.chunks,
        ocrPagesCount: extracted.ocrPagesCount,
        ocrWarnings: extracted.ocrWarnings,
        extractionStatus: extracted.extractionStatus,
        analysisStatus: 'uploaded',
        chatHistory: [],
        createdAt: now,
        expiresAt: now + DOCUMENT_TTL_MS,
      };

      setDocument(stored);

      res.status(201).json({
        documentId: stored.documentId,
        originalFilename: stored.originalFilename,
        sanitizedFilename: stored.sanitizedFilename,
        fileSizeBytes: stored.fileSizeBytes,
        pageCount: stored.pageCount,
        sectionsCount: stored.sections.length,
        ocrPagesCount: stored.ocrPagesCount,
        ocrWarnings: stored.ocrWarnings,
        extractionStatus: stored.extractionStatus,
        analysisStatus: stored.analysisStatus,
      });
    } catch (err) {
      if (err instanceof PdfProcessingError) {
        res.status(422).json({
          error: err.message,
          code: err.code,
        });
        return;
      }
      res.status(500).json({
        error: 'Unexpected error while extracting text from the PDF.',
        code: 'EXTRACTION_FAILED',
      });
    }
  });
});

router.get('/documents/:documentId', (req: SessionRequest, res) => {
  const { documentId } = req.params;
  if (!isValidId(documentId)) {
    res.status(400).json({ error: 'Invalid document ID.' });
    return;
  }

  const lookup = getDocumentForSession(documentId, req.sessionId!);
  if (!lookup.doc) {
    if (lookup.reason === 'expired') {
      res.status(410).json({
        error:
          'This temporary document has expired and been removed. Please upload your PDF again.',
        code: 'DOCUMENT_EXPIRED',
      });
      return;
    }
    res.status(lookup.reason === 'forbidden' ? 403 : 404).json({
      error:
        lookup.reason === 'forbidden'
          ? 'You do not have access to this document.'
          : 'Document not found.',
    });
    return;
  }

  res.json(serializeDocumentResponse(lookup.doc));
});

router.get('/documents/:documentId/pdf', (req: SessionRequest, res) => {
  const { documentId } = req.params;
  if (!isValidId(documentId)) {
    res.status(400).json({ error: 'Invalid document ID.' });
    return;
  }

  const lookup = getDocumentForSession(documentId, req.sessionId!);
  if (!lookup.doc) {
    res.status(lookup.reason === 'expired' ? 410 : 404).json({
      error: 'Original PDF document is unavailable or expired.',
    });
    return;
  }

  if (!fs.existsSync(lookup.doc.filePath)) {
    res.status(404).json({ error: 'Temporary PDF file is no longer present.' });
    return;
  }

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader(
    'Content-Disposition',
    `attachment; filename="${lookup.doc.sanitizedFilename}"`,
  );
  fs.createReadStream(lookup.doc.filePath).pipe(res);
});

router.delete('/documents/:documentId', (req: SessionRequest, res) => {
  const { documentId } = req.params;
  if (!isValidId(documentId)) {
    res.status(400).json({ error: 'Invalid document ID.' });
    return;
  }

  const result = deleteDocumentForSession(documentId, req.sessionId!);
  if (!result.deleted) {
    res.status(result.reason === 'forbidden' ? 403 : 404).json({
      error:
        result.reason === 'forbidden'
          ? 'Access denied.'
          : 'Document not found.',
    });
    return;
  }

  res.json({
    deleted: true,
    fileDeleted: result.fileDeleted,
    documentId,
  });
});

async function executeAnalysisPipeline(
  doc: StoredDocument,
  job: AnalysisJob,
  controller: AbortController,
): Promise<void> {
  try {
    if (job.cancelled || controller.signal.aborted) return;

    // STAGE 1: Reading & verifying extracted document structure
    job.status = 'running';
    job.currentStage = 1;
    job.stages.stage1.status = 'in_progress';
    job.statusMessage = 'Reading your research paper...';
    job.progress = 15;
    job.updatedAt = Date.now();

    if (!doc.fullText || doc.pages.length === 0) {
      throw new Error('Document contains no extracted text to analyze.');
    }

    job.progress = 28;
    job.stages.stage1.status = 'completed';
    job.currentStage = 2;
    job.stages.stage2.status = 'in_progress';
    job.statusMessage = 'Extracting structured research insights with Gemini...';
    job.progress = 32;
    job.updatedAt = Date.now();

    // STAGE 2 & STAGE 3: Unified single-pass streaming extraction + deep analysis
    const { extraction, analysis } = await runUnifiedPaperAnalysis(
      doc,
      (update) => {
        if (job.cancelled || controller.signal.aborted) return;
        if (update.phase === 'analyzing') {
          job.stages.stage2.status = 'completed';
          job.currentStage = 3;
          job.stages.stage3.status = 'in_progress';
        } else {
          job.currentStage = 2;
          job.stages.stage2.status = 'in_progress';
        }
        job.progress = Math.max(job.progress, update.progress);
        job.statusMessage = update.message;
        job.updatedAt = Date.now();
      },
      controller.signal,
    );

    if (job.cancelled || controller.signal.aborted) return;
    doc.extraction = extraction;
    doc.analysis = analysis;
    doc.analysisStatus = 'completed';

    job.stages.stage2.status = 'completed';
    job.stages.stage3.status = 'completed';
    job.currentStage = 3;
    job.status = 'completed';
    job.progress = 100;
    job.statusMessage = 'Analysis complete. Preparing your dashboard...';
    job.updatedAt = Date.now();
  } catch (err) {
    if (job.cancelled || controller.signal.aborted) {
      job.status = 'cancelled';
      job.statusMessage = 'Analysis cancelled by user.';
      doc.analysisStatus = 'uploaded';
      job.updatedAt = Date.now();
      return;
    }

    const classified = classifyGeminiError(err);
    doc.analysisStatus = 'failed';
    job.status = 'failed';
    job.error = classified.message;
    job.statusMessage = classified.message;
    if (job.currentStage === 1) job.stages.stage1.status = 'failed';
    if (job.currentStage === 2) job.stages.stage2.status = 'failed';
    if (job.currentStage === 3) job.stages.stage3.status = 'failed';
    job.updatedAt = Date.now();
  } finally {
    activeAbortControllers.delete(job.jobId);
  }
}

router.post('/documents/:documentId/analyze', (req: SessionRequest, res) => {
  const { documentId } = req.params;
  if (!isValidId(documentId)) {
    res.status(400).json({ error: 'Invalid document ID.' });
    return;
  }

  const sessionId = req.sessionId!;
  const lookup = getDocumentForSession(documentId, sessionId);
  if (!lookup.doc) {
    res.status(lookup.reason === 'expired' ? 410 : 404).json({
      error:
        lookup.reason === 'expired'
          ? 'Temporary document expired. Please upload the PDF again.'
          : 'Document not found.',
    });
    return;
  }

  if (!isGeminiConfigured()) {
    res.status(503).json({
      error:
        'GEMINI_API_KEY is not configured on the server. Please add it in Settings > Secrets.',
      code: 'API_KEY_MISSING',
    });
    return;
  }

  // Prevent duplicate concurrent analysis requests for the same document
  const existingJob = findActiveJobForDocument(documentId, sessionId);
  if (existingJob) {
    res.status(202).json({
      jobId: existingJob.jobId,
      status: existingJob.status,
      duplicatePrevented: true,
    });
    return;
  }

  const jobId = `job_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
  const now = Date.now();
  const job: AnalysisJob = {
    jobId,
    documentId,
    sessionId,
    status: 'queued',
    progress: 5,
    statusMessage: 'Reading your research paper...',
    currentStage: 1,
    stages: {
      stage1: {
        status: 'in_progress',
        label: 'STAGE 1 – READING DOCUMENT',
        tasks: [
          'Validate uploaded PDF',
          'Extract document text',
          'Identify sections',
          'Identify page numbers',
        ],
      },
      stage2: {
        status: 'pending',
        label: 'STAGE 2 – EXTRACTING INSIGHTS',
        tasks: [
          'Identify research objectives',
          'Extract methodology',
          'Identify algorithms',
          'Extract datasets',
          'Identify experimental results',
        ],
      },
      stage3: {
        status: 'pending',
        label: 'STAGE 3 – PREPARING ANALYSIS',
        tasks: [
          'Send document content to Gemini',
          'Generate research analysis',
          'Generate research gap suggestions',
          'Prepare dashboard information',
        ],
      },
    },
    createdAt: now,
    updatedAt: now,
    cancelled: false,
  };

  lookup.doc.analysisStatus = 'analyzing';
  setJob(job);

  const controller = new AbortController();
  activeAbortControllers.set(jobId, controller);

  void executeAnalysisPipeline(lookup.doc, job, controller);

  res.status(202).json({
    jobId: job.jobId,
    status: job.status,
  });
});

router.get('/jobs/:jobId', (req: SessionRequest, res) => {
  const { jobId } = req.params;
  if (!isValidId(jobId)) {
    res.status(400).json({ error: 'Invalid job ID.' });
    return;
  }

  const job = getJobForSession(jobId, req.sessionId!);
  if (!job) {
    res.status(404).json({ error: 'Analysis job not found.' });
    return;
  }

  res.json({
    jobId: job.jobId,
    documentId: job.documentId,
    status: job.status,
    progress: job.status === 'completed' ? 100 : Math.min(99, job.progress),
    statusMessage: job.statusMessage,
    currentStage: job.currentStage,
    stages: job.stages,
    error: job.error ?? null,
    updatedAt: job.updatedAt,
  });
});

router.post('/jobs/:jobId/cancel', (req: SessionRequest, res) => {
  const { jobId } = req.params;
  if (!isValidId(jobId)) {
    res.status(400).json({ error: 'Invalid job ID.' });
    return;
  }

  const job = getJobForSession(jobId, req.sessionId!);
  if (!job) {
    res.status(404).json({ error: 'Analysis job not found.' });
    return;
  }

  job.cancelled = true;
  job.status = 'cancelled';
  job.statusMessage = 'Analysis cancelled.';
  job.updatedAt = Date.now();

  const controller = activeAbortControllers.get(jobId);
  if (controller) {
    controller.abort();
    activeAbortControllers.delete(jobId);
  }

  const lookup = getDocumentForSession(job.documentId, req.sessionId!);
  if (lookup.doc && lookup.doc.analysisStatus === 'analyzing') {
    lookup.doc.analysisStatus = 'uploaded';
  }

  res.json({ cancelled: true, jobId });
});

router.post('/documents/:documentId/chat', async (req: SessionRequest, res) => {
  const { documentId } = req.params;
  if (!isValidId(documentId)) {
    res.status(400).json({ error: 'Invalid document ID.' });
    return;
  }

  const lookup = getDocumentForSession(documentId, req.sessionId!);
  if (!lookup.doc) {
    res.status(lookup.reason === 'expired' ? 410 : 404).json({
      error:
        lookup.reason === 'expired'
          ? 'Document expired. Please re-upload your PDF.'
          : 'Document not found.',
    });
    return;
  }

  const rawQuestion = req.body?.question;
  if (typeof rawQuestion !== 'string' || rawQuestion.trim().length === 0) {
    res.status(400).json({
      error: 'Please enter a valid non-empty question.',
      code: 'INVALID_QUESTION',
    });
    return;
  }

  const question = rawQuestion.trim().slice(0, 2000);
  const wantStream = req.query.stream !== 'false';

  if (!wantStream) {
    try {
      let finalMessage = null;
      for await (const ev of streamChatResponse(lookup.doc, question)) {
        if (ev.type === 'done') finalMessage = ev.message;
      }
      res.json({ message: finalMessage });
    } catch (err) {
      const classified = classifyGeminiError(err);
      res.status(classified.statusCode).json({
        error: classified.message,
        code: classified.code,
      });
    }
    return;
  }

  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');

  try {
    for await (const ev of streamChatResponse(lookup.doc, question)) {
      res.write(`data: ${JSON.stringify(ev)}\n\n`);
    }
    res.end();
  } catch (err) {
    const classified = classifyGeminiError(err);
    res.write(
      `data: ${JSON.stringify({
        type: 'error',
        error: classified.message,
        code: classified.code,
      })}\n\n`,
    );
    res.end();
  }
});

router.delete('/documents/:documentId/chat', (req: SessionRequest, res) => {
  const { documentId } = req.params;
  if (!isValidId(documentId)) {
    res.status(400).json({ error: 'Invalid document ID.' });
    return;
  }

  const lookup = getDocumentForSession(documentId, req.sessionId!);
  if (!lookup.doc) {
    res.status(404).json({ error: 'Document not found.' });
    return;
  }

  lookup.doc.chatHistory = [];
  res.json({ cleared: true });
});

router.post(
  '/documents/:documentId/compare',
  async (req: SessionRequest, res) => {
    const { documentId } = req.params;
    const otherDocumentId = req.body?.otherDocumentId;

    if (!isValidId(documentId) || !isValidId(otherDocumentId)) {
      res.status(400).json({
        error: 'Two valid document IDs are required for comparison.',
      });
      return;
    }

    if (documentId === otherDocumentId) {
      res.status(400).json({
        error: 'Please select two different research papers to compare.',
      });
      return;
    }

    const sessionId = req.sessionId!;
    const lookupA = getDocumentForSession(documentId, sessionId);
    const lookupB = getDocumentForSession(otherDocumentId, sessionId);

    if (!lookupA.doc || !lookupB.doc) {
      res.status(404).json({
        error: 'One or both selected research papers could not be found.',
      });
      return;
    }

    try {
      // Ensure Paper B has at least smart extraction run if not yet analyzed
      if (!lookupA.doc.extraction) {
        lookupA.doc.extraction = await runSmartExtraction(lookupA.doc);
      }
      if (!lookupB.doc.extraction) {
        lookupB.doc.extraction = await runSmartExtraction(lookupB.doc);
      }
      if (!lookupB.doc.analysis) {
        lookupB.doc.analysis = await runDeepAnalysis(
          lookupB.doc,
          lookupB.doc.extraction,
        );
        lookupB.doc.analysisStatus = 'completed';
      }

      const comparison = await compareResearchPapers(lookupA.doc, lookupB.doc);
      res.json({ comparison });
    } catch (err) {
      const classified = classifyGeminiError(err);
      res.status(classified.statusCode).json({
        error: classified.message,
        code: classified.code,
      });
    }
  },
);

router.post(
  '/documents/:documentId/literature-review',
  async (req: SessionRequest, res) => {
    const { documentId } = req.params;
    if (!isValidId(documentId)) {
      res.status(400).json({ error: 'Invalid document ID.' });
      return;
    }

    const sessionId = req.sessionId!;
    const primaryLookup = getDocumentForSession(documentId, sessionId);
    if (!primaryLookup.doc) {
      res.status(404).json({ error: 'Primary document not found.' });
      return;
    }

    const requestedIds: string[] = Array.isArray(req.body?.documentIds)
      ? req.body.documentIds.filter((id: unknown) =>
          typeof id === 'string' && isValidId(id),
        )
      : [documentId];

    if (!requestedIds.includes(documentId)) {
      requestedIds.unshift(documentId);
    }

    const docs: StoredDocument[] = [];
    for (const id of requestedIds.slice(0, 5)) {
      const l = getDocumentForSession(id, sessionId);
      if (l.doc) docs.push(l.doc);
    }

    if (docs.length === 0) {
      res.status(404).json({ error: 'No valid documents selected.' });
      return;
    }

    try {
      for (const d of docs) {
        if (!d.extraction) {
          d.extraction = await runSmartExtraction(d);
        }
      }

      const literatureReview = await generateLiteratureReview(
        docs,
        primaryLookup.doc,
      );
      res.json({ literatureReview });
    } catch (err) {
      const classified = classifyGeminiError(err);
      res.status(classified.statusCode).json({
        error: classified.message,
        code: classified.code,
      });
    }
  },
);

router.post(
  '/documents/:documentId/report',
  async (req: SessionRequest, res) => {
    const { documentId } = req.params;
    if (!isValidId(documentId)) {
      res.status(400).json({ error: 'Invalid document ID.' });
      return;
    }

    const lookup = getDocumentForSession(documentId, req.sessionId!);
    if (!lookup.doc) {
      res.status(lookup.reason === 'expired' ? 410 : 404).json({
        error: 'Document not found or expired.',
      });
      return;
    }

    const formatRaw = req.body?.format;
    const format: 'pdf' | 'txt' | 'json' =
      formatRaw === 'txt' || formatRaw === 'json' || formatRaw === 'pdf'
        ? formatRaw
        : 'pdf';

    try {
      if (req.body?.previewOnly === true) {
        const payload = buildStructuredReportPayload(lookup.doc);
        res.json({ payload });
        return;
      }

      const { report, payload } = await generateReportFile(
        lookup.doc,
        req.sessionId!,
        format,
      );

      res.status(201).json({
        reportId: report.reportId,
        format: report.format,
        filename: report.filename,
        downloadUrl: `/api/reports/${report.reportId}/download`,
        payload,
      });
    } catch (err) {
      res.status(500).json({
        error:
          err instanceof Error
            ? `Report generation failed: ${err.message}`
            : 'Report generation failed.',
        code: 'REPORT_FAILED',
      });
    }
  },
);

router.get('/reports/:reportId/download', (req: SessionRequest, res) => {
  const { reportId } = req.params;
  if (!isValidId(reportId)) {
    res.status(400).json({ error: 'Invalid report ID.' });
    return;
  }

  const lookup = getReportForSession(reportId, req.sessionId!);
  if (!lookup.report) {
    res.status(lookup.reason === 'expired' ? 410 : 404).json({
      error: 'Report not found or has expired. Please regenerate the report.',
    });
    return;
  }

  if (!fs.existsSync(lookup.report.filePath)) {
    res.status(404).json({ error: 'Generated report file is missing.' });
    return;
  }

  res.setHeader('Content-Type', lookup.report.mimeType);
  res.setHeader(
    'Content-Disposition',
    `attachment; filename="${lookup.report.filename}"`,
  );
  fs.createReadStream(lookup.report.filePath).pipe(res);
});

export default router;
