export interface ExtractedPage {
  pageNumber: number;
  text: string;
  charCount: number;
  ocrUsed: boolean;
  ocrError?: string;
}

export interface DocumentSection {
  title: string;
  pageStart: number;
  pageEnd: number;
  preview: string;
}

export interface DocumentChunk {
  id: string;
  pageStart: number;
  pageEnd: number;
  section: string;
  text: string;
}

export interface ExtractedReference {
  title: string;
  authors: string;
  year: string;
  doiOrUrl: string;
}

export interface SmartExtractionData {
  generalInfo: {
    title: string;
    authors: string[];
    publicationYear: string;
    journalOrConference: string;
    doi: string;
    abstract: string;
    keywords: string[];
  };
  researchInfo: {
    researchProblem: string;
    researchObjectives: string[];
    researchQuestions: string[];
    researchMotivation: string;
    existingSystem: string;
    proposedSystem: string;
    researchContributions: string[];
  };
  technicalInfo: {
    researchMethodology: string;
    algorithmsUsed: string[];
    mlModels: string[];
    dlModels: string[];
    nlpTechniques: string[];
    datasetNames: string[];
    datasetDescriptions: string[];
    toolsAndTechnologies: string[];
    softwareAndLibraries: string[];
  };
  experimentalInfo: {
    experimentalSetup: string;
    evaluationMethods: string[];
    performanceMetricsSummary: string;
    accuracy: string;
    precision: string;
    recall: string;
    f1Score: string;
    mae: string;
    rmse: string;
    otherMeasurements: string[];
    experimentalFindings: string[];
  };
  conclusions: {
    keyFindings: string[];
    strengths: string[];
    limitations: string[];
    challenges: string[];
    futureScope: string[];
    conclusion: string;
  };
  references: ExtractedReference[];
}

export interface PerformanceMetricRow {
  modelOrAlgorithm: string;
  dataset: string;
  accuracy: number | null;
  precision: number | null;
  recall: number | null;
  f1Score: number | null;
  mae: number | null;
  rmse: number | null;
  otherMetrics: string;
  rawReportedValues: string;
}

export interface AIAnalysisData {
  summary: {
    shortSummary: string;
    detailedSummary: string;
    mainPurpose: string;
    importantContributions: string[];
  };
  problemAnalysis: {
    mainProblem: string;
    whyProblemExists: string;
    existingChallenges: string[];
    whyResearchNecessary: string;
  };
  objectivesExplained: Array<{
    objective: string;
    simpleExplanation: string;
  }>;
  methodologyAnalysis: {
    researchApproach: string;
    proposedMethodology: string;
    algorithmsUsed: string[];
    modelsUsed: string[];
    workflowSteps: Array<{
      stepNumber: number;
      title: string;
      description: string;
    }>;
    implementationDetails: string;
  };
  datasetAnalysis: Array<{
    datasetName: string;
    datasetSource: string;
    numberOfRecords: string;
    characteristics: string;
    preprocessingMethods: string[];
    trainTestSplitDetails: string;
  }>;
  resultsAnalysis: {
    metricsTable: PerformanceMetricRow[];
    hasSufficientNumericalDataForChart: boolean;
    chartMetricUnit: string;
    explanation: string;
  };
  strengthsAndWeaknesses: {
    majorStrengths: string[];
    technicalAdvantages: string[];
    methodologicalLimitations: string[];
    performanceLimitations: string[];
    practicalChallenges: string[];
  };
  researchGaps: {
    authorIdentifiedGaps: string[];
    aiSuggestedOpportunities: string[];
  };
  futureScope: {
    aiGeneratedDisclaimer: string;
    possibleImprovements: string[];
    alternativeApproaches: string[];
    newAlgorithmsToInvestigate: string[];
    possibleApplications: string[];
    futureResearchDirections: string[];
  };
  finalConclusion: string;
}

export interface PaperComparisonResult {
  paperATitle: string;
  paperBTitle: string;
  comparisonTable: Array<{
    dimension: string;
    paperA: string;
    paperB: string;
    notes: string;
  }>;
  metricComparabilityWarning: string;
  similarities: string[];
  differences: string[];
  overallSummary: string;
}

export interface LiteratureReviewResult {
  title: string;
  aiSynthesisNotice: string;
  papersIncluded: Array<{
    documentId: string;
    title: string;
    authors: string;
    year: string;
  }>;
  introduction: string;
  researchBackground: string;
  previousApproaches: string;
  methodsUsed: Array<{
    paperTitle: string;
    summary: string;
  }>;
  comparisonOfFindings: string;
  existingLimitations: string[];
  identifiedResearchGaps: string[];
  overallConclusion: string;
  verifiedCitations: ExtractedReference[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sourcePages?: number[];
  timestamp: string;
}

export type JobStageStatus = 'pending' | 'in_progress' | 'completed' | 'failed';

export interface AnalysisJob {
  jobId: string;
  documentId: string;
  sessionId: string;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
  progress: number;
  statusMessage: string;
  currentStage: 1 | 2 | 3;
  stages: {
    stage1: { status: JobStageStatus; label: string; tasks: string[] };
    stage2: { status: JobStageStatus; label: string; tasks: string[] };
    stage3: { status: JobStageStatus; label: string; tasks: string[] };
  };
  error?: string;
  createdAt: number;
  updatedAt: number;
  cancelled: boolean;
}

export interface StoredDocument {
  documentId: string;
  sessionId: string;
  originalFilename: string;
  sanitizedFilename: string;
  filePath: string;
  fileSizeBytes: number;
  pageCount: number;
  pages: ExtractedPage[];
  fullText: string;
  sections: DocumentSection[];
  chunks: DocumentChunk[];
  ocrPagesCount: number;
  ocrWarnings: string[];
  extractionStatus: 'extracted' | 'partial_ocr' | 'failed';
  analysisStatus: 'uploaded' | 'analyzing' | 'completed' | 'failed';
  extraction?: SmartExtractionData;
  analysis?: AIAnalysisData;
  chatHistory: ChatMessage[];
  lastComparison?: PaperComparisonResult;
  lastLiteratureReview?: LiteratureReviewResult;
  createdAt: number;
  expiresAt: number;
}

export interface StoredReport {
  reportId: string;
  documentId: string;
  sessionId: string;
  format: 'pdf' | 'txt' | 'json';
  filename: string;
  filePath: string;
  mimeType: string;
  createdAt: number;
  expiresAt: number;
}
