import type {
  AnalysisJobStatus,
  ChatMessage,
  DocumentSummaryItem,
  FullDocumentData,
  HealthStatus,
  LiteratureReviewResult,
  PaperComparisonResult,
  UploadedDocumentResponse,
} from '../types/papermind';

// Kept strictly in JS memory (never localStorage or sessionStorage)
let inMemorySessionToken: string | null = null;

function buildHeaders(extra?: Record<string, string>): Record<string, string> {
  const headers: Record<string, string> = {
    'X-Requested-With': 'PaperMind',
    ...(extra || {}),
  };
  if (inMemorySessionToken) {
    headers['Authorization'] = `Bearer ${inMemorySessionToken}`;
  }
  return headers;
}

function syncSessionToken(res: Response): void {
  const token = res.headers.get('X-Session-Token');
  if (token) {
    inMemorySessionToken = token;
  }
}

async function ensureSessionInitialized(): Promise<void> {
  if (!inMemorySessionToken) {
    await checkHealth();
  }
}

async function parseJsonOrThrow<T>(res: Response): Promise<T> {
  syncSessionToken(res);
  let body: unknown = null;
  try {
    body = await res.json();
  } catch {
    if (!res.ok) {
      throw new Error(`Server error (${res.status}): ${res.statusText}`);
    }
  }

  if (!res.ok) {
    const errMsg =
      body && typeof body === 'object' && 'error' in body
        ? String((body as { error: unknown }).error)
        : `Request failed with status ${res.status}`;
    throw new Error(errMsg);
  }
  return body as T;
}

export async function checkHealth(): Promise<HealthStatus> {
  try {
    const res = await fetch('/api/health', {
      credentials: 'include',
      headers: buildHeaders(),
    });
    syncSessionToken(res);
    if (!res.ok) {
      return {
        status: 'offline',
        geminiConfigured: false,
        maxUploadBytes: 25 * 1024 * 1024,
        maxUploadMb: 25,
      };
    }
    const data = (await res.json()) as HealthStatus & {
      sessionToken?: string;
    };
    if (data.sessionToken) {
      inMemorySessionToken = data.sessionToken;
    }
    return {
      status: data.status,
      geminiConfigured: data.geminiConfigured,
      maxUploadBytes: data.maxUploadBytes,
      maxUploadMb: data.maxUploadMb,
    };
  } catch {
    return {
      status: 'offline',
      geminiConfigured: false,
      maxUploadBytes: 25 * 1024 * 1024,
      maxUploadMb: 25,
    };
  }
}

export async function uploadPdfDocument(
  file: File,
): Promise<UploadedDocumentResponse> {
  await ensureSessionInitialized();
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch('/api/documents/upload', {
    method: 'POST',
    body: formData,
    credentials: 'include',
    headers: buildHeaders(),
  });
  return parseJsonOrThrow<UploadedDocumentResponse>(res);
}

export async function listSessionDocuments(): Promise<DocumentSummaryItem[]> {
  await ensureSessionInitialized();
  const res = await fetch('/api/documents', {
    credentials: 'include',
    headers: buildHeaders(),
  });
  const data = await parseJsonOrThrow<{ documents: DocumentSummaryItem[] }>(res);
  return data.documents;
}

export async function fetchDocumentDetails(
  documentId: string,
): Promise<FullDocumentData> {
  await ensureSessionInitialized();
  const res = await fetch(`/api/documents/${encodeURIComponent(documentId)}`, {
    credentials: 'include',
    headers: buildHeaders(),
  });
  return parseJsonOrThrow<FullDocumentData>(res);
}

export async function deleteDocument(
  documentId: string,
): Promise<{ deleted: boolean; fileDeleted: boolean }> {
  await ensureSessionInitialized();
  const res = await fetch(`/api/documents/${encodeURIComponent(documentId)}`, {
    method: 'DELETE',
    credentials: 'include',
    headers: buildHeaders(),
  });
  return parseJsonOrThrow<{ deleted: boolean; fileDeleted: boolean }>(res);
}

export async function startDocumentAnalysis(
  documentId: string,
): Promise<{ jobId: string; status: string }> {
  await ensureSessionInitialized();
  const res = await fetch(
    `/api/documents/${encodeURIComponent(documentId)}/analyze`,
    {
      method: 'POST',
      credentials: 'include',
      headers: buildHeaders({ 'Content-Type': 'application/json' }),
    },
  );
  return parseJsonOrThrow<{ jobId: string; status: string }>(res);
}

export async function pollJobStatus(jobId: string): Promise<AnalysisJobStatus> {
  await ensureSessionInitialized();
  const res = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`, {
    credentials: 'include',
    headers: buildHeaders(),
  });
  return parseJsonOrThrow<AnalysisJobStatus>(res);
}

export async function cancelAnalysisJob(jobId: string): Promise<void> {
  await ensureSessionInitialized();
  const res = await fetch(`/api/jobs/${encodeURIComponent(jobId)}/cancel`, {
    method: 'POST',
    credentials: 'include',
    headers: buildHeaders(),
  });
  await parseJsonOrThrow<{ cancelled: boolean }>(res);
}

export async function streamChatQuestion(
  documentId: string,
  question: string,
  callbacks: {
    onMeta?: (sourcePages: number[]) => void;
    onChunk: (partialText: string) => void;
    onDone: (message: ChatMessage) => void;
    onError: (errorMsg: string) => void;
  },
): Promise<void> {
  await ensureSessionInitialized();
  const res = await fetch(
    `/api/documents/${encodeURIComponent(documentId)}/chat`,
    {
      method: 'POST',
      credentials: 'include',
      headers: buildHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ question }),
    },
  );

  if (!res.ok) {
    try {
      const errJson = await res.json();
      callbacks.onError(errJson.error || `Chat error (${res.status})`);
    } catch {
      callbacks.onError(`Chat request failed (${res.status})`);
    }
    return;
  }

  const reader = res.body?.getReader();
  if (!reader) {
    callbacks.onError('Streaming response unavailable.');
    return;
  }

  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const events = buffer.split('\n\n');
    buffer = events.pop() || '';

    for (const ev of events) {
      const dataLine = ev.split('\n').find((l) => l.startsWith('data: '));
      if (!dataLine) continue;
      try {
        const parsed = JSON.parse(dataLine.slice(6));
        if (parsed.type === 'meta') {
          callbacks.onMeta?.(parsed.sourcePages || []);
        } else if (parsed.type === 'chunk') {
          callbacks.onChunk(parsed.text || '');
        } else if (parsed.type === 'done') {
          callbacks.onDone(parsed.message);
        } else if (parsed.type === 'error') {
          callbacks.onError(parsed.error || 'Chat assistant error');
        }
      } catch {
        // Ignore partial chunk JSON edge cases
      }
    }
  }
}

export async function clearChatHistory(documentId: string): Promise<void> {
  await ensureSessionInitialized();
  const res = await fetch(
    `/api/documents/${encodeURIComponent(documentId)}/chat`,
    {
      method: 'DELETE',
      credentials: 'include',
      headers: buildHeaders(),
    },
  );
  await parseJsonOrThrow<{ cleared: boolean }>(res);
}

export async function comparePapers(
  documentId: string,
  otherDocumentId: string,
): Promise<PaperComparisonResult> {
  await ensureSessionInitialized();
  const res = await fetch(
    `/api/documents/${encodeURIComponent(documentId)}/compare`,
    {
      method: 'POST',
      credentials: 'include',
      headers: buildHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ otherDocumentId }),
    },
  );
  const data = await parseJsonOrThrow<{ comparison: PaperComparisonResult }>(
    res,
  );
  return data.comparison;
}

export async function generateLiteratureReviewApi(
  documentId: string,
  documentIds: string[],
): Promise<LiteratureReviewResult> {
  await ensureSessionInitialized();
  const res = await fetch(
    `/api/documents/${encodeURIComponent(documentId)}/literature-review`,
    {
      method: 'POST',
      credentials: 'include',
      headers: buildHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ documentIds }),
    },
  );
  const data = await parseJsonOrThrow<{
    literatureReview: LiteratureReviewResult;
  }>(res);
  return data.literatureReview;
}

export async function generateReport(
  documentId: string,
  format: 'pdf' | 'txt' | 'json',
  previewOnly = false,
): Promise<{
  reportId?: string;
  format?: string;
  filename?: string;
  downloadUrl?: string;
  payload: unknown;
}> {
  await ensureSessionInitialized();
  const res = await fetch(
    `/api/documents/${encodeURIComponent(documentId)}/report`,
    {
      method: 'POST',
      credentials: 'include',
      headers: buildHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ format, previewOnly }),
    },
  );
  return parseJsonOrThrow(res);
}

export async function downloadBlobFromUrl(
  url: string,
  fallbackFilename: string,
): Promise<void> {
  await ensureSessionInitialized();
  const res = await fetch(url, {
    credentials: 'include',
    headers: buildHeaders(),
  });
  if (!res.ok) {
    let msg = `Download failed (${res.status})`;
    try {
      const json = await res.json();
      if (json.error) msg = json.error;
    } catch {
      // Ignore
    }
    throw new Error(msg);
  }

  const blob = await res.blob();
  const disposition = res.headers.get('Content-Disposition') || '';
  const match = disposition.match(/filename="?([^"]+)"?/i);
  const filename = match?.[1] || fallbackFilename;

  const objectUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = objectUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
}
