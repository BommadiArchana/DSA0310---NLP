import { useEffect, useRef, useState } from 'react';
import { Clock, FileText, Trash2, X } from 'lucide-react';
import type {
  AnalysisJobStatus,
  DashboardSectionId,
  FullDocumentData,
  HealthStatus,
  UploadedDocumentResponse,
} from './types/papermind';
import {
  cancelAnalysisJob,
  checkHealth,
  deleteDocument,
  downloadBlobFromUrl,
  fetchDocumentDetails,
  pollJobStatus,
  startDocumentAnalysis,
  uploadPdfDocument,
} from './services/api';
import {
  deleteAnalysisFromHistory,
  loadAnalysisHistory,
  saveAnalysisToHistory,
} from './utils/indexedDb';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { UploadCard } from './components/UploadCard';
import { ProgressCard } from './components/ProgressCard';
import { FeatureCards } from './components/FeatureCards';
import { Dashboard } from './components/Dashboard';

type AppView = 'landing' | 'analyzing' | 'dashboard';

export default function App() {
  const [health, setHealth] = useState<HealthStatus>({
    status: 'ok',
    geminiConfigured: true,
    maxUploadBytes: 25 * 1024 * 1024,
    maxUploadMb: 25,
  });
  const [view, setView] = useState<AppView>('landing');
  const [uploadedDoc, setUploadedDoc] =
    useState<UploadedDocumentResponse | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [activeJob, setActiveJob] = useState<AnalysisJobStatus | null>(null);
  const [activeDoc, setActiveDoc] = useState<FullDocumentData | null>(null);
  const [activeSection, setActiveSection] =
    useState<DashboardSectionId>('overview');

  const [savedHistory, setSavedHistory] = useState<FullDocumentData[]>([]);
  const [showHistoryModal, setShowHistoryModal] = useState(false);

  const pollingRef = useRef<number | null>(null);

  const refreshHistory = async () => {
    const items = await loadAnalysisHistory();
    setSavedHistory(items);
  };

  useEffect(() => {
    void checkHealth().then(setHealth);
    void refreshHistory();
    return () => {
      if (pollingRef.current !== null) {
        window.clearInterval(pollingRef.current);
      }
    };
  }, []);

  const stopPolling = () => {
    if (pollingRef.current !== null) {
      window.clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
  };

  const handleFileSelected = async (file: File) => {
    setUploadError(null);

    if (
      !file.name.toLowerCase().endsWith('.pdf') &&
      file.type !== 'application/pdf'
    ) {
      setUploadError(
        'Invalid file format. Please select a PDF (.pdf) document.',
      );
      return;
    }
    if (file.size === 0) {
      setUploadError('The selected PDF file is empty (0 bytes).');
      return;
    }
    if (file.size > health.maxUploadBytes) {
      setUploadError(
        `PDF exceeds the ${health.maxUploadMb} MB upload limit. Please select a smaller document.`,
      );
      return;
    }

    // If replacing an existing un-analyzed uploaded document, remove old temp doc cleanly
    if (uploadedDoc) {
      deleteDocument(uploadedDoc.documentId).catch(() => {});
    }

    setIsUploading(true);
    try {
      const resp = await uploadPdfDocument(file);
      setUploadedDoc(resp);
    } catch (err) {
      setUploadedDoc(null);
      setUploadError(
        err instanceof Error ? err.message : 'Failed to upload PDF.',
      );
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveUploadedDoc = async () => {
    if (!uploadedDoc) return;
    const id = uploadedDoc.documentId;
    setUploadedDoc(null);
    setUploadError(null);
    try {
      await deleteDocument(id);
    } catch {
      // Ignore cleanup error if already expired
    }
  };

  const startAnalysisFlow = async (docMeta: UploadedDocumentResponse) => {
    stopPolling();
    setUploadError(null);

    const initialJob: AnalysisJobStatus = {
      jobId: '',
      documentId: docMeta.documentId,
      status: 'queued',
      progress: 5,
      statusMessage: 'Reading your research paper...',
      currentStage: 1,
      stages: {
        stage1: {
          status: 'in_progress',
          label: 'STAGE 1 – READING DOCUMENT',
          tasks: [
            'Validate uploaded PDF',
            'Extract document text',
            'Identify sections',
            'Identify page numbers',
          ],
        },
        stage2: {
          status: 'pending',
          label: 'STAGE 2 – EXTRACTING INSIGHTS',
          tasks: [
            'Identify research objectives',
            'Extract methodology',
            'Identify algorithms',
            'Extract datasets',
            'Identify experimental results',
          ],
        },
        stage3: {
          status: 'pending',
          label: 'STAGE 3 – PREPARING ANALYSIS',
          tasks: [
            'Send document content to Gemini',
            'Generate research analysis',
            'Generate research gap suggestions',
            'Prepare dashboard information',
          ],
        },
      },
      error: null,
      updatedAt: Date.now(),
    };

    setActiveJob(initialJob);
    setView('analyzing');

    try {
      const { jobId } = await startDocumentAnalysis(docMeta.documentId);
      setActiveJob((prev) => (prev ? { ...prev, jobId } : prev));

      const pollOnce = async () => {
        try {
          const status = await pollJobStatus(jobId);
          setActiveJob(status);

          if (status.status === 'completed') {
            stopPolling();
            const fullDoc = await fetchDocumentDetails(docMeta.documentId);
            setActiveDoc(fullDoc);
            setActiveSection('overview');
            setView('dashboard');
            await saveAnalysisToHistory(fullDoc);
            await refreshHistory();
          } else if (
            status.status === 'failed' ||
            status.status === 'cancelled'
          ) {
            stopPolling();
          }
        } catch (err) {
          stopPolling();
          setActiveJob((prev) =>
            prev
              ? {
                  ...prev,
                  status: 'failed',
                  error:
                    err instanceof Error
                      ? err.message
                      : 'Lost connection while checking analysis progress.',
                }
              : prev,
          );
        }
      };

      void pollOnce();
      pollingRef.current = window.setInterval(() => {
        void pollOnce();
      }, 750);
    } catch (err) {
      setActiveJob((prev) =>
        prev
          ? {
              ...prev,
              status: 'failed',
              error:
                err instanceof Error
                  ? err.message
                  : 'Unable to start AI analysis.',
            }
          : prev,
      );
    }
  };

  const handleAnalyzeClick = () => {
    if (!uploadedDoc) return;
    void startAnalysisFlow(uploadedDoc);
  };

  const handleCancelJob = async () => {
    stopPolling();
    if (activeJob?.jobId) {
      try {
        await cancelAnalysisJob(activeJob.jobId);
      } catch {
        // Ignore
      }
    }
    setActiveJob(null);
    setView('landing');
  };

  const handleRetryJob = () => {
    if (uploadedDoc) {
      void startAnalysisFlow(uploadedDoc);
    }
  };

  const handleOpenSavedPaper = async (item: FullDocumentData) => {
    setShowHistoryModal(false);
    try {
      // Try fetching live server copy first (in case server session is still active)
      const live = await fetchDocumentDetails(item.documentId);
      setActiveDoc(live);
    } catch {
      // Fallback to saved IndexedDB snapshot
      setActiveDoc({ ...item, isOfflineSnapshot: true });
    }
    setActiveSection('overview');
    setView('dashboard');
  };

  const handleDeleteSavedPaper = async (documentId: string) => {
    await deleteAnalysisFromHistory(documentId);
    try {
      await deleteDocument(documentId);
    } catch {
      // Ignore if already expired
    }
    await refreshHistory();
    if (activeDoc?.documentId === documentId) {
      setActiveDoc(null);
      setUploadedDoc(null);
      setView('landing');
    }
  };

  const handleUpdateDocumentState = (updated: FullDocumentData) => {
    setActiveDoc(updated);
    if (!updated.isOfflineSnapshot) {
      void saveAnalysisToHistory(updated).then(refreshHistory);
    }
  };

  const handleDownloadOriginalPdf = async () => {
    if (!activeDoc) return;
    try {
      await downloadBlobFromUrl(
        `/api/documents/${encodeURIComponent(activeDoc.documentId)}/pdf`,
        activeDoc.originalFilename,
      );
    } catch (err) {
      setUploadError(
        err instanceof Error ? err.message : 'Original PDF download failed.',
      );
    }
  };

  const handleGoHome = () => {
    stopPolling();
    setView('landing');
    setUploadedDoc(null);
    setUploadError(null);
  };

  return (
    <div className="min-h-screen bg-papermind-grid flex flex-col">
      <Header
        health={health}
        showDashboardActions={view === 'dashboard'}
        savedCount={savedHistory.length}
        onGoHome={handleGoHome}
        onOpenHistory={() => setShowHistoryModal(true)}
      />

      {view === 'landing' && (
        <main className="flex-1">
          <Hero />
          <UploadCard
            uploadedDoc={uploadedDoc}
            maxUploadMb={health.maxUploadMb}
            isUploading={isUploading}
            uploadError={uploadError}
            onFileSelected={handleFileSelected}
            onRemoveDocument={handleRemoveUploadedDoc}
            onAnalyzePaper={handleAnalyzeClick}
            onClearError={() => setUploadError(null)}
          />
          <FeatureCards />
        </main>
      )}

      {view === 'analyzing' && activeJob && uploadedDoc && (
        <main className="flex-1 pt-8 pb-16">
          <Hero />
          <ProgressCard
            filename={uploadedDoc.originalFilename}
            job={activeJob}
            onCancel={handleCancelJob}
            onRetry={handleRetryJob}
            onBackToUpload={() => {
              stopPolling();
              setView('landing');
            }}
          />
          <FeatureCards />
        </main>
      )}

      {view === 'dashboard' && activeDoc && (
        <Dashboard
          doc={activeDoc}
          activeSection={activeSection}
          onSelectSection={setActiveSection}
          onDownloadOriginalPdf={handleDownloadOriginalPdf}
          onReplacePaper={handleGoHome}
          onDeleteDocument={() =>
            void handleDeleteSavedPaper(activeDoc.documentId)
          }
          onUpdateDocumentState={handleUpdateDocumentState}
        />
      )}

      {/* Saved Papers History Modal */}
      {showHistoryModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="saved-history-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/45 backdrop-blur-xs"
        >
          <div className="bg-white rounded-2xl border border-purple-200 max-w-2xl w-full max-h-[80vh] flex flex-col shadow-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-purple-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Clock className="w-5 h-5 text-violet-600" />
                <h2
                  id="saved-history-title"
                  className="font-display text-lg font-bold text-[#13112C]"
                >
                  Saved Paper Analyses
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                aria-label="Close saved papers dialog"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-purple-50 hover:text-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
              {savedHistory.length === 0 ? (
                <p className="text-sm text-slate-500 text-center py-8">
                  No analyzed papers saved yet.
                </p>
              ) : (
                savedHistory.map((item) => (
                  <div
                    key={item.documentId}
                    className="flex items-center justify-between gap-4 p-4 rounded-xl border border-purple-200/70 bg-purple-50/30 hover:bg-purple-50/60 transition-colors"
                  >
                    <button
                      type="button"
                      onClick={() => void handleOpenSavedPaper(item)}
                      className="flex items-start gap-3 text-left min-w-0 flex-1"
                    >
                      <FileText className="w-5 h-5 text-violet-600 shrink-0 mt-0.5" />
                      <div className="min-w-0">
                        <p className="font-display text-sm font-bold text-[#13112C] truncate">
                          {item.extraction?.generalInfo.title ||
                            item.originalFilename}
                        </p>
                        <p className="text-xs text-slate-500 mt-0.5 font-mono tabular-nums">
                          {item.pageCount} pages ·{' '}
                          {new Date(item.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </button>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => void handleOpenSavedPaper(item)}
                        className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-violet-600 text-white hover:bg-violet-700"
                      >
                        Open
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          void handleDeleteSavedPaper(item.documentId)
                        }
                        aria-label={`Delete ${item.originalFilename}`}
                        className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
