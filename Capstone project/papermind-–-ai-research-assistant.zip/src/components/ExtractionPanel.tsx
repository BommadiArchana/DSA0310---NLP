import { ExternalLink, FileText } from 'lucide-react';
import type { FullDocumentData } from '../types/papermind';
import { CopyButton } from './CopyButton';

const NS = 'Not specified in the document';

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function ListOrFallback({ items }: { items: string[] }) {
  if (!items || items.length === 0) {
    return <p className="text-sm text-slate-500 italic">{NS}</p>;
  }
  return (
    <ul className="space-y-1.5 text-sm text-slate-700">
      {items.map((item, idx) => (
        <li key={idx} className="flex items-start gap-2">
          <span
            aria-hidden="true"
            className="mt-2 w-1.5 h-1.5 rounded-full bg-violet-400 shrink-0"
          />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

function FieldRow({ label, value }: { label: string; value: string }) {
  const isMissing = !value || value === NS;
  return (
    <div className="py-2.5 border-b border-purple-100/70 last:border-b-0">
      <dt className="text-xs font-semibold text-slate-500 mb-1">{label}</dt>
      <dd
        className={`text-sm leading-relaxed ${
          isMissing ? 'text-slate-500 italic' : 'text-slate-800'
        }`}
      >
        {value || NS}
      </dd>
    </div>
  );
}

export function PaperInformationView({ doc }: { doc: FullDocumentData }) {
  const g = doc.extraction?.generalInfo;
  const copyText = [
    `Title: ${g?.title || doc.originalFilename}`,
    `Authors: ${g?.authors.join(', ') || NS}`,
    `Publication Year: ${g?.publicationYear || NS}`,
    `Journal / Conference: ${g?.journalOrConference || NS}`,
    `DOI: ${g?.doi || NS}`,
    `Keywords: ${g?.keywords.join(', ') || NS}`,
    `Abstract:\n${g?.abstract || NS}`,
  ].join('\n\n');

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
          <div>
            <h2 className="font-display text-xl font-bold text-[#13112C]">
              General Paper Information
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Bibliographic metadata extracted directly from the uploaded PDF.
            </p>
          </div>
          <CopyButton text={copyText} label="Copy Metadata" />
        </div>

        <dl className="divide-y divide-purple-100/70">
          <FieldRow
            label="Research Paper Title"
            value={g?.title || doc.originalFilename}
          />
          <FieldRow
            label="Author Names"
            value={g?.authors && g.authors.length > 0 ? g.authors.join(', ') : NS}
          />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 py-2.5 border-b border-purple-100/70">
            <div>
              <dt className="text-xs font-semibold text-slate-500 mb-1">
                Publication Year
              </dt>
              <dd className="text-sm text-slate-800 font-mono tabular-nums">
                {g?.publicationYear || NS}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-semibold text-slate-500 mb-1">
                Journal or Conference
              </dt>
              <dd className="text-sm text-slate-800">
                {g?.journalOrConference || NS}
              </dd>
            </div>
            <div>
              <dt className="text-xs font-semibold text-slate-500 mb-1">DOI</dt>
              <dd className="text-sm text-slate-800 font-mono break-all">
                {g?.doi || NS}
              </dd>
            </div>
          </div>
          <FieldRow label="Abstract" value={g?.abstract || NS} />
          <FieldRow
            label="Keywords"
            value={
              g?.keywords && g.keywords.length > 0 ? g.keywords.join(' · ') : NS
            }
          />
        </dl>
      </div>

      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <h3 className="font-display text-lg font-bold text-[#13112C] mb-4">
          Document Structure &amp; File Details
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-5">
          <div className="p-3.5 rounded-xl bg-purple-50/50 border border-purple-100">
            <p className="text-xs text-slate-500">Original File</p>
            <p className="text-sm font-semibold text-[#13112C] truncate mt-1">
              {doc.originalFilename}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-purple-50/50 border border-purple-100">
            <p className="text-xs text-slate-500">File Size</p>
            <p className="text-sm font-semibold font-mono tabular-nums text-[#13112C] mt-1">
              {formatBytes(doc.fileSizeBytes)}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-purple-50/50 border border-purple-100">
            <p className="text-xs text-slate-500">Total Pages</p>
            <p className="text-sm font-semibold font-mono tabular-nums text-[#13112C] mt-1">
              {doc.pageCount}
            </p>
          </div>
          <div className="p-3.5 rounded-xl bg-purple-50/50 border border-purple-100">
            <p className="text-xs text-slate-500">Detected Sections</p>
            <p className="text-sm font-semibold font-mono tabular-nums text-[#13112C] mt-1">
              {doc.sections.length}
            </p>
          </div>
        </div>

        {doc.sections.length > 0 && (
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-2">
              Extracted Document Outline
            </p>
            <div className="divide-y divide-purple-100/70 border border-purple-100 rounded-xl overflow-hidden">
              {doc.sections.map((sec, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between gap-4 px-4 py-2.5 text-sm bg-white hover:bg-purple-50/30"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <FileText className="w-4 h-4 text-violet-500 shrink-0" />
                    <span className="font-medium text-slate-800 truncate">
                      {sec.title}
                    </span>
                  </div>
                  <span className="text-xs font-mono tabular-nums text-slate-500 shrink-0">
                    p. {sec.pageStart}
                    {sec.pageEnd !== sec.pageStart ? `–${sec.pageEnd}` : ''}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function ExtractionPanel({ doc }: { doc: FullDocumentData }) {
  const ext = doc.extraction;
  if (!ext) {
    return (
      <div className="bg-white rounded-2xl border border-purple-200/80 p-8 text-center text-slate-600">
        No smart extraction data is available for this document yet.
      </div>
    );
  }

  const gText = `General Paper Information\nTitle: ${ext.generalInfo.title}\nAuthors: ${ext.generalInfo.authors.join(', ') || NS}\nYear: ${ext.generalInfo.publicationYear}\nJournal/Conference: ${ext.generalInfo.journalOrConference}\nDOI: ${ext.generalInfo.doi}\nKeywords: ${ext.generalInfo.keywords.join(', ') || NS}\nAbstract: ${ext.generalInfo.abstract}`;

  const rText = `Research Information\nProblem: ${ext.researchInfo.researchProblem}\nMotivation: ${ext.researchInfo.researchMotivation}\nExisting System: ${ext.researchInfo.existingSystem}\nProposed System: ${ext.researchInfo.proposedSystem}\nObjectives:\n${ext.researchInfo.researchObjectives.join('\n') || NS}\nQuestions:\n${ext.researchInfo.researchQuestions.join('\n') || NS}\nContributions:\n${ext.researchInfo.researchContributions.join('\n') || NS}`;

  const tText = `Technical Information\nMethodology: ${ext.technicalInfo.researchMethodology}\nAlgorithms: ${ext.technicalInfo.algorithmsUsed.join(', ') || NS}\nML Models: ${ext.technicalInfo.mlModels.join(', ') || NS}\nDL Models: ${ext.technicalInfo.dlModels.join(', ') || NS}\nNLP Techniques: ${ext.technicalInfo.nlpTechniques.join(', ') || NS}\nDatasets: ${ext.technicalInfo.datasetNames.join(', ') || NS}\nDataset Descriptions: ${ext.technicalInfo.datasetDescriptions.join('; ') || NS}\nTools & Technologies: ${ext.technicalInfo.toolsAndTechnologies.join(', ') || NS}\nSoftware & Libraries: ${ext.technicalInfo.softwareAndLibraries.join(', ') || NS}`;

  const eText = `Experimental Information\nSetup: ${ext.experimentalInfo.experimentalSetup}\nEvaluation Methods: ${ext.experimentalInfo.evaluationMethods.join(', ') || NS}\nPerformance Summary: ${ext.experimentalInfo.performanceMetricsSummary}\nAccuracy: ${ext.experimentalInfo.accuracy}\nPrecision: ${ext.experimentalInfo.precision}\nRecall: ${ext.experimentalInfo.recall}\nF1-Score: ${ext.experimentalInfo.f1Score}\nMAE: ${ext.experimentalInfo.mae}\nRMSE: ${ext.experimentalInfo.rmse}\nOther Measurements: ${ext.experimentalInfo.otherMeasurements.join(', ') || NS}\nFindings:\n${ext.experimentalInfo.experimentalFindings.join('\n') || NS}`;

  const cText = `Research Conclusions\nKey Findings:\n${ext.conclusions.keyFindings.join('\n') || NS}\nStrengths:\n${ext.conclusions.strengths.join('\n') || NS}\nLimitations:\n${ext.conclusions.limitations.join('\n') || NS}\nChallenges:\n${ext.conclusions.challenges.join('\n') || NS}\nFuture Scope:\n${ext.conclusions.futureScope.join('\n') || NS}\nConclusion:\n${ext.conclusions.conclusion}`;

  const refText = ext.references
    .map((r, i) => `[${i + 1}] ${r.authors} (${r.year}). ${r.title}. ${r.doiOrUrl}`)
    .join('\n');

  return (
    <div className="space-y-6">
      {/* A. General Paper Information */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            A. General Paper Information
          </h3>
          <CopyButton text={gText} />
        </div>
        <dl>
          <FieldRow label="Title" value={ext.generalInfo.title} />
          <FieldRow
            label="Authors"
            value={ext.generalInfo.authors.join(', ') || NS}
          />
          <FieldRow
            label="Publication Year"
            value={ext.generalInfo.publicationYear}
          />
          <FieldRow
            label="Journal or Conference"
            value={ext.generalInfo.journalOrConference}
          />
          <FieldRow label="DOI" value={ext.generalInfo.doi} />
          <FieldRow label="Abstract" value={ext.generalInfo.abstract} />
          <FieldRow
            label="Keywords"
            value={ext.generalInfo.keywords.join(' · ') || NS}
          />
        </dl>
      </section>

      {/* B. Research Information */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            B. Research Information
          </h3>
          <CopyButton text={rText} />
        </div>
        <div className="space-y-4">
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Research Problem
            </p>
            <p className="text-sm text-slate-800 leading-relaxed">
              {ext.researchInfo.researchProblem}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Research Objectives
            </p>
            <ListOrFallback items={ext.researchInfo.researchObjectives} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Research Questions
            </p>
            <ListOrFallback items={ext.researchInfo.researchQuestions} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Research Motivation
            </p>
            <p className="text-sm text-slate-800 leading-relaxed">
              {ext.researchInfo.researchMotivation}
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-purple-100">
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1">
                Existing System
              </p>
              <p className="text-sm text-slate-800 leading-relaxed">
                {ext.researchInfo.existingSystem}
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1">
                Proposed System
              </p>
              <p className="text-sm text-slate-800 leading-relaxed">
                {ext.researchInfo.proposedSystem}
              </p>
            </div>
          </div>
          <div className="pt-2 border-t border-purple-100">
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Research Contributions
            </p>
            <ListOrFallback items={ext.researchInfo.researchContributions} />
          </div>
        </div>
      </section>

      {/* C. Technical Information */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            C. Technical Information
          </h3>
          <CopyButton text={tText} />
        </div>
        <div className="space-y-4">
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Research Methodology
            </p>
            <p className="text-sm text-slate-800 leading-relaxed">
              {ext.technicalInfo.researchMethodology}
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2 border-t border-purple-100">
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                Algorithms Used
              </p>
              <ListOrFallback items={ext.technicalInfo.algorithmsUsed} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                Machine Learning Models
              </p>
              <ListOrFallback items={ext.technicalInfo.mlModels} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                Deep Learning Models
              </p>
              <ListOrFallback items={ext.technicalInfo.dlModels} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                NLP Techniques
              </p>
              <ListOrFallback items={ext.technicalInfo.nlpTechniques} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                Dataset Names
              </p>
              <ListOrFallback items={ext.technicalInfo.datasetNames} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                Dataset Descriptions
              </p>
              <ListOrFallback items={ext.technicalInfo.datasetDescriptions} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                Tools &amp; Technologies
              </p>
              <ListOrFallback items={ext.technicalInfo.toolsAndTechnologies} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1.5">
                Software &amp; Libraries
              </p>
              <ListOrFallback items={ext.technicalInfo.softwareAndLibraries} />
            </div>
          </div>
        </div>
      </section>

      {/* D. Experimental Information */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            D. Experimental Information
          </h3>
          <CopyButton text={eText} />
        </div>
        <div className="space-y-4">
          <FieldRow
            label="Experimental Setup"
            value={ext.experimentalInfo.experimentalSetup}
          />
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Evaluation Methods
            </p>
            <ListOrFallback items={ext.experimentalInfo.evaluationMethods} />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 border-t border-purple-100">
            {[
              { label: 'Accuracy', val: ext.experimentalInfo.accuracy },
              { label: 'Precision', val: ext.experimentalInfo.precision },
              { label: 'Recall', val: ext.experimentalInfo.recall },
              { label: 'F1-Score', val: ext.experimentalInfo.f1Score },
              { label: 'MAE', val: ext.experimentalInfo.mae },
              { label: 'RMSE', val: ext.experimentalInfo.rmse },
            ].map((m) => (
              <div
                key={m.label}
                className="p-3 rounded-xl bg-purple-50/40 border border-purple-100"
              >
                <p className="text-xs font-semibold text-slate-500">{m.label}</p>
                <p className="text-sm font-mono tabular-nums font-medium text-[#13112C] mt-1">
                  {m.val || NS}
                </p>
              </div>
            ))}
          </div>
          <FieldRow
            label="Performance Metrics Summary"
            value={ext.experimentalInfo.performanceMetricsSummary}
          />
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Other Reported Measurements
            </p>
            <ListOrFallback items={ext.experimentalInfo.otherMeasurements} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Experimental Findings
            </p>
            <ListOrFallback items={ext.experimentalInfo.experimentalFindings} />
          </div>
        </div>
      </section>

      {/* E. Research Conclusions */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            E. Research Conclusions
          </h3>
          <CopyButton text={cText} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Key Findings
            </p>
            <ListOrFallback items={ext.conclusions.keyFindings} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Strengths
            </p>
            <ListOrFallback items={ext.conclusions.strengths} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Limitations
            </p>
            <ListOrFallback items={ext.conclusions.limitations} />
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Challenges
            </p>
            <ListOrFallback items={ext.conclusions.challenges} />
          </div>
          <div className="md:col-span-2">
            <p className="text-xs font-semibold text-slate-500 mb-1.5">
              Future Scope
            </p>
            <ListOrFallback items={ext.conclusions.futureScope} />
          </div>
          <div className="md:col-span-2 pt-2 border-t border-purple-100">
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Conclusion
            </p>
            <p className="text-sm text-slate-800 leading-relaxed">
              {ext.conclusions.conclusion}
            </p>
          </div>
        </div>
      </section>

      {/* F. References */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="font-display text-lg font-bold text-[#13112C]">
              F. Extracted References
            </h3>
            <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
              {ext.references.length} bibliographic entries extracted from the
              paper
            </p>
          </div>
          <CopyButton text={refText || NS} />
        </div>
        {ext.references.length === 0 ? (
          <p className="text-sm text-slate-500 italic">{NS}</p>
        ) : (
          <div className="divide-y divide-purple-100/70">
            {ext.references.map((ref, idx) => (
              <div key={idx} className="py-3 text-sm">
                <p className="font-medium text-slate-900">
                  <span className="font-mono text-xs text-violet-600 mr-2">
                    [{idx + 1}]
                  </span>
                  {ref.title}
                </p>
                <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 mt-1">
                  <span>{ref.authors}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{ref.year}</span>
                  {ref.doiOrUrl && ref.doiOrUrl !== NS && (
                    <>
                      <span aria-hidden="true">·</span>
                      {/^https?:\/\//i.test(ref.doiOrUrl) ? (
                        <a
                          href={ref.doiOrUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-violet-600 hover:underline break-all"
                        >
                          <span>{ref.doiOrUrl}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="font-mono break-all">
                          {ref.doiOrUrl}
                        </span>
                      )}
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
