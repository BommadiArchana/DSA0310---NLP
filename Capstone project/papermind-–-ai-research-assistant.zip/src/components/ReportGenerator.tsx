import { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Download,
  FileCode2,
  FileText,
  Loader2,
  Printer,
} from 'lucide-react';
import type { FullDocumentData } from '../types/papermind';
import { downloadBlobFromUrl, generateReport } from '../services/api';
import { CopyButton } from './CopyButton';
import { ErrorMessage } from './ErrorMessage';

interface ReportGeneratorProps {
  doc: FullDocumentData;
}

export function ReportGenerator({ doc }: ReportGeneratorProps) {
  const [previewPayload, setPreviewPayload] = useState<Record<string, unknown> | null>(null);
  const [isGenerating, setIsGenerating] = useState<'pdf' | 'txt' | 'json' | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    generateReport(doc.documentId, 'json', true)
      .then((res) => setPreviewPayload(res.payload as Record<string, unknown>))
      .catch(() => {});
  }, [doc.documentId]);

  const handleDownload = async (format: 'pdf' | 'txt' | 'json') => {
    setError(null);
    setSuccessMsg(null);
    setIsGenerating(format);
    try {
      const res = await generateReport(doc.documentId, format, false);
      setPreviewPayload(res.payload as Record<string, unknown>);
      if (res.downloadUrl && res.filename) {
        await downloadBlobFromUrl(res.downloadUrl, res.filename);
        setSuccessMsg(`Downloaded ${res.filename} successfully.`);
      } else {
        throw new Error('Server did not return a report download URL.');
      }
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : `Failed to generate ${format.toUpperCase()} report.`,
      );
    } finally {
      setIsGenerating(null);
    }
  };

  const ext = doc.extraction;
  const ana = doc.analysis;
  const NS = 'Not specified in the document';

  const fullTextForCopy = [
    `PAPERMIND – RESEARCH REPORT`,
    `Title: ${ext?.generalInfo.title || doc.originalFilename}`,
    `Authors: ${ext?.generalInfo.authors.join(', ') || NS}`,
    `Year: ${ext?.generalInfo.publicationYear || NS}`,
    `\n2. Abstract Summary\n${ana?.summary.detailedSummary || ext?.generalInfo.abstract || NS}`,
    `\n4. Research Problem\n${ana?.problemAnalysis.mainProblem || NS}`,
    `\n6. Methodology\n${ana?.methodologyAnalysis.proposedMethodology || NS}`,
    `\n10-11. Results & Performance\n${ana?.resultsAnalysis.explanation || NS}`,
    `\n12. Strengths & Limitations\nStrengths: ${ana?.strengthsAndWeaknesses.majorStrengths.join('; ') || NS}\nLimitations: ${ana?.strengthsAndWeaknesses.methodologicalLimitations.join('; ') || NS}`,
    `\n13. Research Gaps\nAuthor Gaps: ${ana?.researchGaps.authorIdentifiedGaps.join('; ') || NS}\nAI Suggestions: ${ana?.researchGaps.aiSuggestedOpportunities.join('; ') || NS}`,
    `\n15. Conclusion\n${ana?.finalConclusion || NS}`,
  ].join('\n');

  const previewSections = [
    {
      num: 1,
      title: 'Research Paper Information',
      body: `${ext?.generalInfo.title || doc.originalFilename} · Authors: ${ext?.generalInfo.authors.join(', ') || NS} · Year: ${ext?.generalInfo.publicationYear || NS} · DOI: ${ext?.generalInfo.doi || NS}`,
    },
    {
      num: 2,
      title: 'Abstract Summary',
      body: ana?.summary.shortSummary || ext?.generalInfo.abstract || NS,
    },
    {
      num: 3,
      title: 'Introduction & Purpose',
      body: ana?.summary.mainPurpose || ext?.researchInfo.researchMotivation || NS,
    },
    {
      num: 4,
      title: 'Research Problem',
      body: ana?.problemAnalysis.mainProblem || ext?.researchInfo.researchProblem || NS,
    },
    {
      num: 5,
      title: 'Research Objectives',
      body:
        ana?.objectivesExplained
          .map((o, i) => `${i + 1}. ${o.objective}`)
          .join(' ') || NS,
    },
    {
      num: 6,
      title: 'Methodology',
      body: ana?.methodologyAnalysis.proposedMethodology || NS,
    },
    {
      num: 7,
      title: 'Algorithms and Models',
      body:
        [
          ...(ext?.technicalInfo.algorithmsUsed || []),
          ...(ext?.technicalInfo.mlModels || []),
          ...(ext?.technicalInfo.dlModels || []),
        ].join(', ') || NS,
    },
    {
      num: 8,
      title: 'Dataset Information',
      body:
        ana?.datasetAnalysis
          .map((d) => `${d.datasetName} (${d.numberOfRecords})`)
          .join('; ') || NS,
    },
    {
      num: 9,
      title: 'Tools and Technologies',
      body:
        [
          ...(ext?.technicalInfo.toolsAndTechnologies || []),
          ...(ext?.technicalInfo.softwareAndLibraries || []),
        ].join(', ') || NS,
    },
    {
      num: 10,
      title: 'Experimental Results',
      body:
        ext?.experimentalInfo.experimentalFindings.join(' ') ||
        ext?.experimentalInfo.experimentalSetup ||
        NS,
    },
    {
      num: 11,
      title: 'Performance Analysis',
      body: ana?.resultsAnalysis.explanation || NS,
    },
    {
      num: 12,
      title: 'Strengths and Limitations',
      body: `Strengths: ${ana?.strengthsAndWeaknesses.majorStrengths.join('; ') || NS} | Limitations: ${ana?.strengthsAndWeaknesses.methodologicalLimitations.join('; ') || NS}`,
    },
    {
      num: 13,
      title: 'Research Gap',
      body: `Author Gaps: ${ana?.researchGaps.authorIdentifiedGaps.join('; ') || NS} | AI Suggestions: ${ana?.researchGaps.aiSuggestedOpportunities.join('; ') || NS}`,
    },
    {
      num: 14,
      title: 'Future Scope (AI-Generated)',
      body: ana?.futureScope.futureResearchDirections.join('; ') || NS,
    },
    {
      num: 15,
      title: 'Conclusion',
      body: ana?.finalConclusion || NS,
    },
    {
      num: 16,
      title: 'References',
      body: `${ext?.references.length || 0} extracted bibliographic references included in export.`,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="no-print bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="font-display text-xl font-bold text-[#13112C]">
              Generate Research Report
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Export the complete 16-section research analysis as PDF, TXT, or
              structured JSON.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <CopyButton text={fullTextForCopy} label="Copy Summary" />
            <button
              type="button"
              onClick={() => window.print()}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-lg border border-purple-200 bg-white text-slate-700 hover:text-violet-700 hover:border-violet-300 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Report</span>
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-4">
            <ErrorMessage
              title="Report Generation Failed"
              message={error}
              onDismiss={() => setError(null)}
            />
          </div>
        )}

        {successMsg && (
          <div className="mb-4 rounded-xl border border-emerald-200 bg-emerald-50 p-3.5 text-sm text-emerald-900 flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            type="button"
            disabled={isGenerating !== null}
            onClick={() => void handleDownload('pdf')}
            className="flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 shadow-sm transition-all disabled:opacity-60"
          >
            {isGenerating === 'pdf' ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            <span>Download PDF Report</span>
          </button>

          <button
            type="button"
            disabled={isGenerating !== null}
            onClick={() => void handleDownload('txt')}
            className="flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-xl text-sm font-semibold border border-purple-200 bg-purple-50/50 text-[#13112C] hover:bg-violet-50 hover:border-violet-300 transition-all disabled:opacity-60"
          >
            {isGenerating === 'txt' ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <FileText className="w-4 h-4 text-violet-600" />
            )}
            <span>Download TXT Report</span>
          </button>

          <button
            type="button"
            disabled={isGenerating !== null}
            onClick={() => void handleDownload('json')}
            className="flex items-center justify-center gap-2.5 px-5 py-3.5 rounded-xl text-sm font-semibold border border-purple-200 bg-purple-50/50 text-[#13112C] hover:bg-violet-50 hover:border-violet-300 transition-all disabled:opacity-60"
          >
            {isGenerating === 'json' ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <FileCode2 className="w-4 h-4 text-blue-600" />
            )}
            <span>Download JSON Report</span>
          </button>
        </div>
      </div>

      {/* 16-Section Report Preview */}
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 sm:p-8 shadow-xs">
        <div className="flex items-center justify-between border-b border-purple-100 pb-4 mb-6">
          <div>
            <p className="text-xs font-semibold text-violet-700">
              Report Preview (16 Sections)
            </p>
            <h3 className="font-display text-lg font-bold text-[#13112C] mt-0.5">
              {ext?.generalInfo.title || doc.originalFilename}
            </h3>
          </div>
          {previewPayload && (
            <span className="text-xs font-mono tabular-nums text-slate-500">
              {doc.pageCount} source pages
            </span>
          )}
        </div>

        <div className="space-y-5">
          {previewSections.map((sec) => (
            <div
              key={sec.num}
              className="pb-4 border-b border-purple-100/70 last:border-b-0 last:pb-0"
            >
              <h4 className="font-display text-sm font-bold text-[#13112C] mb-1">
                {sec.num}. {sec.title}
              </h4>
              <p className="text-sm text-slate-700 leading-relaxed">{sec.body}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
