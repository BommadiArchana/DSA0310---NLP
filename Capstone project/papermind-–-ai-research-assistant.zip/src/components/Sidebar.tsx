import {
  BarChart3,
  BookOpen,
  BrainCircuit,
  Compass,
  Database,
  Download,
  FileCheck2,
  FileSearch,
  GitCompare,
  Layers,
  LayoutDashboard,
  Lightbulb,
  MessageSquareText,
  Trash2,
  Upload,
} from 'lucide-react';
import type { DashboardSectionId } from '../types/papermind';

interface SidebarProps {
  activeSection: DashboardSectionId;
  onSelectSection: (id: DashboardSectionId) => void;
  paperTitle: string;
  pageCount: number;
  isOfflineSnapshot?: boolean;
  onDownloadOriginalPdf: () => void;
  onReplacePaper: () => void;
  onRequestDelete: () => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: Array<{
  id: DashboardSectionId;
  label: string;
  icon: typeof LayoutDashboard;
}> = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'paper-info', label: 'Paper Information', icon: FileCheck2 },
  { id: 'smart-extraction', label: 'Smart Extraction', icon: FileSearch },
  { id: 'ai-analysis', label: 'AI Analysis', icon: BrainCircuit },
  { id: 'methodology', label: 'Methodology', icon: Layers },
  { id: 'dataset-analysis', label: 'Dataset Analysis', icon: Database },
  { id: 'results', label: 'Results', icon: BarChart3 },
  { id: 'research-gaps', label: 'Research Gaps', icon: Compass },
  { id: 'future-scope', label: 'Future Scope', icon: Lightbulb },
  { id: 'literature-review', label: 'Literature Review', icon: BookOpen },
  { id: 'compare-papers', label: 'Compare Papers', icon: GitCompare },
  { id: 'ai-assistant', label: 'AI Research Assistant', icon: MessageSquareText },
  { id: 'download-report', label: 'Download Report', icon: Download },
];

export function Sidebar({
  activeSection,
  onSelectSection,
  paperTitle,
  pageCount,
  isOfflineSnapshot,
  onDownloadOriginalPdf,
  onReplacePaper,
  onRequestDelete,
  mobileOpen,
  onCloseMobile,
}: SidebarProps) {
  const navContent = (
    <div className="flex flex-col h-full bg-white border-r border-purple-100 w-68">
      <div className="p-4 border-b border-purple-100">
        <p className="text-xs font-semibold text-violet-600 mb-1">
          Active Paper · <span className="font-mono tabular-nums">{pageCount} pages</span>
        </p>
        <p
          className="font-display text-sm font-bold text-[#13112C] line-clamp-2 leading-snug"
          title={paperTitle}
        >
          {paperTitle}
        </p>
      </div>

      <nav
        aria-label="Dashboard sections"
        className="flex-1 overflow-y-auto p-3 space-y-1"
      >
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onSelectSection(item.id);
                onCloseMobile();
              }}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors text-left whitespace-nowrap ${
                active
                  ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-violet-700 hover:bg-purple-50/80'
              }`}
            >
              <Icon
                className={`w-4 h-4 shrink-0 ${
                  active ? 'text-white' : 'text-slate-400'
                }`}
              />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-purple-100 space-y-1.5 bg-purple-50/30">
        {!isOfflineSnapshot && (
          <button
            type="button"
            onClick={onDownloadOriginalPdf}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-violet-700 hover:bg-white rounded-lg border border-transparent hover:border-purple-200 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-violet-600 shrink-0" />
            <span>Download Original PDF</span>
          </button>
        )}
        <button
          type="button"
          onClick={onReplacePaper}
          className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-slate-700 hover:text-violet-700 hover:bg-white rounded-lg border border-transparent hover:border-purple-200 transition-colors"
        >
          <Upload className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          <span>Upload / Replace Paper</span>
        </button>
        <button
          type="button"
          onClick={onRequestDelete}
          className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5 shrink-0" />
          <span>Delete Analysis</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      <aside className="no-print hidden lg:block shrink-0">{navContent}</aside>

      {mobileOpen && (
        <div className="no-print fixed inset-0 z-40 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs"
            onClick={onCloseMobile}
          />
          <div className="relative z-50 h-full shadow-xl">{navContent}</div>
        </div>
      )}
    </>
  );
}
