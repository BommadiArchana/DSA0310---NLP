import {
  CheckCircle2,
  Circle,
  Loader2,
  RefreshCw,
  Sparkles,
  XCircle,
} from 'lucide-react';
import type { AnalysisJobStatus, JobStageStatus } from '../types/papermind';
import { ErrorMessage } from './ErrorMessage';

interface ProgressCardProps {
  filename: string;
  job: AnalysisJobStatus;
  onCancel: () => void;
  onRetry: () => void;
  onBackToUpload: () => void;
}

function StageIcon({ status }: { status: JobStageStatus }) {
  if (status === 'completed') {
    return <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />;
  }
  if (status === 'in_progress') {
    return (
      <Loader2 className="w-5 h-5 text-violet-600 animate-spin shrink-0" />
    );
  }
  if (status === 'failed') {
    return <XCircle className="w-5 h-5 text-rose-600 shrink-0" />;
  }
  return <Circle className="w-5 h-5 text-slate-300 shrink-0" />;
}

export function ProgressCard({
  filename,
  job,
  onCancel,
  onRetry,
  onBackToUpload,
}: ProgressCardProps) {
  const stageList = [job.stages.stage1, job.stages.stage2, job.stages.stage3];
  const isFailed = job.status === 'failed';
  const isCancelled = job.status === 'cancelled';

  return (
    <div className="max-w-3xl mx-auto px-4">
      <div className="bg-white rounded-3xl border border-purple-200/80 shadow-[0_14px_45px_rgba(109,40,217,0.08)] p-6 sm:p-10">
        <div className="flex flex-col items-center text-center mb-8">
          <div className="inline-flex items-center gap-2.5 px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 via-purple-600 to-blue-600 text-white font-semibold text-base shadow-md shadow-violet-500/20 mb-4">
            {isFailed ? (
              <XCircle className="w-5 h-5" />
            ) : (
              <Sparkles className="w-5 h-5 animate-pulse" />
            )}
            <span>
              {isFailed
                ? 'Analysis Failed'
                : isCancelled
                  ? 'Analysis Cancelled'
                  : 'Analyzing Your Paper...'}
            </span>
          </div>

          <p className="text-sm font-medium text-slate-700 truncate max-w-full">
            {filename}
          </p>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between gap-4 mb-2.5">
            <span className="text-sm font-semibold text-[#13112C]">
              {job.statusMessage}
            </span>
            <span className="font-mono tabular-nums text-sm font-bold text-violet-700 shrink-0">
              {job.progress}%
            </span>
          </div>
          <div className="w-full h-3 rounded-full bg-purple-100 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-300 ${
                isFailed
                  ? 'bg-rose-500'
                  : 'bg-gradient-to-r from-violet-600 via-purple-600 to-blue-600'
              }`}
              style={{ width: `${Math.max(4, job.progress)}%` }}
            />
          </div>
        </div>

        {isFailed && job.error && (
          <div className="mb-6">
            <ErrorMessage
              title="Analysis Could Not Complete"
              message={job.error}
              onRetry={onRetry}
            />
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {stageList.map((stage, idx) => {
            const active = stage.status === 'in_progress';
            const done = stage.status === 'completed';
            const failed = stage.status === 'failed';
            return (
              <div
                key={idx}
                className={`rounded-2xl border p-4 transition-colors ${
                  active
                    ? 'border-violet-300 bg-violet-50/70'
                    : done
                      ? 'border-emerald-200 bg-emerald-50/50'
                      : failed
                        ? 'border-rose-200 bg-rose-50/50'
                        : 'border-slate-200/80 bg-slate-50/60'
                }`}
              >
                <div className="flex items-center gap-2.5 mb-3">
                  <StageIcon status={stage.status} />
                  <span className="text-xs font-bold tracking-wide text-[#13112C]">
                    {stage.label}
                  </span>
                </div>
                <ul className="space-y-1.5 text-xs text-slate-600">
                  {stage.tasks.map((task, tIdx) => (
                    <li key={tIdx} className="flex items-start gap-2">
                      <span
                        aria-hidden="true"
                        className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${
                          done
                            ? 'bg-emerald-500'
                            : active
                              ? 'bg-violet-500'
                              : 'bg-slate-300'
                        }`}
                      />
                      <span>{task}</span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3">
          {!isFailed && !isCancelled && job.status !== 'completed' && (
            <button
              type="button"
              onClick={onCancel}
              className="px-5 py-2.5 rounded-xl text-sm font-semibold border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 transition-colors"
            >
              Cancel Analysis
            </button>
          )}
          {(isFailed || isCancelled) && (
            <>
              <button
                type="button"
                onClick={onRetry}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 shadow-sm transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Retry Analysis</span>
              </button>
              <button
                type="button"
                onClick={onBackToUpload}
                className="px-5 py-2.5 rounded-xl text-sm font-semibold border border-purple-200 bg-white text-slate-700 hover:bg-purple-50 transition-colors"
              >
                Back to Upload
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
