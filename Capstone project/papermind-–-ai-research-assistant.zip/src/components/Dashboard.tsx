import { useState } from 'react';
import {
  ArrowRight,
  BarChart3,
  BookOpen,
  Compass,
  Cpu,
  Database,
  Download,
  FileText,
  Layers,
  Menu,
  MessageSquareText,
  Trash2,
} from 'lucide-react';
import type {
  ChatMessage,
  DashboardSectionId,
  FullDocumentData,
  LiteratureReviewResult,
  PaperComparisonResult,
} from '../types/papermind';
import { Sidebar } from './Sidebar';
import { ExtractionPanel, PaperInformationView } from './ExtractionPanel';
import {
  AIAnalysisView,
  DatasetAnalysisView,
  FutureScopeView,
  MethodologyView,
  ResearchGapsView,
} from './AnalysisPanel';
import { ResultsPanel } from './ResultsPanel';
import { ChatAssistant } from './ChatAssistant';
import { ComparisonPanel } from './ComparisonPanel';
import { LiteratureReview } from './LiteratureReview';
import { ReportGenerator } from './ReportGenerator';
import { CopyButton } from './CopyButton';

interface DashboardProps {
  doc: FullDocumentData;
  activeSection: DashboardSectionId;
  onSelectSection: (section: DashboardSectionId) => void;
  onDownloadOriginalPdf: () => void;
  onReplacePaper: () => void;
  onDeleteDocument: () => void;
  onUpdateDocumentState: (updated: FullDocumentData) => void;
}

export function Dashboard({
  doc,
  activeSection,
  onSelectSection,
  onDownloadOriginalPdf,
  onReplacePaper,
  onDeleteDocument,
  onUpdateDocumentState,
}: DashboardProps) {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const ext = doc.extraction;
  const ana = doc.analysis;
  const paperTitle = ext?.generalInfo.title || doc.originalFilename;
  const authorsText =
    ext?.generalInfo.authors && ext.generalInfo.authors.length > 0
      ? ext.generalInfo.authors.join(', ')
      : 'Not specified in the document';
  const pubYear =
    ext?.generalInfo.publicationYear || 'Not specified in the document';

  const algorithmsCount = new Set([
    ...(ext?.technicalInfo.algorithmsUsed || []),
    ...(ext?.technicalInfo.mlModels || []),
    ...(ext?.technicalInfo.dlModels || []),
  ]).size;

  const datasetsCount = Math.max(
    ext?.technicalInfo.datasetNames?.length || 0,
    ana?.datasetAnalysis?.length || 0,
  );

  const handleChatUpdated = (chatHistory: ChatMessage[]) => {
    onUpdateDocumentState({ ...doc, chatHistory });
  };

  const handleComparisonSaved = (lastComparison: PaperComparisonResult) => {
    onUpdateDocumentState({ ...doc, lastComparison });
  };

  const handleLiteratureReviewSaved = (
    lastLiteratureReview: LiteratureReviewResult,
  ) => {
    onUpdateDocumentState({ ...doc, lastLiteratureReview });
  };

  const renderSection = () => {
    switch (activeSection) {
      case 'overview':
        return (
          <div className="space-y-6">
            {/* Hero Summary Banner */}
            <div className="bg-white rounded-2xl border border-purple-200/80 p-6 sm:p-7 shadow-xs">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-2">
                    <span className="font-semibold text-violet-700">
                      Analysis Status: {doc.analysisStatus === 'completed' ? 'Completed' : doc.analysisStatus}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      Year: {pubYear}
                    </span>
                    {doc.ocrPagesCount > 0 && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>OCR processed ({doc.ocrPagesCount} pages)</span>
                      </>
                    )}
                  </div>
                  <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#13112C] leading-tight">
                    {paperTitle}
                  </h1>
                  <p className="text-sm text-slate-600 mt-2">{authorsText}</p>
                </div>

                {ana?.summary.shortSummary && (
                  <CopyButton
                    text={`${paperTitle}\nAuthors: ${authorsText}\nYear: ${pubYear}\n\nSummary:\n${ana.summary.shortSummary}`}
                    label="Copy Overview"
                  />
                )}
              </div>

              {ana?.summary.shortSummary && (
                <p className="mt-5 pt-5 border-t border-purple-100 text-sm sm:text-base text-slate-700 leading-relaxed">
                  {ana.summary.shortSummary}
                </p>
              )}
            </div>

            {/* Key Quantitative Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white rounded-2xl border border-purple-200/80 p-5 shadow-xs">
                <div className="flex items-center justify-between text-slate-500 mb-2">
                  <span className="text-xs font-semibold">Total Pages</span>
                  <FileText className="w-4 h-4 text-violet-600" />
                </div>
                <p className="font-display text-2xl font-extrabold font-mono tabular-nums text-[#13112C]">
                  {doc.pageCount}
                </p>
              </div>

              <div className="bg-white rounded-2xl border border-purple-200/80 p-5 shadow-xs">
                <div className="flex items-center justify-between text-slate-500 mb-2">
                  <span className="text-xs font-semibold">
                    Extracted Sections
                  </span>
                  <Layers className="w-4 h-4 text-blue-600" />
                </div>
                <p className="font-display text-2xl font-extrabold font-mono tabular-nums text-[#13112C]">
                  {doc.sections.length}
                </p>
              </div>

              <div className="bg-white rounded-2xl border border-purple-200/80 p-5 shadow-xs">
                <div className="flex items-center justify-between text-slate-500 mb-2">
                  <span className="text-xs font-semibold">
                    Algorithms &amp; Models
                  </span>
                  <Cpu className="w-4 h-4 text-purple-600" />
                </div>
                <p className="font-display text-2xl font-extrabold font-mono tabular-nums text-[#13112C]">
                  {algorithmsCount}
                </p>
              </div>

              <div className="bg-white rounded-2xl border border-purple-200/80 p-5 shadow-xs">
                <div className="flex items-center justify-between text-slate-500 mb-2">
                  <span className="text-xs font-semibold">
                    Identified Datasets
                  </span>
                  <Database className="w-4 h-4 text-emerald-600" />
                </div>
                <p className="font-display text-2xl font-extrabold font-mono tabular-nums text-[#13112C]">
                  {datasetsCount}
                </p>
              </div>
            </div>

            {/* Key Findings & Research Gaps Preview + Quick Jump */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <h2 className="font-display text-lg font-bold text-[#13112C] mb-3">
                    Key Contributions &amp; Purpose
                  </h2>
                  <p className="text-sm text-slate-700 leading-relaxed mb-4">
                    {ana?.summary.mainPurpose ||
                      ext?.researchInfo.researchProblem ||
                      'Not specified in the document'}
                  </p>
                  {ana?.summary.importantContributions &&
                    ana.summary.importantContributions.length > 0 && (
                      <ul className="space-y-1.5 text-sm text-slate-600 mb-4">
                        {ana.summary.importantContributions
                          .slice(0, 4)
                          .map((c, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <span className="mt-2 w-1.5 h-1.5 rounded-full bg-violet-500 shrink-0" />
                              <span>{c}</span>
                            </li>
                          ))}
                      </ul>
                    )}
                </div>
                <button
                  type="button"
                  onClick={() => onSelectSection('ai-analysis')}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-violet-700 hover:text-violet-900 mt-2"
                >
                  <span>View Full AI Analysis</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs flex flex-col justify-between">
                <div>
                  <h2 className="font-display text-lg font-bold text-[#13112C] mb-3">
                    Quick Research Workflows
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => onSelectSection('ai-assistant')}
                      className="flex items-center gap-3 p-3.5 rounded-xl border border-purple-200/80 bg-purple-50/40 hover:bg-violet-50 hover:border-violet-300 text-left transition-colors"
                    >
                      <MessageSquareText className="w-5 h-5 text-violet-600 shrink-0" />
                      <div>
                        <p className="text-sm font-bold text-[#13112C]">
                          Ask AI Assistant
                        </p>
                        <p className="text-xs text-slate-500">
                          Q&amp;A with page citations
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onSelectSection('research-gaps')}
                      className="flex items-center gap-3 p-3.5 rounded-xl border border-purple-200/80 bg-purple-50/40 hover:bg-violet-50 hover:border-violet-300 text-left transition-colors"
                    >
                      <Compass className="w-5 h-5 text-blue-600 shrink-0" />
                      <div>
                        <p className="text-sm font-bold text-[#13112C]">
                          Research Gaps
                        </p>
                        <p className="text-xs text-slate-500">
                          Author &amp; AI gaps
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onSelectSection('literature-review')}
                      className="flex items-center gap-3 p-3.5 rounded-xl border border-purple-200/80 bg-purple-50/40 hover:bg-violet-50 hover:border-violet-300 text-left transition-colors"
                    >
                      <BookOpen className="w-5 h-5 text-emerald-600 shrink-0" />
                      <div>
                        <p className="text-sm font-bold text-[#13112C]">
                          Literature Review
                        </p>
                        <p className="text-xs text-slate-500">
                          Synthesize review
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() => onSelectSection('download-report')}
                      className="flex items-center gap-3 p-3.5 rounded-xl border border-purple-200/80 bg-purple-50/40 hover:bg-violet-50 hover:border-violet-300 text-left transition-colors"
                    >
                      <Download className="w-5 h-5 text-purple-600 shrink-0" />
                      <div>
                        <p className="text-sm font-bold text-[#13112C]">
                          Generate Report
                        </p>
                        <p className="text-xs text-slate-500">
                          PDF, TXT &amp; JSON export
                        </p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {ana &&
              ana.resultsAnalysis.hasSufficientNumericalDataForChart &&
              ana.resultsAnalysis.metricsTable.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500 inline-flex items-center gap-1.5">
                      <BarChart3 className="w-3.5 h-3.5 text-violet-600" />
                      Experimental Results Preview
                    </span>
                    <button
                      type="button"
                      onClick={() => onSelectSection('results')}
                      className="text-xs font-bold text-violet-700 hover:underline"
                    >
                      Open Full Results
                    </button>
                  </div>
                  <ResultsPanel analysis={ana} />
                </div>
              )}
          </div>
        );

      case 'paper-info':
        return <PaperInformationView doc={doc} />;
      case 'smart-extraction':
        return <ExtractionPanel doc={doc} />;
      case 'ai-analysis':
        return ana ? (
          <AIAnalysisView analysis={ana} />
        ) : (
          <EmptyAnalysisNotice />
        );
      case 'methodology':
        return ana ? (
          <MethodologyView analysis={ana} />
        ) : (
          <EmptyAnalysisNotice />
        );
      case 'dataset-analysis':
        return ana ? (
          <DatasetAnalysisView analysis={ana} />
        ) : (
          <EmptyAnalysisNotice />
        );
      case 'results':
        return ana ? (
          <ResultsPanel analysis={ana} />
        ) : (
          <EmptyAnalysisNotice />
        );
      case 'research-gaps':
        return ana ? (
          <ResearchGapsView analysis={ana} />
        ) : (
          <EmptyAnalysisNotice />
        );
      case 'future-scope':
        return ana ? (
          <FutureScopeView analysis={ana} />
        ) : (
          <EmptyAnalysisNotice />
        );
      case 'literature-review':
        return (
          <LiteratureReview
            primaryDoc={doc}
            onLiteratureReviewSaved={handleLiteratureReviewSaved}
          />
        );
      case 'compare-papers':
        return (
          <ComparisonPanel
            primaryDoc={doc}
            onComparisonSaved={handleComparisonSaved}
          />
        );
      case 'ai-assistant':
        return (
          <ChatAssistant
            documentId={doc.documentId}
            paperTitle={paperTitle}
            initialHistory={doc.chatHistory}
            isOfflineSnapshot={doc.isOfflineSnapshot}
            onHistoryUpdated={handleChatUpdated}
          />
        );
      case 'download-report':
        return <ReportGenerator doc={doc} />;
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-4rem)]">
      <Sidebar
        activeSection={activeSection}
        onSelectSection={onSelectSection}
        paperTitle={paperTitle}
        pageCount={doc.pageCount}
        isOfflineSnapshot={doc.isOfflineSnapshot}
        onDownloadOriginalPdf={onDownloadOriginalPdf}
        onReplacePaper={onReplacePaper}
        onRequestDelete={() => setShowDeleteConfirm(true)}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto w-full">
        {/* Mobile section bar */}
        <div className="no-print lg:hidden mb-4 flex items-center justify-between gap-3 bg-white rounded-xl border border-purple-200/80 px-4 py-2.5 shadow-xs">
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(true)}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#13112C]"
          >
            <Menu className="w-4 h-4 text-violet-600" />
            <span>Dashboard Menu</span>
          </button>
          <span className="text-xs font-medium text-violet-700 capitalize">
            {activeSection.replace('-', ' ')}
          </span>
        </div>

        {renderSection()}
      </main>

      {/* Delete Confirmation Dialog */}
      {showDeleteConfirm && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-dialog-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/45 backdrop-blur-xs"
        >
          <div className="bg-white rounded-2xl border border-purple-200 max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center gap-3 text-rose-600 mb-3">
              <Trash2 className="w-5 h-5" />
              <h3
                id="delete-dialog-title"
                className="font-display text-lg font-bold text-[#13112C]"
              >
                Delete Analyzed Paper?
              </h3>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed mb-6">
              This removes the uploaded PDF, extracted text, AI analysis, and
              chat history for{' '}
              <span className="font-semibold text-[#13112C]">
                {doc.originalFilename}
              </span>{' '}
              from the server and your saved browser history.
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 text-sm font-semibold rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowDeleteConfirm(false);
                  onDeleteDocument();
                }}
                className="px-4 py-2 text-sm font-semibold rounded-xl bg-rose-600 text-white hover:bg-rose-700"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function EmptyAnalysisNotice() {
  return (
    <div className="bg-white rounded-2xl border border-purple-200/80 p-8 text-center text-slate-600">
      Analysis data is not yet available for this section.
    </div>
  );
}
