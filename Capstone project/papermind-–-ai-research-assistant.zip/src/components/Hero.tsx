import { Sparkles } from 'lucide-react';

export function Hero() {
  return (
    <section className="text-center max-w-3xl mx-auto pt-10 sm:pt-14 pb-8 px-4">
      <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 border border-purple-200/80 shadow-xs text-xs sm:text-sm font-semibold text-violet-700 mb-6">
        <Sparkles className="w-4 h-4 text-violet-600" />
        <span>AI-Powered Research Analysis</span>
      </div>

      <h1
        className="font-display text-4xl sm:text-5xl lg:text-[54px] font-extrabold tracking-tight text-[#13112C] leading-[1.12] mb-5"
        style={{ textWrap: 'balance' }}
      >
        Understand Research Papers
        <br />
        <span className="bg-gradient-to-r from-violet-600 via-purple-600 to-blue-600 bg-clip-text text-transparent">
          Smarter &amp; Faster
        </span>
      </h1>

      <p className="text-base sm:text-lg text-slate-600 leading-relaxed max-w-2xl mx-auto">
        Upload a research or conference paper and transform complex academic
        content into clear, structured and meaningful insights.
      </p>
    </section>
  );
}
