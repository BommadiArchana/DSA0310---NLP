import { AlertCircle, BookCheck, Sparkles } from 'lucide-react';
import type { AIAnalysisData } from '../types/papermind';
import { CopyButton } from './CopyButton';

function BulletList({ items, emptyText = 'Not specified in the document' }: { items: string[]; emptyText?: string }) {
  if (!items || items.length === 0) {
    return <p className="text-sm text-slate-500 italic">{emptyText}</p>;
  }
  return (
    <ul className="space-y-2 text-sm text-slate-700 leading-relaxed">
      {items.map((item, idx) => (
        <li key={idx} className="flex items-start gap-2.5">
          <span
            aria-hidden="true"
            className="mt-2 w-1.5 h-1.5 rounded-full bg-violet-500 shrink-0"
          />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export function AIAnalysisView({ analysis }: { analysis: AIAnalysisData }) {
  const summaryCopy = `Short Summary:\n${analysis.summary.shortSummary}\n\nDetailed Summary:\n${analysis.summary.detailedSummary}\n\nMain Purpose:\n${analysis.summary.mainPurpose}\n\nContributions:\n${analysis.summary.importantContributions.join('\n')}`;
  const problemCopy = `Main Problem: ${analysis.problemAnalysis.mainProblem}\nWhy Problem Exists: ${analysis.problemAnalysis.whyProblemExists}\nExisting Challenges:\n${analysis.problemAnalysis.existingChallenges.join('\n')}\nWhy Research Is Necessary: ${analysis.problemAnalysis.whyResearchNecessary}`;

  return (
    <div className="space-y-6">
      {/* A. Research Paper Summary */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h2 className="font-display text-xl font-bold text-[#13112C]">
            Research Paper Summary
          </h2>
          <CopyButton text={summaryCopy} />
        </div>
        <div className="space-y-4">
          <div>
            <p className="text-xs font-semibold text-violet-700 mb-1">
              Short Summary
            </p>
            <p className="text-sm sm:text-base text-slate-800 leading-relaxed">
              {analysis.summary.shortSummary}
            </p>
          </div>
          <div className="pt-3 border-t border-purple-100">
            <p className="text-xs font-semibold text-violet-700 mb-1">
              Detailed Summary (Plain English)
            </p>
            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
              {analysis.summary.detailedSummary}
            </p>
          </div>
          <div className="pt-3 border-t border-purple-100">
            <p className="text-xs font-semibold text-violet-700 mb-1">
              Main Purpose of the Paper
            </p>
            <p className="text-sm text-slate-700 leading-relaxed">
              {analysis.summary.mainPurpose}
            </p>
          </div>
          <div className="pt-3 border-t border-purple-100">
            <p className="text-xs font-semibold text-violet-700 mb-2">
              Important Contributions
            </p>
            <BulletList items={analysis.summary.importantContributions} />
          </div>
        </div>
      </section>

      {/* B. Research Problem Analysis */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            Research Problem Analysis
          </h3>
          <CopyButton text={problemCopy} />
        </div>
        <div className="space-y-4">
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">
              Main Problem
            </p>
            <p className="text-sm text-slate-800 leading-relaxed">
              {analysis.problemAnalysis.mainProblem}
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 border-t border-purple-100">
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1">
                Why the Problem Exists
              </p>
              <p className="text-sm text-slate-700 leading-relaxed">
                {analysis.problemAnalysis.whyProblemExists}
              </p>
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-1">
                Why This Research Is Necessary
              </p>
              <p className="text-sm text-slate-700 leading-relaxed">
                {analysis.problemAnalysis.whyResearchNecessary}
              </p>
            </div>
          </div>
          <div className="pt-2 border-t border-purple-100">
            <p className="text-xs font-semibold text-slate-500 mb-2">
              Existing Challenges
            </p>
            <BulletList items={analysis.problemAnalysis.existingChallenges} />
          </div>
        </div>
      </section>

      {/* C. Research Objectives */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            Research Objectives Explained
          </h3>
          <CopyButton
            text={analysis.objectivesExplained
              .map((o, i) => `${i + 1}. ${o.objective}: ${o.simpleExplanation}`)
              .join('\n')}
          />
        </div>
        {analysis.objectivesExplained.length === 0 ? (
          <p className="text-sm text-slate-500 italic">
            Not specified in the document
          </p>
        ) : (
          <div className="divide-y divide-purple-100">
            {analysis.objectivesExplained.map((obj, idx) => (
              <div key={idx} className="py-3.5 first:pt-0 last:pb-0">
                <p className="text-sm font-bold text-[#13112C]">
                  {idx + 1}. {obj.objective}
                </p>
                <p className="text-sm text-slate-600 mt-1 leading-relaxed">
                  {obj.simpleExplanation}
                </p>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* G. Strengths & Weaknesses */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            Strengths &amp; Weaknesses
          </h3>
          <CopyButton
            text={`Strengths:\n${analysis.strengthsAndWeaknesses.majorStrengths.join('\n')}\n\nLimitations:\n${analysis.strengthsAndWeaknesses.methodologicalLimitations.join('\n')}`}
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <p className="text-xs font-semibold text-emerald-700 mb-2">
                Major Strengths
              </p>
              <BulletList items={analysis.strengthsAndWeaknesses.majorStrengths} />
            </div>
            <div>
              <p className="text-xs font-semibold text-emerald-700 mb-2">
                Technical Advantages
              </p>
              <BulletList
                items={analysis.strengthsAndWeaknesses.technicalAdvantages}
              />
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <p className="text-xs font-semibold text-amber-700 mb-2">
                Methodological Limitations
              </p>
              <BulletList
                items={analysis.strengthsAndWeaknesses.methodologicalLimitations}
              />
            </div>
            <div>
              <p className="text-xs font-semibold text-amber-700 mb-2">
                Performance Limitations
              </p>
              <BulletList
                items={analysis.strengthsAndWeaknesses.performanceLimitations}
              />
            </div>
            <div>
              <p className="text-xs font-semibold text-amber-700 mb-2">
                Practical Challenges
              </p>
              <BulletList
                items={analysis.strengthsAndWeaknesses.practicalChallenges}
              />
            </div>
          </div>
        </div>
      </section>

      {/* J. Final Conclusion */}
      <section className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-3">
          <h3 className="font-display text-lg font-bold text-[#13112C]">
            Final Conclusion
          </h3>
          <CopyButton text={analysis.finalConclusion} />
        </div>
        <p className="text-sm sm:text-base text-slate-700 leading-relaxed whitespace-pre-line">
          {analysis.finalConclusion}
        </p>
      </section>
    </div>
  );
}

export function MethodologyView({ analysis }: { analysis: AIAnalysisData }) {
  const m = analysis.methodologyAnalysis;
  const copyText = `Research Approach: ${m.researchApproach}\nProposed Methodology: ${m.proposedMethodology}\nAlgorithms: ${m.algorithmsUsed.join(', ')}\nModels: ${m.modelsUsed.join(', ')}\nSteps:\n${m.workflowSteps.map((s) => `${s.stepNumber}. ${s.title}: ${s.description}`).join('\n')}\nImplementation: ${m.implementationDetails}`;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="font-display text-xl font-bold text-[#13112C]">
              Methodology Analysis
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Step-by-step breakdown of the proposed research architecture and workflow.
            </p>
          </div>
          <CopyButton text={copyText} />
        </div>

        <div className="space-y-4">
          <div>
            <p className="text-xs font-semibold text-violet-700 mb-1">
              Research Approach
            </p>
            <p className="text-sm text-slate-800 leading-relaxed">
              {m.researchApproach}
            </p>
          </div>
          <div className="pt-3 border-t border-purple-100">
            <p className="text-xs font-semibold text-violet-700 mb-1">
              Proposed Methodology
            </p>
            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
              {m.proposedMethodology}
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3 border-t border-purple-100">
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2">
                Algorithms Used
              </p>
              <BulletList items={m.algorithmsUsed} />
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2">
                Models Used
              </p>
              <BulletList items={m.modelsUsed} />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <h3 className="font-display text-lg font-bold text-[#13112C] mb-4">
          Step-by-Step Workflow &amp; Implementation
        </h3>
        {m.workflowSteps.length === 0 ? (
          <p className="text-sm text-slate-500 italic">
            Workflow steps not explicitly itemized in the document.
          </p>
        ) : (
          <div className="space-y-3 mb-5">
            {m.workflowSteps.map((step) => (
              <div
                key={step.stepNumber}
                className="flex items-start gap-4 p-4 rounded-xl bg-purple-50/40 border border-purple-100"
              >
                <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 text-white font-mono tabular-nums text-xs font-bold flex items-center justify-center shrink-0">
                  {step.stepNumber}
                </span>
                <div>
                  <p className="text-sm font-bold text-[#13112C]">
                    {step.title}
                  </p>
                  <p className="text-sm text-slate-700 mt-1 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="pt-3 border-t border-purple-100">
          <p className="text-xs font-semibold text-slate-500 mb-1">
            Important Implementation Steps
          </p>
          <p className="text-sm text-slate-700 leading-relaxed">
            {m.implementationDetails}
          </p>
        </div>
      </div>
    </div>
  );
}

export function DatasetAnalysisView({ analysis }: { analysis: AIAnalysisData }) {
  const datasets = analysis.datasetAnalysis;
  const copyText = datasets
    .map(
      (d) =>
        `Dataset: ${d.datasetName}\nSource: ${d.datasetSource}\nRecords: ${d.numberOfRecords}\nCharacteristics: ${d.characteristics}\nPreprocessing: ${d.preprocessingMethods.join(', ')}\nTrain/Test: ${d.trainTestSplitDetails}`,
    )
    .join('\n\n');

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-5">
          <div>
            <h2 className="font-display text-xl font-bold text-[#13112C]">
              Dataset Analysis
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Verified dataset specifications reported in the research paper (missing details are never guessed).
            </p>
          </div>
          {datasets.length > 0 && <CopyButton text={copyText} />}
        </div>

        {datasets.length === 0 ? (
          <p className="text-sm text-slate-500 italic">
            No named datasets were specified in the uploaded document.
          </p>
        ) : (
          <div className="space-y-5">
            {datasets.map((ds, idx) => (
              <div
                key={idx}
                className="rounded-xl border border-purple-200/70 bg-purple-50/30 p-5"
              >
                <h3 className="font-display text-base font-bold text-[#13112C] mb-3">
                  {ds.datasetName}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                  <div>
                    <p className="text-xs font-semibold text-slate-500">Source</p>
                    <p className="text-sm text-slate-800 mt-0.5">
                      {ds.datasetSource}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-slate-500">
                      Number of Records
                    </p>
                    <p className="text-sm font-mono tabular-nums text-slate-800 mt-0.5">
                      {ds.numberOfRecords}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-slate-500">
                      Train / Test Split
                    </p>
                    <p className="text-sm text-slate-800 mt-0.5">
                      {ds.trainTestSplitDetails}
                    </p>
                  </div>
                </div>
                <div className="space-y-3 pt-3 border-t border-purple-100">
                  <div>
                    <p className="text-xs font-semibold text-slate-500 mb-1">
                      Dataset Characteristics
                    </p>
                    <p className="text-sm text-slate-700 leading-relaxed">
                      {ds.characteristics}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-slate-500 mb-1.5">
                      Data Preprocessing Methods
                    </p>
                    <BulletList items={ds.preprocessingMethods} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function ResearchGapsView({ analysis }: { analysis: AIAnalysisData }) {
  const { authorIdentifiedGaps, aiSuggestedOpportunities } = analysis.researchGaps;
  const copyText = `1. Explicitly Discussed by Authors:\n${authorIdentifiedGaps.join('\n') || 'None specified'}\n\n2. AI-Suggested Research Opportunities (Gemini):\n${aiSuggestedOpportunities.join('\n') || 'None'}`;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-2">
          <h2 className="font-display text-xl font-bold text-[#13112C]">
            Research Gap Identification
          </h2>
          <CopyButton text={copyText} />
        </div>
        <p className="text-sm text-slate-500 mb-6">
          Explicitly separates limitations stated by the paper&apos;s authors from
          additional research opportunities synthesized by Gemini.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-5">
            <div className="flex items-center gap-2 mb-3">
              <BookCheck className="w-5 h-5 text-slate-700" />
              <h3 className="font-display text-base font-bold text-[#13112C]">
                1. Explicitly Discussed by Authors
              </h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Unaddressed problems and limitations directly acknowledged in the
              uploaded paper.
            </p>
            <BulletList
              items={authorIdentifiedGaps}
              emptyText="The authors did not explicitly state research gaps in the text."
            />
          </div>

          <div className="rounded-2xl border border-violet-200 bg-violet-50/50 p-5">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-violet-600" />
              <h3 className="font-display text-base font-bold text-[#13112C]">
                2. AI-Generated Research Opportunities (Gemini)
              </h3>
            </div>
            <p className="text-xs text-violet-700 mb-4">
              AI-generated suggestions based on methodological and experimental
              analysis.
            </p>
            <BulletList items={aiSuggestedOpportunities} />
          </div>
        </div>
      </div>
    </div>
  );
}

export function FutureScopeView({ analysis }: { analysis: AIAnalysisData }) {
  const f = analysis.futureScope;
  const copyText = `${f.aiGeneratedDisclaimer}\n\nPossible Improvements:\n${f.possibleImprovements.join('\n')}\n\nAlternative Approaches:\n${f.alternativeApproaches.join('\n')}\n\nNew Algorithms:\n${f.newAlgorithmsToInvestigate.join('\n')}\n\nApplications:\n${f.possibleApplications.join('\n')}\n\nFuture Directions:\n${f.futureResearchDirections.join('\n')}`;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h2 className="font-display text-xl font-bold text-[#13112C]">
            Future Scope &amp; Extensions
          </h2>
          <CopyButton text={copyText} />
        </div>

        <div className="rounded-xl border border-violet-200 bg-violet-50/60 p-3.5 text-xs text-violet-900 flex items-start gap-2.5 mb-6">
          <AlertCircle className="w-4 h-4 text-violet-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold">AI-Generated Suggestions: </span>
            <span>{f.aiGeneratedDisclaimer}</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-bold text-[#13112C] mb-2">
              Possible Improvements
            </h3>
            <BulletList items={f.possibleImprovements} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#13112C] mb-2">
              Alternative Approaches
            </h3>
            <BulletList items={f.alternativeApproaches} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#13112C] mb-2">
              New Algorithms to Investigate
            </h3>
            <BulletList items={f.newAlgorithmsToInvestigate} />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#13112C] mb-2">
              Possible Applications
            </h3>
            <BulletList items={f.possibleApplications} />
          </div>
          <div className="md:col-span-2 pt-4 border-t border-purple-100">
            <h3 className="text-sm font-bold text-[#13112C] mb-2">
              Future Research Directions
            </h3>
            <BulletList items={f.futureResearchDirections} />
          </div>
        </div>
      </div>
    </div>
  );
}
