import { useMemo, useState } from 'react';
import type { AIAnalysisData, PerformanceMetricRow } from '../types/papermind';
import { CopyButton } from './CopyButton';

type MetricKey = 'accuracy' | 'precision' | 'recall' | 'f1Score' | 'mae' | 'rmse';

const METRIC_OPTIONS: Array<{ key: MetricKey; label: string; color: string }> = [
  { key: 'accuracy', label: 'Accuracy', color: '#7C3AED' },
  { key: 'precision', label: 'Precision', color: '#2563EB' },
  { key: 'recall', label: 'Recall', color: '#059669' },
  { key: 'f1Score', label: 'F1-Score', color: '#9333EA' },
  { key: 'mae', label: 'MAE', color: '#D97706' },
  { key: 'rmse', label: 'RMSE', color: '#DC2626' },
];

function fmt(val: number | null): string {
  if (val === null || val === undefined || Number.isNaN(val)) return '—';
  return Number.isInteger(val) ? String(val) : val.toFixed(4).replace(/\.?0+$/, '');
}

export function ResultsPanel({ analysis }: { analysis: AIAnalysisData }) {
  const { metricsTable, hasSufficientNumericalDataForChart, chartMetricUnit, explanation } =
    analysis.resultsAnalysis;

  const availableMetrics = useMemo(() => {
    return METRIC_OPTIONS.filter((opt) =>
      metricsTable.some((row) => row[opt.key] !== null),
    );
  }, [metricsTable]);

  const [selectedMetric, setSelectedMetric] = useState<MetricKey>(
    availableMetrics[0]?.key || 'accuracy',
  );

  const activeMetric =
    availableMetrics.find((m) => m.key === selectedMetric) ??
    availableMetrics[0];

  const chartRows = useMemo(() => {
    if (!activeMetric) return [];
    return metricsTable
      .filter((r) => r[activeMetric.key] !== null)
      .slice(0, 10)
      .map((r) => ({
        label: r.modelOrAlgorithm,
        dataset: r.dataset,
        value: r[activeMetric.key] as number,
      }));
  }, [metricsTable, activeMetric]);

  const maxVal = useMemo(() => {
    if (chartRows.length === 0) return 100;
    const rawMax = Math.max(...chartRows.map((r) => r.value));
    if (rawMax <= 1) return 1;
    if (rawMax <= 100) return 100;
    return Math.ceil(rawMax * 1.15);
  }, [chartRows]);

  const copyText = [
    'Results & Performance Analysis',
    explanation,
    '',
    ...metricsTable.map(
      (r: PerformanceMetricRow) =>
        `${r.modelOrAlgorithm} (${r.dataset}): Acc=${fmt(r.accuracy)}, Prec=${fmt(r.precision)}, Rec=${fmt(r.recall)}, F1=${fmt(r.f1Score)}, MAE=${fmt(r.mae)}, RMSE=${fmt(r.rmse)} | ${r.rawReportedValues}`,
    ),
  ].join('\n');

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="font-display text-xl font-bold text-[#13112C]">
              Results &amp; Performance Analysis
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Actual reported experimental metrics extracted from the paper (no fabricated values).
            </p>
          </div>
          <CopyButton text={copyText} />
        </div>

        <p className="text-sm text-slate-700 leading-relaxed mb-6">
          {explanation}
        </p>

        {metricsTable.length === 0 ? (
          <div className="rounded-xl border border-purple-100 bg-purple-50/40 p-6 text-center text-sm text-slate-600">
            No tabular performance metrics were numerically reported in this paper.
          </div>
        ) : (
          <div className="overflow-x-auto border border-purple-100 rounded-xl">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-purple-50/80 border-b border-purple-100 text-xs font-bold text-[#13112C]">
                  <th className="py-3 px-4">Model / Algorithm</th>
                  <th className="py-3 px-4">Dataset</th>
                  <th className="py-3 px-3 text-right">Accuracy</th>
                  <th className="py-3 px-3 text-right">Precision</th>
                  <th className="py-3 px-3 text-right">Recall</th>
                  <th className="py-3 px-3 text-right">F1-Score</th>
                  <th className="py-3 px-3 text-right">MAE</th>
                  <th className="py-3 px-3 text-right">RMSE</th>
                  <th className="py-3 px-4">Other / Raw</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-purple-100/70">
                {metricsTable.map((row, idx) => (
                  <tr
                    key={idx}
                    className="hover:bg-purple-50/30 transition-colors"
                  >
                    <td className="py-3 px-4 font-semibold text-[#13112C]">
                      {row.modelOrAlgorithm}
                    </td>
                    <td className="py-3 px-4 text-slate-600">{row.dataset}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {fmt(row.accuracy)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {fmt(row.precision)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {fmt(row.recall)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {fmt(row.f1Score)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {fmt(row.mae)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-800">
                      {fmt(row.rmse)}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-600 max-w-[220px]">
                      {row.otherMetrics && row.otherMetrics !== 'None reported'
                        ? row.otherMetrics
                        : row.rawReportedValues}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {hasSufficientNumericalDataForChart &&
        availableMetrics.length > 0 &&
        chartRows.length > 0 && (
          <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              <div>
                <h3 className="font-display text-lg font-bold text-[#13112C]">
                  Reported Metrics Visualization
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Scale: {chartMetricUnit} · Showing reported{' '}
                  {activeMetric?.label}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-1 p-1 bg-purple-50 rounded-xl border border-purple-100">
                {availableMetrics.map((m) => (
                  <button
                    key={m.key}
                    type="button"
                    onClick={() => setSelectedMetric(m.key)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                      activeMetric?.key === m.key
                        ? 'bg-white text-violet-700 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              {chartRows.map((item, idx) => {
                const pct = Math.min(
                  100,
                  Math.max(2, (item.value / maxVal) * 100),
                );
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between gap-3 text-xs sm:text-sm">
                      <span className="font-medium text-slate-800 truncate">
                        {item.label}
                        {item.dataset &&
                        item.dataset !== 'Not specified in the document'
                          ? ` (${item.dataset})`
                          : ''}
                      </span>
                      <span className="font-mono tabular-nums font-bold text-[#13112C] shrink-0">
                        {fmt(item.value)}
                      </span>
                    </div>
                    <div className="w-full h-3 rounded-full bg-purple-100/70 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${pct}%`,
                          backgroundColor: activeMetric?.color || '#7C3AED',
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
    </div>
  );
}
