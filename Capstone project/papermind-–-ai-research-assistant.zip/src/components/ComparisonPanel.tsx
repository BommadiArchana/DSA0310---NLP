import { useEffect, useRef, useState, type ChangeEvent } from 'react';
import {
  AlertTriangle,
  Download,
  FileUp,
  GitCompare,
  Loader2,
} from 'lucide-react';
import type {
  DocumentSummaryItem,
  FullDocumentData,
  PaperComparisonResult,
} from '../types/papermind';
import {
  comparePapers,
  listSessionDocuments,
  uploadPdfDocument,
} from '../services/api';
import { CopyButton } from './CopyButton';
import { ErrorMessage } from './ErrorMessage';

interface ComparisonPanelProps {
  primaryDoc: FullDocumentData;
  onComparisonSaved: (result: PaperComparisonResult) => void;
}

export function ComparisonPanel({
  primaryDoc,
  onComparisonSaved,
}: ComparisonPanelProps) {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [sessionDocs, setSessionDocs] = useState<DocumentSummaryItem[]>([]);
  const [selectedOtherId, setSelectedOtherId] = useState<string>('');
  const [isUploadingSecond, setIsUploadingSecond] = useState(false);
  const [isComparing, setIsComparing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<PaperComparisonResult | null>(
    primaryDoc.lastComparison ?? null,
  );

  const refreshDocs = async () => {
    try {
      const list = await listSessionDocuments();
      const others = list.filter((d) => d.documentId !== primaryDoc.documentId);
      setSessionDocs(others);
      if (!selectedOtherId && others.length > 0) {
        setSelectedOtherId(others[0].documentId);
      }
    } catch {
      // Ignore silent list error
    }
  };

  useEffect(() => {
    setResult(primaryDoc.lastComparison ?? null);
    void refreshDocs();
  }, [primaryDoc.documentId]);

  const handleUploadSecondPaper = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setError(null);
    setIsUploadingSecond(true);
    try {
      const uploaded = await uploadPdfDocument(file);
      await refreshDocs();
      setSelectedOtherId(uploaded.documentId);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Failed to upload second PDF.',
      );
    } finally {
      setIsUploadingSecond(false);
    }
  };

  const handleRunComparison = async () => {
    if (!selectedOtherId) {
      setError('Please upload or select a second research paper to compare.');
      return;
    }
    setError(null);
    setIsComparing(true);
    try {
      const comparison = await comparePapers(
        primaryDoc.documentId,
        selectedOtherId,
      );
      setResult(comparison);
      onComparisonSaved(comparison);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Comparison failed.');
    } finally {
      setIsComparing(false);
    }
  };

  const formatComparisonText = (res: PaperComparisonResult): string => {
    const lines = [
      'PAPERMIND – RESEARCH PAPER COMPARISON REPORT',
      `Paper A: ${res.paperATitle}`,
      `Paper B: ${res.paperBTitle}`,
      '',
      `Metric Comparability Notice: ${res.metricComparabilityWarning}`,
      '',
      'Overall Summary:',
      res.overallSummary,
      '',
      'Similarities:',
      ...res.similarities.map((s) => `- ${s}`),
      '',
      'Differences:',
      ...res.differences.map((d) => `- ${d}`),
      '',
      'Structured Dimension Comparison:',
      ...res.comparisonTable.map(
        (row) =>
          `\n[${row.dimension}]\nPaper A: ${row.paperA}\nPaper B: ${row.paperB}\nNotes: ${row.notes}`,
      ),
    ];
    return lines.join('\n');
  };

  const handleDownloadComparison = () => {
    if (!result) return;
    const blob = new Blob([formatComparisonText(result)], {
      type: 'text/plain;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PaperMind_Comparison_${primaryDoc.documentId}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <h2 className="font-display text-xl font-bold text-[#13112C]">
          Compare Research Papers
        </h2>
        <p className="text-sm text-slate-500 mt-1 mb-6">
          Compare your current paper against a second research paper across 12
          objectives, methodology, dataset, and performance dimensions.
        </p>

        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,application/pdf"
          onChange={handleUploadSecondPaper}
          className="hidden"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
          <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/40">
            <p className="text-xs font-semibold text-violet-700 mb-1">
              Paper A (Current Paper)
            </p>
            <p className="text-sm font-bold text-[#13112C] line-clamp-2">
              {primaryDoc.extraction?.generalInfo.title ||
                primaryDoc.originalFilename}
            </p>
            <p className="text-xs text-slate-500 mt-1 font-mono tabular-nums">
              {primaryDoc.pageCount} pages
            </p>
          </div>

          <div className="p-4 rounded-xl border border-purple-200 bg-white">
            <p className="text-xs font-semibold text-blue-700 mb-2">
              Paper B (Select or Upload Second PDF)
            </p>
            <div className="flex flex-col sm:flex-row gap-2">
              <select
                value={selectedOtherId}
                onChange={(e) => setSelectedOtherId(e.target.value)}
                disabled={isUploadingSecond || isComparing}
                aria-label="Select second paper for comparison"
                className="flex-1 px-3 py-2 text-sm rounded-lg border border-purple-200 bg-purple-50/30 text-[#13112C] focus:outline-none focus:ring-2 focus:ring-violet-500"
              >
                {sessionDocs.length === 0 ? (
                  <option value="">No second paper uploaded yet</option>
                ) : (
                  sessionDocs.map((d) => (
                    <option key={d.documentId} value={d.documentId}>
                      {d.title} ({d.pageCount}p)
                    </option>
                  ))
                )}
              </select>

              <button
                type="button"
                disabled={isUploadingSecond || isComparing}
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg border border-purple-200 bg-purple-50 text-violet-700 hover:bg-violet-100 transition-colors whitespace-nowrap shrink-0"
              >
                {isUploadingSecond ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <FileUp className="w-3.5 h-3.5" />
                )}
                <span>Upload 2nd PDF</span>
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-5">
            <ErrorMessage
              title="Comparison Issue"
              message={error}
              onDismiss={() => setError(null)}
            />
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={!selectedOtherId || isComparing || isUploadingSecond}
            onClick={handleRunComparison}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm transition-all"
          >
            {isComparing ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <GitCompare className="w-4 h-4" />
            )}
            <span>
              {isComparing ? 'Analyzing & Comparing Papers...' : 'Compare Papers'}
            </span>
          </button>

          {result && (
            <>
              <button
                type="button"
                onClick={handleDownloadComparison}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold border border-purple-200 bg-white text-slate-700 hover:text-violet-700 hover:border-violet-300 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Comparison Report</span>
              </button>
              <CopyButton text={formatComparisonText(result)} label="Copy All" />
            </>
          )}
        </div>
      </div>

      {result && (
        <>
          <div className="rounded-2xl border border-amber-200 bg-amber-50/90 p-4 flex items-start gap-3 text-sm text-amber-950">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-xs uppercase tracking-wide text-amber-800">
                Metric Comparability Safeguard
              </p>
              <p className="text-sm mt-0.5">{result.metricComparabilityWarning}</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs space-y-5">
            <div>
              <h3 className="font-display text-lg font-bold text-[#13112C] mb-2">
                Similarities &amp; Differences Summary
              </h3>
              <p className="text-sm text-slate-700 leading-relaxed">
                {result.overallSummary}
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-4 border-t border-purple-100">
              <div>
                <p className="text-xs font-bold text-emerald-700 mb-2">
                  Key Similarities
                </p>
                <ul className="space-y-1.5 text-sm text-slate-700">
                  {result.similarities.map((s, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="mt-2 w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
                      <span>{s}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="text-xs font-bold text-blue-700 mb-2">
                  Key Differences
                </p>
                <ul className="space-y-1.5 text-sm text-slate-700">
                  {result.differences.map((d, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span className="mt-2 w-1.5 h-1.5 rounded-full bg-blue-500 shrink-0" />
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
            <h3 className="font-display text-lg font-bold text-[#13112C] mb-4">
              Structured Comparison Table
            </h3>
            <div className="overflow-x-auto border border-purple-100 rounded-xl">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-purple-50/80 border-b border-purple-100 text-xs font-bold text-[#13112C]">
                    <th className="py-3 px-4 w-44">Dimension</th>
                    <th className="py-3 px-4">{result.paperATitle}</th>
                    <th className="py-3 px-4">{result.paperBTitle}</th>
                    <th className="py-3 px-4">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-purple-100/70 align-top">
                  {result.comparisonTable.map((row, i) => (
                    <tr key={i} className="hover:bg-purple-50/20">
                      <td className="py-3.5 px-4 font-bold text-[#13112C]">
                        {row.dimension}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 leading-relaxed">
                        {row.paperA}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 leading-relaxed">
                        {row.paperB}
                      </td>
                      <td className="py-3.5 px-4 text-xs text-slate-600 leading-relaxed">
                        {row.notes}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
