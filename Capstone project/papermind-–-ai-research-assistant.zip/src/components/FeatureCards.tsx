import { BrainCircuit, FileSearch, MessageSquareText } from 'lucide-react';

export function FeatureCards() {
  const cards = [
    {
      title: 'Smart Extraction',
      description: 'Key information from your paper.',
      icon: FileSearch,
      iconBg: 'bg-violet-100 text-violet-600 border-violet-200/70',
    },
    {
      title: 'AI-Powered Analysis',
      description: 'Clear and meaningful insights.',
      icon: BrainCircuit,
      iconBg: 'bg-blue-100 text-blue-600 border-blue-200/70',
    },
    {
      title: 'Interactive Assistant',
      description: 'Ask questions about your paper.',
      icon: MessageSquareText,
      iconBg: 'bg-emerald-100 text-emerald-600 border-emerald-200/70',
    },
  ];

  return (
    <section className="max-w-4xl mx-auto px-4 mt-10 sm:mt-12 pb-12">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <div
              key={card.title}
              className="bg-white/95 rounded-2xl border border-purple-200/70 p-6 shadow-xs hover:shadow-md hover:border-violet-300 transition-all"
            >
              <div
                className={`w-11 h-11 rounded-xl border flex items-center justify-center mb-4 ${card.iconBg}`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="font-display text-base font-bold text-[#13112C]">
                {card.title}
              </h3>
              <p className="text-sm text-slate-600 mt-1">{card.description}</p>
            </div>
          );
        })}
      </div>

      <footer className="text-center mt-10 text-xs sm:text-sm text-slate-500">
        Intelligent Research Paper Analyzer • NLP + Large Language Models
      </footer>
    </section>
  );
}
