import { useEffect, useState } from 'react';
import { BookOpen, Download, Loader2, Sparkles } from 'lucide-react';
import type {
  DocumentSummaryItem,
  FullDocumentData,
  LiteratureReviewResult,
} from '../types/papermind';
import {
  generateLiteratureReviewApi,
  listSessionDocuments,
} from '../services/api';
import { CopyButton } from './CopyButton';
import { ErrorMessage } from './ErrorMessage';

interface LiteratureReviewProps {
  primaryDoc: FullDocumentData;
  onLiteratureReviewSaved: (res: LiteratureReviewResult) => void;
}

export function LiteratureReview({
  primaryDoc,
  onLiteratureReviewSaved,
}: LiteratureReviewProps) {
  const [sessionDocs, setSessionDocs] = useState<DocumentSummaryItem[]>([]);
  const [selectedIds, setSelectedIds] = useState<string[]>([
    primaryDoc.documentId,
  ]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [review, setReview] = useState<LiteratureReviewResult | null>(
    primaryDoc.lastLiteratureReview ?? null,
  );

  useEffect(() => {
    setReview(primaryDoc.lastLiteratureReview ?? null);
    setSelectedIds([primaryDoc.documentId]);
    listSessionDocuments()
      .then((docs) => setSessionDocs(docs))
      .catch(() => {});
  }, [primaryDoc.documentId]);

  const toggleDocSelection = (docId: string) => {
    setSelectedIds((prev) => {
      if (prev.includes(docId)) {
        if (prev.length === 1) return prev; // Keep at least 1 paper selected
        return prev.filter((id) => id !== docId);
      }
      return [...prev, docId];
    });
  };

  const handleGenerate = async () => {
    setError(null);
    setIsGenerating(true);
    try {
      const res = await generateLiteratureReviewApi(
        primaryDoc.documentId,
        selectedIds,
      );
      setReview(res);
      onLiteratureReviewSaved(res);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'Failed to generate literature review.',
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const formatReviewAsText = (rev: LiteratureReviewResult): string => {
    return [
      rev.title,
      `[${rev.aiSynthesisNotice}]`,
      '',
      'Papers Included:',
      ...rev.papersIncluded.map(
        (p, i) => `  ${i + 1}. ${p.title} — ${p.authors} (${p.year})`,
      ),
      '',
      '1. Introduction',
      rev.introduction,
      '',
      '2. Research Background',
      rev.researchBackground,
      '',
      '3. Previous Research Approaches',
      rev.previousApproaches,
      '',
      '4. Methods Used in Selected Paper(s)',
      ...rev.methodsUsed.map((m) => `\n${m.paperTitle}:\n${m.summary}`),
      '',
      '5. Comparison of Research Findings',
      rev.comparisonOfFindings,
      '',
      '6. Existing Limitations',
      ...rev.existingLimitations.map((l) => `- ${l}`),
      '',
      '7. Identified Research Gaps',
      ...rev.identifiedResearchGaps.map((g) => `- ${g}`),
      '',
      '8. Overall Literature Review Conclusion',
      rev.overallConclusion,
      '',
      'Verified Citations (from extracted paper references):',
      ...rev.verifiedCitations.map(
        (c, i) => `[${i + 1}] ${c.authors} (${c.year}). ${c.title}. ${c.doiOrUrl}`,
      ),
    ].join('\n');
  };

  const handleDownload = () => {
    if (!review) return;
    const blob = new Blob([formatReviewAsText(review)], {
      type: 'text/plain;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `PaperMind_Literature_Review_${primaryDoc.documentId}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl border border-purple-200/80 p-6 shadow-xs">
        <h2 className="font-display text-xl font-bold text-[#13112C]">
          Literature Review Generator
        </h2>
        <p className="text-sm text-slate-500 mt-1 mb-5">
          Synthesize a structured academic literature review from the current
          paper or multiple uploaded papers, strictly anchored to verified
          extracted references.
        </p>

        {sessionDocs.length > 1 && (
          <div className="mb-5">
            <p className="text-xs font-semibold text-slate-600 mb-2">
              Select Papers to Include ({selectedIds.length} selected)
            </p>
            <div className="space-y-2">
              {sessionDocs.map((d) => {
                const checked = selectedIds.includes(d.documentId);
                return (
                  <label
                    key={d.documentId}
                    className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-colors ${
                      checked
                        ? 'border-violet-300 bg-violet-50/60'
                        : 'border-purple-100 bg-white hover:bg-purple-50/30'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleDocSelection(d.documentId)}
                      className="rounded border-purple-300 text-violet-600 focus:ring-violet-500"
                    />
                    <span className="text-sm font-medium text-[#13112C] flex-1 truncate">
                      {d.title}
                    </span>
                    <span className="text-xs font-mono tabular-nums text-slate-500">
                      {d.pageCount} pages
                    </span>
                  </label>
                );
              })}
            </div>
          </div>
        )}

        {error && (
          <div className="mb-5">
            <ErrorMessage
              title="Literature Review Error"
              message={error}
              onDismiss={() => setError(null)}
            />
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={isGenerating}
            onClick={handleGenerate}
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 disabled:opacity-50 shadow-sm transition-all"
          >
            {isGenerating ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <BookOpen className="w-4 h-4" />
            )}
            <span>
              {isGenerating
                ? 'Synthesizing Literature Review...'
                : review
                  ? 'Regenerate Literature Review'
                  : 'Generate Literature Review'}
            </span>
          </button>

          {review && (
            <>
              <button
                type="button"
                onClick={handleDownload}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold border border-purple-200 bg-white text-slate-700 hover:text-violet-700 hover:border-violet-300 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Literature Review</span>
              </button>
              <CopyButton text={formatReviewAsText(review)} label="Copy Review" />
            </>
          )}
        </div>
      </div>

      {review && (
        <article className="bg-white rounded-2xl border border-purple-200/80 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="rounded-xl border border-violet-200 bg-violet-50/70 p-3.5 flex items-start gap-2.5 text-xs text-violet-900">
            <Sparkles className="w-4 h-4 text-violet-600 shrink-0 mt-0.5" />
            <span>{review.aiSynthesisNotice}</span>
          </div>

          <h3 className="font-display text-2xl font-bold text-[#13112C]">
            {review.title}
          </h3>

          {[
            { heading: '1. Introduction', text: review.introduction },
            { heading: '2. Research Background', text: review.researchBackground },
            {
              heading: '3. Previous Research Approaches',
              text: review.previousApproaches,
            },
          ].map((sec) => (
            <section key={sec.heading}>
              <h4 className="font-display text-base font-bold text-violet-800 mb-2">
                {sec.heading}
              </h4>
              <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                {sec.text}
              </p>
            </section>
          ))}

          <section>
            <h4 className="font-display text-base font-bold text-violet-800 mb-3">
              4. Methods Used in Selected Paper(s)
            </h4>
            <div className="space-y-3">
              {review.methodsUsed.map((m, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-purple-50/40 border border-purple-100"
                >
                  <p className="text-sm font-bold text-[#13112C] mb-1">
                    {m.paperTitle}
                  </p>
                  <p className="text-sm text-slate-700 leading-relaxed">
                    {m.summary}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h4 className="font-display text-base font-bold text-violet-800 mb-2">
              5. Comparison of Research Findings
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
              {review.comparisonOfFindings}
            </p>
          </section>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <section>
              <h4 className="font-display text-base font-bold text-violet-800 mb-2">
                6. Existing Limitations
              </h4>
              <ul className="space-y-1.5 text-sm text-slate-700">
                {review.existingLimitations.map((lim, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="mt-2 w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
                    <span>{lim}</span>
                  </li>
                ))}
              </ul>
            </section>

            <section>
              <h4 className="font-display text-base font-bold text-violet-800 mb-2">
                7. Identified Research Gaps
              </h4>
              <ul className="space-y-1.5 text-sm text-slate-700">
                {review.identifiedResearchGaps.map((gap, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="mt-2 w-1.5 h-1.5 rounded-full bg-violet-500 shrink-0" />
                    <span>{gap}</span>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          <section className="pt-4 border-t border-purple-100">
            <h4 className="font-display text-base font-bold text-violet-800 mb-2">
              8. Overall Literature Review Conclusion
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
              {review.overallConclusion}
            </p>
          </section>

          <section className="pt-4 border-t border-purple-100">
            <h4 className="font-display text-base font-bold text-[#13112C] mb-3">
              Verified Linked References
            </h4>
            {review.verifiedCitations.length === 0 ? (
              <p className="text-sm text-slate-500 italic">
                No extracted references were available in the uploaded paper(s).
              </p>
            ) : (
              <ol className="space-y-2 text-xs sm:text-sm text-slate-700">
                {review.verifiedCitations.map((c, idx) => (
                  <li key={idx}>
                    <span className="font-mono text-violet-600 mr-2">
                      [{idx + 1}]
                    </span>
                    {c.authors} ({c.year}). <span className="font-medium">{c.title}</span>.{' '}
                    {c.doiOrUrl !== 'Not specified in the document'
                      ? c.doiOrUrl
                      : ''}
                  </li>
                ))}
              </ol>
            )}
          </section>
        </article>
      )}
    </div>
  );
}
