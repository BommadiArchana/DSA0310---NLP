import { History, Plus, Sparkles } from 'lucide-react';
import type { HealthStatus } from '../types/papermind';

interface HeaderProps {
  health: HealthStatus;
  showDashboardActions?: boolean;
  savedCount?: number;
  onGoHome: () => void;
  onOpenHistory?: () => void;
}

export function Header({
  health,
  showDashboardActions = false,
  savedCount = 0,
  onGoHome,
  onOpenHistory,
}: HeaderProps) {
  const isOnline = health.status === 'ok';

  return (
    <header className="no-print sticky top-0 z-30 w-full bg-white/80 backdrop-blur-md border-b border-purple-100/90">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        <button
          type="button"
          onClick={onGoHome}
          className="flex items-center gap-3 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded-xl whitespace-nowrap shrink-0"
        >
          <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-600 flex items-center justify-center shadow-sm shadow-violet-500/25 group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 text-white" />
          </span>
          <span className="font-display text-xl font-extrabold tracking-tight text-[#13112C]">
            Paper<span className="text-violet-600">Mind</span>
          </span>
        </button>

        <div className="flex items-center gap-3 sm:gap-5 shrink-0">
          {savedCount > 0 && onOpenHistory && (
            <button
              type="button"
              onClick={onOpenHistory}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-violet-700 bg-purple-50/70 hover:bg-purple-100/80 border border-purple-200/80 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <History className="w-3.5 h-3.5 text-violet-600" />
              <span className="hidden sm:inline">Saved Papers</span>
              <span className="font-mono tabular-nums text-violet-700">
                ({savedCount})
              </span>
            </button>
          )}

          {showDashboardActions && (
            <button
              type="button"
              onClick={onGoHome}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Upload Paper</span>
            </button>
          )}

          <div
            className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-600 whitespace-nowrap shrink-0"
            title={
              isOnline
                ? health.geminiConfigured
                  ? 'Backend API & Gemini AI connected'
                  : 'Backend online (Gemini API key required in Settings)'
                : 'Backend API unreachable'
            }
          >
            <span
              aria-hidden="true"
              className={`w-2.5 h-2.5 rounded-full ${
                isOnline ? 'bg-emerald-500' : 'bg-amber-500'
              }`}
            />
            <span>AI Research Assistant</span>
          </div>
        </div>
      </div>
    </header>
  );
}
