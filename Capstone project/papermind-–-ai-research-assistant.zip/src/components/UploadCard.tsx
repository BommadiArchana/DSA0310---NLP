import { useRef, useState, type DragEvent, type ChangeEvent } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  FileText,
  FolderOpen,
  Loader2,
  RefreshCw,
  ShieldCheck,
  Trash2,
  UploadCloud,
} from 'lucide-react';
import type { UploadedDocumentResponse } from '../types/papermind';
import { ErrorMessage } from './ErrorMessage';

interface UploadCardProps {
  uploadedDoc: UploadedDocumentResponse | null;
  maxUploadMb: number;
  isUploading: boolean;
  uploadError: string | null;
  onFileSelected: (file: File) => void;
  onRemoveDocument: () => void;
  onAnalyzePaper: () => void;
  onClearError: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function UploadCard({
  uploadedDoc,
  maxUploadMb,
  isUploading,
  uploadError,
  onFileSelected,
  onRemoveDocument,
  onAnalyzePaper,
  onClearError,
}: UploadCardProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleBrowseClick = () => {
    inputRef.current?.click();
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelected(file);
    }
    e.target.value = '';
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isUploading) setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (isUploading) return;
    const file = e.dataTransfer.files?.[0];
    if (file) {
      onFileSelected(file);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4">
      <div className="bg-white rounded-3xl border border-purple-200/80 shadow-[0_14px_45px_rgba(109,40,217,0.08)] p-6 sm:p-10">
        <div className="text-center mb-7">
          <h2 className="font-display text-2xl sm:text-[26px] font-bold text-[#13112C]">
            Analyze Your Research Paper
          </h2>
          <p className="text-sm sm:text-base text-slate-500 mt-1.5">
            Upload a PDF to begin your intelligent analysis.
          </p>
        </div>

        <input
          ref={inputRef}
          type="file"
          accept=".pdf,application/pdf"
          onChange={handleFileChange}
          className="sr-only"
          aria-label="Select PDF research paper"
        />

        {uploadError && (
          <div className="mb-6">
            <ErrorMessage
              title="Document Upload Issue"
              message={uploadError}
              onDismiss={onClearError}
            />
          </div>
        )}

        {!uploadedDoc ? (
          <div
            onClick={() => {
              if (!isUploading) handleBrowseClick();
            }}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            role="region"
            aria-label="PDF Upload Dropzone"
            className={`rounded-2xl border-2 border-dashed transition-all p-8 sm:p-12 text-center ${
              isUploading ? 'cursor-wait' : 'cursor-pointer'
            } ${
              isDragging
                ? 'border-violet-500 bg-violet-50/70 scale-[1.01]'
                : 'border-purple-200 bg-purple-50/30 hover:border-violet-400 hover:bg-purple-50/50'
            }`}
          >
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-100 to-indigo-100 border border-purple-200/70 flex items-center justify-center mx-auto mb-5 shadow-xs">
              {isUploading ? (
                <Loader2 className="w-8 h-8 text-violet-600 animate-spin" />
              ) : (
                <UploadCloud className="w-8 h-8 text-violet-600" />
              )}
            </div>

            {isUploading ? (
              <div>
                <p className="font-display text-lg font-bold text-[#13112C]">
                  Validating &amp; Extracting PDF Content...
                </p>
                <p className="text-sm text-slate-500 mt-1.5">
                  Checking document structure, page count, and extracting text
                  (OCR runs automatically if scanned pages are detected).
                </p>
              </div>
            ) : (
              <>
                <p className="font-display text-lg sm:text-xl font-bold text-[#13112C]">
                  Drop your paper here
                </p>
                <p className="text-sm text-slate-500 mt-1 mb-6">
                  Or choose a PDF from your computer
                </p>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleBrowseClick();
                  }}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 shadow-md shadow-violet-500/20 transition-all cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
                >
                  <FolderOpen className="w-4 h-4" />
                  <span>Browse PDF</span>
                </button>

                <div className="mt-6 flex flex-wrap items-center justify-center gap-x-4 gap-y-1 text-xs text-slate-500">
                  <span>PDF files only</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">Max {maxUploadMb} MB</span>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    Secure document processing
                  </span>
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="rounded-2xl border border-purple-200 bg-purple-50/40 p-5 sm:p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-start gap-4 min-w-0">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center shrink-0 shadow-sm">
                  <FileText className="w-6 h-6 text-white" />
                </div>
                <div className="min-w-0">
                  <p className="font-display text-base font-bold text-[#13112C] truncate">
                    {uploadedDoc.originalFilename}
                  </p>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs sm:text-sm text-slate-600 mt-1 tabular-nums">
                    <span>{formatBytes(uploadedDoc.fileSizeBytes)}</span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {uploadedDoc.pageCount}{' '}
                      {uploadedDoc.pageCount === 1 ? 'page' : 'pages'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {uploadedDoc.sectionsCount}{' '}
                      {uploadedDoc.sectionsCount === 1
                        ? 'section'
                        : 'sections'}{' '}
                      detected
                    </span>
                    {uploadedDoc.ocrPagesCount > 0 && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="text-violet-700 font-medium">
                          OCR applied ({uploadedDoc.ocrPagesCount} pages)
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleBrowseClick}
                  disabled={isUploading}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl border border-purple-200 bg-white text-slate-700 hover:text-violet-700 hover:border-violet-300 transition-colors whitespace-nowrap"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Replace</span>
                </button>
                <button
                  type="button"
                  onClick={onRemoveDocument}
                  disabled={isUploading}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl border border-rose-200 bg-white text-rose-600 hover:bg-rose-50 transition-colors whitespace-nowrap"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove</span>
                </button>
              </div>
            </div>

            {uploadedDoc.ocrWarnings.length > 0 && (
              <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold">
                    OCR Notice for Scanned Pages:
                  </p>
                  <ul className="list-disc pl-4 mt-1 space-y-0.5">
                    {uploadedDoc.ocrWarnings.slice(0, 4).map((w, idx) => (
                      <li key={idx}>{w}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="mt-7 flex flex-col items-center gap-3">
          <button
            type="button"
            disabled={!uploadedDoc || isUploading}
            onClick={onAnalyzePaper}
            className={`w-full sm:w-auto min-w-[240px] inline-flex items-center justify-center gap-2.5 px-8 py-3.5 rounded-xl text-base font-semibold transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${
              uploadedDoc && !isUploading
                ? 'bg-gradient-to-r from-violet-600 via-purple-600 to-blue-600 hover:from-violet-700 hover:to-blue-700 text-white shadow-lg shadow-violet-500/25 cursor-pointer'
                : 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
            }`}
          >
            <span>Analyze Paper</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <p className="text-xs text-slate-500 text-center max-w-lg">
            Privacy notice: Uploaded PDFs are stored temporarily on the server
            scoped to your active session, automatically cleaned up upon
            expiration, and never used to train external models.
          </p>
        </div>
      </div>
    </div>
  );
}
