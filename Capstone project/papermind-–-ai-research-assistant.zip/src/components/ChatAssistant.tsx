import { useEffect, useRef, useState, type FormEvent } from 'react';
import {
  Bot,
  ChevronDown,
  ChevronUp,
  Loader2,
  Send,
  Trash2,
  User,
} from 'lucide-react';
import type { ChatMessage } from '../types/papermind';
import { clearChatHistory, streamChatQuestion } from '../services/api';
import { CopyButton } from './CopyButton';
import { ErrorMessage } from './ErrorMessage';

const EXAMPLE_QUESTIONS = [
  'What is the main objective of this research?',
  'Explain the abstract in simple words.',
  'Which algorithms are used?',
  'What dataset is used?',
  'Explain the methodology step by step.',
  'What are the major findings?',
  'What are the limitations?',
  'Identify the research gap.',
  'What are the future improvements?',
  'Explain the results and performance metrics.',
  'Why did the authors select this algorithm?',
  'What is the difference between the existing and proposed systems?',
  'Explain the paper for a beginner.',
  'What are the main contributions?',
  'Suggest possible extensions to this research.',
];

interface ChatAssistantProps {
  documentId: string;
  paperTitle: string;
  initialHistory: ChatMessage[];
  isOfflineSnapshot?: boolean;
  onHistoryUpdated: (messages: ChatMessage[]) => void;
}

export function ChatAssistant({
  documentId,
  paperTitle,
  initialHistory,
  isOfflineSnapshot,
  onHistoryUpdated,
}: ChatAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialHistory);
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const [streamingPages, setStreamingPages] = useState<number[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showAllPrompts, setShowAllPrompts] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const bottomRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    setMessages(initialHistory);
    setError(null);
  }, [documentId, initialHistory]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingText]);

  const sendQuestion = async (questionText: string) => {
    const trimmed = questionText.trim();
    if (!trimmed) {
      setError('Please enter a question before sending.');
      return;
    }
    if (isStreaming || isOfflineSnapshot) return;

    setError(null);
    const optimisticUser: ChatMessage = {
      id: `temp_${Date.now()}`,
      role: 'user',
      content: trimmed,
      timestamp: new Date().toISOString(),
    };

    const nextMessages = [...messages, optimisticUser];
    setMessages(nextMessages);
    setInput('');
    setIsStreaming(true);
    setStreamingText('');
    setStreamingPages([]);

    let accumulated = '';
    await streamChatQuestion(documentId, trimmed, {
      onMeta: (pages) => {
        setStreamingPages(pages);
      },
      onChunk: (piece) => {
        accumulated += piece;
        setStreamingText(accumulated);
      },
      onDone: (finalMsg) => {
        const finalized = [...nextMessages, finalMsg];
        setMessages(finalized);
        onHistoryUpdated(finalized);
        setStreamingText('');
        setStreamingPages([]);
        setIsStreaming(false);
      },
      onError: (errMsg) => {
        setMessages(messages);
        setInput(trimmed);
        setError(errMsg);
        setStreamingText('');
        setIsStreaming(false);
      },
    });
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    void sendQuestion(input);
  };

  const handleClearChat = async () => {
    try {
      await clearChatHistory(documentId);
      setMessages([]);
      onHistoryUpdated([]);
      setConfirmClear(false);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to clear chat.');
    }
  };

  const visiblePrompts = showAllPrompts
    ? EXAMPLE_QUESTIONS
    : EXAMPLE_QUESTIONS.slice(0, 6);

  return (
    <div className="bg-white rounded-2xl border border-purple-200/80 shadow-xs overflow-hidden flex flex-col min-h-[640px] max-h-[820px]">
      <div className="p-5 sm:p-6 border-b border-purple-100 flex flex-wrap items-center justify-between gap-3 bg-purple-50/30">
        <div>
          <h2 className="font-display text-xl font-bold text-[#13112C]">
            Ask Anything About Your Research Paper
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Your personal AI assistant for understanding academic research ·{' '}
            <span className="text-slate-700 font-medium">{paperTitle}</span>
          </p>
        </div>

        {messages.length > 0 && !isOfflineSnapshot && (
          <div className="flex items-center gap-2">
            {confirmClear ? (
              <div className="flex items-center gap-2 bg-rose-50 border border-rose-200 rounded-xl px-3 py-1.5">
                <span className="text-xs font-medium text-rose-800">
                  Clear history?
                </span>
                <button
                  type="button"
                  onClick={handleClearChat}
                  className="text-xs font-bold text-rose-700 hover:underline"
                >
                  Confirm
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmClear(false)}
                  className="text-xs text-slate-600 hover:underline"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmClear(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border border-purple-200 bg-white text-slate-600 hover:text-rose-600 hover:border-rose-200 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear Chat</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* Example Questions */}
      <div className="px-5 py-3.5 border-b border-purple-100 bg-white">
        <div className="flex items-center justify-between mb-2">
          <p className="text-xs font-semibold text-slate-500">
            Suggested Research Questions
          </p>
          <button
            type="button"
            onClick={() => setShowAllPrompts((v) => !v)}
            className="inline-flex items-center gap-1 text-xs font-semibold text-violet-600 hover:text-violet-800"
          >
            <span>
              {showAllPrompts ? 'Show fewer' : 'Show all 15 questions'}
            </span>
            {showAllPrompts ? (
              <ChevronUp className="w-3.5 h-3.5" />
            ) : (
              <ChevronDown className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {visiblePrompts.map((q) => (
            <button
              key={q}
              type="button"
              disabled={isStreaming || isOfflineSnapshot}
              onClick={() => void sendQuestion(q)}
              className="text-left text-xs px-3 py-1.5 rounded-lg border border-purple-200/80 bg-purple-50/50 text-slate-700 hover:bg-violet-50 hover:border-violet-300 hover:text-violet-800 transition-colors disabled:opacity-50"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Area */}
      <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-[#FAF8FF]">
        {isOfflineSnapshot && (
          <div className="rounded-xl border border-amber-200 bg-amber-50 p-3.5 text-xs text-amber-900">
            This is a saved browser snapshot whose server session has expired.
            Re-upload the PDF from the home screen to ask live follow-up
            questions.
          </div>
        )}

        {messages.length === 0 && !isStreaming && (
          <div className="text-center py-12 max-w-md mx-auto">
            <div className="w-12 h-12 rounded-2xl bg-violet-100 text-violet-600 flex items-center justify-center mx-auto mb-3">
              <Bot className="w-6 h-6" />
            </div>
            <p className="font-display text-base font-bold text-[#13112C]">
              Ready to explore your paper
            </p>
            <p className="text-sm text-slate-500 mt-1">
              Click any suggested question above or ask your own question below.
              Answers retrieve relevant sections and cite page numbers directly
              from your PDF.
            </p>
          </div>
        )}

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-3 ${
              msg.role === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.role === 'assistant' && (
              <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-xs ${
                msg.role === 'user'
                  ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white'
                  : 'bg-white border border-purple-200/80 text-slate-800'
              }`}
            >
              <p className="whitespace-pre-wrap break-words">{msg.content}</p>

              {msg.role === 'assistant' && (
                <div className="mt-3 pt-2.5 border-t border-purple-100 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs text-slate-500 font-mono tabular-nums">
                    {msg.sourcePages && msg.sourcePages.length > 0
                      ? `Sources: Page${msg.sourcePages.length > 1 ? 's' : ''} ${msg.sourcePages.join(', ')}`
                      : 'Grounded in uploaded document'}
                  </span>
                  <CopyButton text={msg.content} label="Copy" />
                </div>
              )}
            </div>

            {msg.role === 'user' && (
              <div className="w-8 h-8 rounded-xl bg-slate-200 text-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}

        {isStreaming && (
          <div className="flex items-start gap-3 justify-start">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 text-white flex items-center justify-center shrink-0 mt-0.5">
              <Bot className="w-4 h-4" />
            </div>
            <div className="max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed bg-white border border-purple-200/80 text-slate-800 shadow-xs">
              {streamingText ? (
                <p className="whitespace-pre-wrap break-words">
                  {streamingText}
                </p>
              ) : (
                <div className="flex items-center gap-2 text-slate-500">
                  <Loader2 className="w-4 h-4 animate-spin text-violet-600" />
                  <span>Retrieving relevant passages &amp; generating answer...</span>
                </div>
              )}
              {streamingPages.length > 0 && (
                <p className="mt-2 text-xs text-slate-400 font-mono tabular-nums">
                  Checking pages: {streamingPages.join(', ')}
                </p>
              )}
            </div>
          </div>
        )}

        {error && (
          <ErrorMessage
            title="Assistant Error"
            message={error}
            onDismiss={() => setError(null)}
          />
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input Form */}
      <form
        onSubmit={handleSubmit}
        className="p-4 border-t border-purple-100 bg-white flex items-center gap-3"
      >
        <label htmlFor="papermind-chat-input" className="sr-only">
          Ask a question about your research paper
        </label>
        <input
          id="papermind-chat-input"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={isStreaming || isOfflineSnapshot}
          placeholder="Ask anything about objectives, methodology, metrics, or limitations..."
          className="flex-1 px-4 py-3 rounded-xl border border-purple-200 bg-purple-50/30 text-sm text-[#13112C] placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500 focus:bg-white disabled:opacity-60"
        />
        <button
          type="submit"
          disabled={isStreaming || !input.trim() || isOfflineSnapshot}
          className="inline-flex items-center gap-2 px-5 py-3 rounded-xl text-sm font-semibold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm transition-all shrink-0"
        >
          {isStreaming ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Send className="w-4 h-4" />
          )}
          <span className="hidden sm:inline">Send</span>
        </button>
      </form>
    </div>
  );
}
